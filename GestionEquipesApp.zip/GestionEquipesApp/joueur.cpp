// joueur.cpp
#include "joueur.h" // Include direct

Joueur::Joueur() :
    m_id(-1),
    m_numeroMaillot(0), // Ou une autre valeur par défaut
    m_idEquipeActuelle(-1) // -1 pour indiquer NULL/pas d'équipe
{}

Joueur::Joueur(int id, const QString &nom, const QString &prenom) :
    m_id(id),
    m_nom(nom),
    m_prenom(prenom),
    m_numeroMaillot(0),
    m_idEquipeActuelle(-1)
{}

// --- Getters ---
int Joueur::getId() const { return m_id; }
QString Joueur::getNom() const { return m_nom; }
QString Joueur::getPrenom() const { return m_prenom; }
QDate Joueur::getDateNaissance() const { return m_dateNaissance; }
QString Joueur::getPosition() const { return m_position; }
int Joueur::getNumeroMaillot() const { return m_numeroMaillot; }
int Joueur::getIdEquipeActuelle() const { return m_idEquipeActuelle; }


// --- Setters ---
void Joueur::setId(int id) { m_id = id; }
void Joueur::setNom(const QString &nom) { m_nom = nom; }
void Joueur::setPrenom(const QString &prenom) { m_prenom = prenom; }
void Joueur::setDateNaissance(const QDate &date) { m_dateNaissance = date; }
void Joueur::setPosition(const QString &position) { m_position = position; }
void Joueur::setNumeroMaillot(int numero) { m_numeroMaillot = numero; }
void Joueur::setIdEquipeActuelle(int idEquipe) { m_idEquipeActuelle = idEquipe; }
