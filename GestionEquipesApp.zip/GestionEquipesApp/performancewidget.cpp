// performancewidget.cpp (Corrigé)
#include "performancewidget.h"

#include <QApplication>
#include <QComboBox>
#include <QPushButton>
#include <QLabel>
#include <QGroupBox>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QSpacerItem>
#include <QMessageBox>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QVariant>
#include <QPainter>

// Utilisation du namespace QtCharts si déclaré dans le .h avec QT_CHARTS_USE_NAMESPACE
// ou préfixer explicitement les types si vous n'utilisez pas la macro/directive using.
// QT_CHARTS_USE_NAMESPACE // Facultatif si déjà dans .h, mais ne nuit pas

// Constructeur (liste d'initialisation corrigée)
PerformanceWidget::PerformanceWidget(Connection *connection, QWidget *parent) :
    QWidget(parent),
    // Initialisation des pointeurs widgets à nullptr
    mainLayout(nullptr), selectionLayout(nullptr), selectTeamLabel(nullptr),
    teamComboBox(nullptr), analyzeButton(nullptr), refreshTeamsButton(nullptr),
    statsGroupBox(nullptr), statsLayout(nullptr),
    matchesPlayedLabel(nullptr), matchesPlayedValue(nullptr),
    winsLabel(nullptr), winsValue(nullptr), drawsLabel(nullptr), drawsValue(nullptr),
    lossesLabel(nullptr), lossesValue(nullptr), goalsForLabel(nullptr), goalsForValue(nullptr),
    goalsAgainstLabel(nullptr), goalsAgainstValue(nullptr), goalDiffLabel(nullptr), goalDiffValue(nullptr),
    chartGroupBox(nullptr), chartLayout(nullptr),
    statsChartView(nullptr), // Ne pas initialiser ici, fait dans setupChart/setupUi
    chart(nullptr),          // Ne pas initialiser ici, fait dans setupChart/setupUi
    m_connection(connection) // m_connection initialisé en dernier comme déclaré dans .h (supposé)
{
    if (!m_connection) {
        qCritical() << "FATAL: PerformanceWidget a reçu un pointeur Connection nul!";
        setEnabled(false); // Désactiver le widget si pas de connexion
    }

    setupUi(); // Crée les widgets ET appelle setupChart implicitement
    connectSignalsSlots();

    if (m_connection && m_connection->database().isOpen()) {
        refreshTeamList();
    } else {
        // Tenter de connecter une fois si non ouvert
        if(m_connection && m_connection->createconnect()) {
            refreshTeamList();
        } else {
            qWarning() << "Connexion DB non disponible lors de l'initialisation de PerformanceWidget.";
            QMessageBox::warning(this, "Connexion Base de Données",
                                 "La connexion à la base de données n'est pas disponible.\n"
                                 "L'analyse de performance ne peut pas être effectuée.");
            if(teamComboBox) teamComboBox->setEnabled(false);
            if(analyzeButton) analyzeButton->setEnabled(false);
            if(refreshTeamsButton) refreshTeamsButton->setEnabled(false);
        }
    }
    clearStatsDisplay();
}

PerformanceWidget::~PerformanceWidget()
{
    // Destruction gérée par Qt
}

void PerformanceWidget::setupUi() {
    mainLayout = new QVBoxLayout(this);

    selectionLayout = new QHBoxLayout();
    selectTeamLabel = new QLabel("Analyser l'équipe:", this);
    teamComboBox = new QComboBox(this);
    teamComboBox->setMinimumWidth(200);
    analyzeButton = new QPushButton("Analyser", this);
    refreshTeamsButton = new QPushButton("Rafraîchir Équipes", this);
    selectionLayout->addWidget(selectTeamLabel);
    selectionLayout->addWidget(teamComboBox);
    selectionLayout->addWidget(analyzeButton);
    selectionLayout->addWidget(refreshTeamsButton);
    selectionLayout->addStretch();
    mainLayout->addLayout(selectionLayout);

    statsGroupBox = new QGroupBox("Statistiques Textuelles", this);
    statsLayout = new QGridLayout(statsGroupBox);
    matchesPlayedLabel = new QLabel("Matchs Joués:", statsGroupBox); matchesPlayedValue = new QLabel("N/A", statsGroupBox);
    winsLabel = new QLabel("Victoires:", statsGroupBox); winsValue = new QLabel("N/A", statsGroupBox);
    drawsLabel = new QLabel("Nuls:", statsGroupBox); drawsValue = new QLabel("N/A", statsGroupBox);
    lossesLabel = new QLabel("Défaites:", statsGroupBox); lossesValue = new QLabel("N/A", statsGroupBox);
    goalsForLabel = new QLabel("Buts Pour (BP):", statsGroupBox); goalsForValue = new QLabel("N/A", statsGroupBox);
    goalsAgainstLabel = new QLabel("Buts Contre (BC):", statsGroupBox); goalsAgainstValue = new QLabel("N/A", statsGroupBox);
    goalDiffLabel = new QLabel("Différence (Diff):", statsGroupBox); goalDiffValue = new QLabel("N/A", statsGroupBox);
    QString valueStyle = "font-weight: bold;";
    matchesPlayedValue->setStyleSheet(valueStyle); winsValue->setStyleSheet(valueStyle); drawsValue->setStyleSheet(valueStyle);
    lossesValue->setStyleSheet(valueStyle); goalsForValue->setStyleSheet(valueStyle); goalsAgainstValue->setStyleSheet(valueStyle); goalDiffValue->setStyleSheet(valueStyle);
    statsLayout->addWidget(matchesPlayedLabel, 0, 0); statsLayout->addWidget(matchesPlayedValue, 0, 1);
    statsLayout->addWidget(winsLabel, 1, 0);          statsLayout->addWidget(winsValue, 1, 1);
    statsLayout->addWidget(drawsLabel, 2, 0);         statsLayout->addWidget(drawsValue, 2, 1);
    statsLayout->addWidget(lossesLabel, 3, 0);        statsLayout->addWidget(lossesValue, 3, 1);
    statsLayout->addWidget(goalsForLabel, 0, 2);      statsLayout->addWidget(goalsForValue, 0, 3);
    statsLayout->addWidget(goalsAgainstLabel, 1, 2);  statsLayout->addWidget(goalsAgainstValue, 1, 3);
    statsLayout->addWidget(goalDiffLabel, 2, 2);      statsLayout->addWidget(goalDiffValue, 2, 3);
    statsLayout->addItem(new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum), 0, 4, 4, 1);
    statsLayout->setColumnStretch(4, 1);
    mainLayout->addWidget(statsGroupBox);

    chartGroupBox = new QGroupBox("Graphique Victoires/Nuls/Défaites", this);
    chartLayout = new QVBoxLayout(chartGroupBox);
    // Appel de setupChart pour créer chart et chartView
    setupChart();
    if(statsChartView) {
        chartLayout->addWidget(statsChartView); // Ajouter la vue créée au layout
    } else {
        qWarning() << "Impossible de créer QChartView.";
        chartLayout->addWidget(new QLabel("Erreur: Impossible d'afficher le graphique.", chartGroupBox));
    }
    mainLayout->addWidget(chartGroupBox);

    mainLayout->addStretch();
}

void PerformanceWidget::setupChart() {
    if (!chart) { // Créer QChart seulement s'il n'existe pas
        chart = new QChart();
        chart->setTitle("Résultats (V/N/D) - Sélectionner une équipe");
        chart->setAnimationOptions(QChart::SeriesAnimations);
        chart->legend()->setVisible(true);
        chart->legend()->setAlignment(Qt::AlignBottom);

        QBarCategoryAxis *axisX = new QBarCategoryAxis();
        QValueAxis *axisY = new QValueAxis();
        axisY->setMin(0);
        chart->addAxis(axisX, Qt::AlignBottom);
        chart->addAxis(axisY, Qt::AlignLeft);
    }

    if (!statsChartView) { // Créer QChartView seulement s'il n'existe pas
        // S'assurer que 'chart' existe avant de créer la vue
        if (!chart) {
            qWarning() << "QChart non initialisé avant QChartView dans setupChart.";
            return; // Ne peut pas créer la vue sans le graphique
        }
        // Passer le parent (chartGroupBox) au constructeur de QChartView
        statsChartView = new QChartView(chart, chartGroupBox);
        statsChartView->setRenderHint(QPainter::Antialiasing);
        statsChartView->setMinimumHeight(250);
    } else {
        // S'il existe déjà, s'assurer qu'il utilise le bon QChart (utile si on recrée QChart)
        statsChartView->setChart(chart);
    }
}

void PerformanceWidget::connectSignalsSlots() {
    if(analyzeButton) connect(analyzeButton, &QPushButton::clicked, this, &PerformanceWidget::analyzeSelectedTeam);
    if(refreshTeamsButton) connect(refreshTeamsButton, &QPushButton::clicked, this, &PerformanceWidget::refreshTeamList);
    if(teamComboBox) connect(teamComboBox, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &PerformanceWidget::clearStatsOnTeamChange);
}


void PerformanceWidget::refreshTeamList() {
    if (!m_connection || !m_connection->database().isOpen()) {
        QMessageBox::warning(this, "Connexion Base de Données", "La connexion n'est pas disponible pour rafraîchir.");
        return;
    }
    QApplication::setOverrideCursor(Qt::WaitCursor);
    loadTeamsCache();
    populateTeamCombo();
    clearStatsDisplay();
    QApplication::restoreOverrideCursor();
}

void PerformanceWidget::analyzeSelectedTeam() {
    if (!m_connection || !m_connection->database().isOpen()) {
        QMessageBox::critical(this, "Erreur", "Connexion à la base de données non disponible.");
        return;
    }
    if (!teamComboBox) return;

    int teamId = teamComboBox->currentData().toInt();

    if (teamId < 0) {
        QMessageBox::warning(this, "Sélection Requise", "Veuillez sélectionner une équipe à analyser.");
        clearStatsDisplay();
        return;
    }

    QApplication::setOverrideCursor(Qt::WaitCursor);
    // Note: clearStatsDisplay est appelé par clearStatsOnTeamChange quand l'index change,
    // mais l'appeler ici aussi garantit la réinitialisation avant l'analyse.
    // clearStatsDisplay();

    QSqlDatabase db = m_connection->database();
    QSqlQuery query(db);

    query.prepare("SELECT id_equipe_domicile, id_equipe_exterieur, score_domicile, score_exterieur "
                  "FROM MATCHS " // Assurez-vous que le nom de table est correct
                  "WHERE (id_equipe_domicile = :id OR id_equipe_exterieur = :id) "
                  "AND score_domicile IS NOT NULL AND score_exterieur IS NOT NULL");
    query.bindValue(":id", teamId);

    int matchesPlayed = 0, wins = 0, draws = 0, losses = 0, goalsFor = 0, goalsAgainst = 0;
    bool queryOk = false;

    if (query.exec()) {
        queryOk = true;
        while (query.next()) {
            matchesPlayed++;
            int idDomicile = query.value(0).toInt();
            int scoreDomicile = query.value(2).toInt();
            int scoreExterieur = query.value(3).toInt();

            if (idDomicile == teamId) {
                goalsFor += scoreDomicile;
                goalsAgainst += scoreExterieur;
                if (scoreDomicile > scoreExterieur) wins++;
                else if (scoreDomicile == scoreExterieur) draws++;
                else losses++;
            } else {
                goalsFor += scoreExterieur;
                goalsAgainst += scoreDomicile;
                if (scoreExterieur > scoreDomicile) wins++;
                else if (scoreExterieur == scoreDomicile) draws++;
                else losses++;
            }
        }
    } else {
        qWarning() << "Erreur analyse performance pour équipe ID" << teamId << ":" << query.lastError().text();
        QMessageBox::critical(this, "Erreur Analyse", "Impossible de récupérer les données des matchs.\n" + query.lastError().text());
    }

    QApplication::restoreOverrideCursor();

    // Mise à jour des labels (vérifier pointeurs non nuls)
    if(matchesPlayedValue) matchesPlayedValue->setText(QString::number(matchesPlayed));
    if(winsValue) winsValue->setText(QString::number(wins));
    if(drawsValue) drawsValue->setText(QString::number(draws));
    if(lossesValue) lossesValue->setText(QString::number(losses));
    if(goalsForValue) goalsForValue->setText(QString::number(goalsFor));
    if(goalsAgainstValue) goalsAgainstValue->setText(QString::number(goalsAgainst));

    int goalDiff = goalsFor - goalsAgainst;
    if(goalDiffValue) {
        goalDiffValue->setText(QString::number(goalDiff));
        if (goalDiff > 0) goalDiffValue->setText("+" + QString::number(goalDiff));
        goalDiffValue->setStyleSheet(goalDiff > 0 ? "font-weight: bold; color: green;" :
                                         goalDiff < 0 ? "font-weight: bold; color: red;" :
                                         "font-weight: bold;");
    }

    if(queryOk) {
        // << CORRECTION: Appel avec teamId >>
        updateChart(wins, draws, losses, teamId);
    } else {
        clearStatsDisplay();
    }
}

void PerformanceWidget::clearStatsOnTeamChange(int index){
    Q_UNUSED(index);
    clearStatsDisplay();
}

void PerformanceWidget::loadTeamsCache() {
    if (!m_connection || !m_connection->database().isOpen()) {
        qWarning() << "PerformanceWidget::loadTeamsCache: Connexion DB non disponible.";
        m_allTeams.clear(); return;
    }
    m_allTeams.clear();
    QSqlDatabase db = m_connection->database();
    QSqlQuery query(db);
    if(query.exec("SELECT id_equipe, nom FROM equipes ORDER BY nom")) { // Assurez-vous que table EQUIPES existe
        while(query.next()) {
            Equipe equipe;
            equipe.setId(query.value(0).toInt());
            equipe.setNom(query.value(1).toString());
            m_allTeams.append(equipe);
        }
        qInfo() << "Cache équipes (Perf) rechargé:" << m_allTeams.count() << "équipes.";
    } else {
        qWarning() << "Erreur rechargement cache équipes (Perf):" << query.lastError().text();
    }
}

void PerformanceWidget::populateTeamCombo() {
    if(!teamComboBox) return;
    teamComboBox->clear();
    teamComboBox->addItem("Sélectionner une équipe...", -1);
    for (const Equipe &team : m_allTeams) {
        teamComboBox->addItem(QString("%1 (ID:%2)").arg(team.getNom()).arg(team.getId()), team.getId());
    }
}

// << CORRECTION: Définition avec teamId >>
void PerformanceWidget::updateChart(int wins, int draws, int losses, int teamId) {
    if (!chart || !statsChartView) {
        qWarning() << "Tentative de mise à jour du graphique avant initialisation.";
        return;
    }

    chart->removeAllSeries();
    QList<QAbstractAxis*> currentAxes = chart->axes();
    for(QAbstractAxis *axis : currentAxes) {
        chart->removeAxis(axis);
        // delete axis; // Normalement géré par removeAxis
    }

    QBarSet *setWins = new QBarSet("Victoires");
    QBarSet *setDraws = new QBarSet("Nuls");
    QBarSet *setLosses = new QBarSet("Défaites");
    *setWins << wins;
    *setDraws << draws;
    *setLosses << losses;
    setWins->setColor(QColor("#2ECC71"));
    setDraws->setColor(QColor("#F1C40F"));
    setLosses->setColor(QColor("#E74C3C"));

    QBarSeries *series = new QBarSeries();
    series->append(setWins);
    series->append(setDraws);
    series->append(setLosses);

    chart->addSeries(series);

    QBarCategoryAxis *axisX = new QBarCategoryAxis();
    QStringList categories; categories << "Résultats";
    axisX->append(categories);
    chart->addAxis(axisX, Qt::AlignBottom);
    series->attachAxis(axisX);

    QValueAxis *axisY = new QValueAxis();
    int maxVal = qMax(wins, qMax(draws, losses));
    axisY->setRange(0, qMax(5, maxVal + 1));
    int tickCount = qMin(maxVal + 2, 11);
    if (tickCount < 2) tickCount = 2;
    axisY->setTickCount(tickCount);
    axisY->setLabelFormat("%d");
    axisY->setTitleText("Nombre de Matchs");
    chart->addAxis(axisY, Qt::AlignLeft);
    series->attachAxis(axisY);

    QString teamName = "[Équipe Inconnue]";
    if (teamComboBox && teamId >=0) {
        int index = teamComboBox->findData(teamId);
        if (index >= 0) {
            teamName = teamComboBox->itemText(index).split(" (ID:").first();
        } else {
            qWarning() << "Impossible de trouver le nom de l'équipe ID" << teamId << "dans le ComboBox.";
        }
    }

    if (teamId >= 0) {
        chart->setTitle(QString("Résultats (V/N/D) - %1").arg(teamName));
        chart->legend()->setVisible(true);
    } else {
        chart->setTitle("Résultats (V/N/D)");
        chart->legend()->setVisible(false);
    }
    chart->legend()->setAlignment(Qt::AlignBottom);
}

void PerformanceWidget::clearStatsDisplay() {
    if(matchesPlayedValue) matchesPlayedValue->setText("N/A");
    if(winsValue) winsValue->setText("N/A");
    if(drawsValue) drawsValue->setText("N/A");
    if(lossesValue) lossesValue->setText("N/A");
    if(goalsForValue) goalsForValue->setText("N/A");
    if(goalsAgainstValue) goalsAgainstValue->setText("N/A");
    if(goalDiffValue) {
        goalDiffValue->setText("N/A");
        goalDiffValue->setStyleSheet("");
    }

    if (chart) {
        chart->removeAllSeries();
        QList<QAbstractAxis*> currentAxes = chart->axes();
        for(QAbstractAxis *axis : currentAxes) { chart->removeAxis(axis); }

        QBarCategoryAxis *axisX = new QBarCategoryAxis();
        QValueAxis *axisY = new QValueAxis();
        axisY->setMin(0);
        axisY->setMax(5);
        axisY->setTickCount(6);
        chart->addAxis(axisX, Qt::AlignBottom);
        chart->addAxis(axisY, Qt::AlignLeft);

        chart->setTitle("Sélectionner une équipe et cliquer sur Analyser");
        chart->legend()->setVisible(false);
    }
}
