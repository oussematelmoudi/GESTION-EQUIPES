// mainwindow.h (Sans logo dans l'UI)
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "connection.h"

// Includes des widgets d'onglet
#include "teammanagementwidget.h"
#include "playermanagementwidget.h" // Vérifiez le nom de fichier réel
#include "coachmanagementwidget.h"
#include "transfermanagementwidget.h"
#include "matchmanagementwidget.h"
#include "performancewidget.h"
#include "standingswidget.h"

// Forward declarations Qt
class QTabWidget;
class QWidget;
class QVBoxLayout; // Ajouté pour le layout du centralWidget

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    void setupUi();
    void setupDatabase();
    void setupTabs();

    // --- Widgets principaux ---
    QWidget *centralArea;     // Le conteneur principal pour le QTabWidget
    QTabWidget *tabWidget;    // Le gestionnaire d'onglets (remplit centralArea)
    // PAS de QToolBar ou QLabel pour le logo ici

    // --- Connexion DB ---
    Connection m_dbConnection;

    // --- Pointeurs vers les onglets ---
    TeamManagementWidget *m_teamManagementTab;
    PlayerManagementWidget *m_playerManagementTab;
    CoachManagementWidget *m_coachManagementTab;
    TransferManagementWidget *m_transferManagementTab;
    MatchManagementWidget *m_matchManagementTab;
    PerformanceWidget *m_performanceTab;
    StandingsWidget *m_standingsTab;
};

#endif // MAINWINDOW_H
