// coachhistorydialog.h
#ifndef COACHHISTORYDIALOG_H
#define COACHHISTORYDIALOG_H

#include <QDialog>
#include <QDate>
#include <QMap> // Pour passer la liste des équipes

// Necessary Qt includes for members/forward declarations
#include <QLabel>
#include <QVBoxLayout> // Include for QVBoxLayout member

// Forward declarations
class QComboBox;
class QDateEdit;
class QCheckBox;
class QPushButton;
class QFormLayout;
class QDialogButtonBox;


class CoachHistoryDialog : public QDialog
{
    Q_OBJECT

public:
    // Le constructeur prend la liste des équipes disponibles (ID -> Nom)
    explicit CoachHistoryDialog(const QMap<int, QString> &availableTeams, QWidget *parent = nullptr);

    // Fonctions pour pré-remplir le dialogue en mode édition
    void setHistoryData(int equipeId, const QDate& dateDebut, const QDate& dateFin, bool isCurrent);

    // Getters pour récupérer les données saisies
    int getSelectedEquipeId() const;
    QDate getDateDebut() const;
    QDate getDateFin() const; // Retourne une date invalide si "Actuel" est coché
    bool isCurrentAssignment() const;

private slots:
    // Slot signature remains compatible with checkStateChanged(int)
    void onCurrentCheckboxChanged(int state);

private:
    void setupUi();

    // Member variable declarations
    QVBoxLayout *mainLayout;   // <<< ADDED DECLARATION
    QFormLayout *formLayout;
    QLabel *equipeLabel;
    QComboBox *equipeComboBox;
    QLabel *debutLabel;
    QDateEdit *debutDateEdit;
    QLabel *finLabel;
    QDateEdit *finDateEdit;
    QCheckBox *currentCheckBox; // Pour indiquer si c'est l'affectation actuelle
    QDialogButtonBox *buttonBox;

    QMap<int, QString> teamsMap; // Stocke les équipes pour le ComboBox
};

#endif // COACHHISTORYDIALOG_H
