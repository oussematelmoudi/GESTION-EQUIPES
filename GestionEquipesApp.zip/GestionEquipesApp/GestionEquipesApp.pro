# GestionEquipesApp.pro - Structure Plate - Complet

# Modules Qt requis : core, gui (pour widgets), widgets, sql (base de données), charts (graphiques)
QT       += core gui widgets sql charts

# Nécessaire pour Qt 5 et supérieur pour le module widgets
greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

# Spécifie le standard C++ (c++11 est le minimum pour les lambdas/Qt5+, c++17 est bien)
# Assurez-vous que votre compilateur le supporte
CONFIG += c++17 console

# Nom de l'exécutable final
TARGET = GestionEquipesApp
# Type de projet (application)
TEMPLATE = app

# PAS D'INCLUDEPATH car tous les fichiers sont à la racine du projet

# Liste des fichiers source (.cpp)
SOURCES += \
    coachhistorydialog.cpp \
    main.cpp \
    connection.cpp \
    equipe.cpp \
    joueur.cpp \
    coach.cpp \
    mainwindow.cpp \
    standingswidget.cpp \
    teammanagementwidget.cpp \
    coachmanagementwidget.cpp \
    transfermanagementwidget.cpp \
    matchmanagementwidget.cpp \
    performancewidget.cpp \
    playermanagementwidget.cpp

# Liste des fichiers d'en-tête (.h)
HEADERS += \
    coachhistorydialog.h \
    connection.h \
    equipe.h \
    joueur.h \
    coach.h \
    mainwindow.h \
    standingswidget.h \
    teammanagementwidget.h \
    coachmanagementwidget.h \
    transfermanagementwidget.h \
    matchmanagementwidget.h \
    performancewidget.h \
    playermanagementwidget.h

# Fichier de ressources Qt (si utilisé, par exemple pour le fichier .qss)
RESOURCES += \
    resources.qrc

# PAS DE SECTION FORMS car l'UI est créée en code C++

# Active les avertissements pour les API Qt dépréciées
DEFINES += QT_DEPRECATED_WARNINGS
# Pour interdire l'utilisation d'API dépréciées avant Qt 6.0 (décommentez si besoin)
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000

# --- Configuration Spécifique Oracle (Rappel) ---
# Ces lignes sont généralement nécessaires UNIQUEMENT si Qt ne trouve pas
# automatiquement votre installation Oracle Client / Instant Client et le driver ODBC/OCI.
# Adaptez les chemins à VOTRE installation.
# win32: INCLUDEPATH += "C:/chemin/vers/oracle/instantclient_XX_X/sdk/include"
# win32: LIBS += -L"C:/chemin/vers/oracle/instantclient_XX_X" -loci # ou le nom de la lib odbc si odbc direct
# unix: INCLUDEPATH += /chemin/vers/oracle/instantclient_XX_X/sdk/include
# unix: LIBS += -L/chemin/vers/oracle/instantclient_XX_X -Wl,-rpath,/chemin/vers/oracle/instantclient_XX_X -loci
# macx: INCLUDEPATH += /chemin/vers/oracle/instantclient_XX_X/sdk/include
# macx: LIBS += -L/chemin/vers/oracle/instantclient_XX_X -loci
