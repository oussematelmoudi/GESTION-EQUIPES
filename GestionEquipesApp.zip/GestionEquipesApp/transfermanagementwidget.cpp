// transfermanagementwidget.cpp
#include "transfermanagementwidget.h"

// Includes Qt nécessaires
#include <QApplication> // Pour le curseur d'attente
#include <QTableWidget>
#include <QPushButton>
#include <QComboBox>
#include <QLabel>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QFormLayout>
#include <QDateEdit>
#include <QDoubleSpinBox>
#include <QCalendarWidget>
#include <QHeaderView>
#include <QMessageBox>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QVariant>
#include <stdexcept> // Pour std::runtime_error

// Constante définie aussi dans le .h, mais peut être redéfinie ici si non visible
// const int NO_TEAM_ID = -1;

// Constructeur
TransferManagementWidget::TransferManagementWidget(Connection *connection, QWidget *parent) :
    QWidget(parent),
    m_connection(connection)
{
    if (!m_connection) {
        qCritical() << "FATAL: TransferManagementWidget a reçu un pointeur Connection nul!";
    }

    setupUi();
    connectSignalsSlots();

    // Charger les données initiales si la connexion est prête
    if (m_connection && m_connection->database().isOpen()) {
        refreshLists(); // Charge tout au début
    } else {
        qWarning() << "Connexion DB non disponible lors de l'initialisation de TransferManagementWidget.";
        QMessageBox::warning(this, "Connexion Base de Données",
                             "La connexion à la base de données n'est pas disponible.\n"
                             "Les données des transferts ne peuvent pas être gérées.");
        // Désactiver les widgets si nécessaire
        addTransferGroupBox->setEnabled(false);
        historyGroupBox->setEnabled(false);
    }
}

// Crée et arrange les widgets de l'interface
void TransferManagementWidget::setupUi() {
    mainLayout = new QVBoxLayout(this); // Layout principal vertical
    topLayout = new QHBoxLayout();      // Layout pour formulaire et liste côte à côte

    // --- Section Gauche : Formulaire Ajout Transfert ---
    addTransferGroupBox = new QGroupBox("Enregistrer un Nouveau Transfert", this);
    addTransferFormLayout = new QFormLayout(addTransferGroupBox);

    playerLabel = new QLabel("Joueur:", addTransferGroupBox);
    playerComboBox = new QComboBox(addTransferGroupBox);
    originTeamLabel = new QLabel("Équipe Origine:", addTransferGroupBox);
    originTeamComboBox = new QComboBox(addTransferGroupBox);
    destTeamLabel = new QLabel("Équipe Destination:", addTransferGroupBox);
    destTeamComboBox = new QComboBox(addTransferGroupBox);
    dateLabel = new QLabel("Date Transfert:", addTransferGroupBox);
    transferDateEdit = new QDateEdit(QDate::currentDate(), addTransferGroupBox);
    transferDateEdit->setCalendarPopup(true);
    transferDateEdit->setDisplayFormat("dd/MM/yyyy");
    amountLabel = new QLabel("Montant:", addTransferGroupBox);
    amountSpinBox = new QDoubleSpinBox(addTransferGroupBox);
    amountSpinBox->setRange(0.0, 999999999.99); // Plage pour le montant
    amountSpinBox->setDecimals(2);
    amountSpinBox->setSuffix(" €"); // Optionnel: unité

    saveTransferButton = new QPushButton("Enregistrer Transfert", addTransferGroupBox);

    addTransferFormLayout->addRow(playerLabel, playerComboBox);
    addTransferFormLayout->addRow(originTeamLabel, originTeamComboBox);
    addTransferFormLayout->addRow(destTeamLabel, destTeamComboBox);
    addTransferFormLayout->addRow(dateLabel, transferDateEdit);
    addTransferFormLayout->addRow(amountLabel, amountSpinBox);
    addTransferFormLayout->addRow(saveTransferButton);

    topLayout->addWidget(addTransferGroupBox, 1); // Le formulaire prend moins de place

    // --- Section Droite : Historique ---
    historyGroupBox = new QGroupBox("Historique des Transferts", this);
    historyVBoxLayout = new QVBoxLayout(historyGroupBox);

    transferTableWidget = new QTableWidget(historyGroupBox);
    transferTableWidget->setColumnCount(6); // ID, Date, Joueur, Origine, Destination, Montant
    transferTableWidget->setHorizontalHeaderLabels({"ID", "Date", "Joueur", "Origine", "Destination", "Montant"});
    transferTableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    transferTableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    transferTableWidget->setColumnWidth(0, 50); // ID
    transferTableWidget->setColumnWidth(1, 80); // Date
    transferTableWidget->setColumnWidth(4, 120); // Destination
    transferTableWidget->setColumnWidth(5, 90); // Montant
    transferTableWidget->horizontalHeader()->setStretchLastSection(false); // Ne pas étirer la dernière par défaut
    transferTableWidget->horizontalHeader()->setSectionResizeMode(2, QHeaderView::Stretch); // Étire Joueur
    transferTableWidget->horizontalHeader()->setSectionResizeMode(3, QHeaderView::Stretch); // Étire Origine
    // Aligner le montant à droite (fait lors du remplissage)

    refreshButton = new QPushButton("Rafraîchir l'Historique", historyGroupBox);

    historyVBoxLayout->addWidget(transferTableWidget);
    historyVBoxLayout->addWidget(refreshButton);

    topLayout->addWidget(historyGroupBox, 2); // La liste prend plus de place

    // --- Assemblage Final ---
    mainLayout->addLayout(topLayout);
}

// Connecte les signaux des widgets UI aux slots
void TransferManagementWidget::connectSignalsSlots() {
    connect(saveTransferButton, &QPushButton::clicked, this, &TransferManagementWidget::saveNewTransfer);
    connect(refreshButton, &QPushButton::clicked, this, &TransferManagementWidget::refreshLists);
}

// --- Implémentation des Slots ---

// Recharge toutes les données nécessaires à ce widget
void TransferManagementWidget::refreshLists() {
    if (!m_connection || !m_connection->database().isOpen()) {
        QMessageBox::warning(this, "Connexion Base de Données", "La connexion n'est pas disponible pour rafraîchir.");
        return;
    }
    QApplication::setOverrideCursor(Qt::WaitCursor);
    loadPlayersCache();   // Recharge le cache joueurs
    loadTeamsCache();     // Recharge le cache équipes
    populateComboBoxes(); // Remplit les ComboBox avec les nouvelles données
    loadTransfersList();  // Recharge la table de l'historique
    QApplication::restoreOverrideCursor();
}

// Enregistre un nouveau transfert
void TransferManagementWidget::saveNewTransfer() {
    if (!m_connection || !m_connection->database().isOpen()) {
        QMessageBox::critical(this, "Erreur", "Connexion à la base de données non disponible.");
        return;
    }

    // Récupérer les données du formulaire
    int playerId = playerComboBox->currentData().toInt();
    int originTeamId = originTeamComboBox->currentData().toInt();
    int destTeamId = destTeamComboBox->currentData().toInt();
    QDate transferDate = transferDateEdit->date();
    double amount = amountSpinBox->value();

    // Validations simples
    if (playerId < 0) { // Assumant que les vrais IDs sont >= 0
        QMessageBox::warning(this, "Données Manquantes", "Veuillez sélectionner un joueur.");
        playerComboBox->setFocus();
        return;
    }
    if (originTeamId == destTeamId && originTeamId != NO_TEAM_ID) { // Permet Libre -> Libre mais pas EquipeA -> EquipeA
        QMessageBox::warning(this, "Données Invalides", "L'équipe d'origine et de destination ne peuvent pas être identiques (sauf si 'Libre').");
        return;
    }
    if (!transferDate.isValid()) {
        QMessageBox::warning(this, "Données Invalides", "Veuillez entrer une date de transfert valide.");
        transferDateEdit->setFocus();
        return;
    }

    // --- Logique de la Transaction ---
    QSqlDatabase db = m_connection->database();
    bool success = false;

    if (!db.transaction()) {
        qWarning() << "Impossible de démarrer la transaction pour saveNewTransfer: " + db.lastError().text();
        QMessageBox::critical(this, "Erreur Transaction", "Impossible de démarrer la transaction.");
        return;
    }

    QApplication::setOverrideCursor(Qt::WaitCursor);

    try {
        QSqlQuery query(db);

        // 1. Obtenir le nouvel ID pour le transfert (Syntaxe Oracle !)
        // !!! ATTENTION : Adapter si DB != Oracle !!!
        query.prepare("SELECT transfert_seq.NEXTVAL FROM DUAL");
        if (!query.exec()) throw std::runtime_error("Erreur obtention ID transfert: " + query.lastError().text().toStdString());
        int newTransferId = -1;
        if (query.next()) newTransferId = query.value(0).toInt();
        else throw std::runtime_error("Impossible de récupérer le nouvel ID transfert.");

        // 2. Insérer dans la table TRANSFERTS
        query.prepare("INSERT INTO transferts (id_transfert, id_joueur, id_equipe_origine, id_equipe_destination, date_transfert, montant) "
                      "VALUES (:id, :idj, :ideo, :ided, :datet, :montant)");
        query.bindValue(":id", newTransferId);
        query.bindValue(":idj", playerId);
        query.bindValue(":ideo", originTeamId == NO_TEAM_ID ? QVariant() : originTeamId); // Gère NULL
        query.bindValue(":ided", destTeamId == NO_TEAM_ID ? QVariant() : destTeamId);     // Gère NULL
        query.bindValue(":datet", transferDate);
        query.bindValue(":montant", amount);
        if (!query.exec()) throw std::runtime_error("Erreur insertion transfert: " + query.lastError().text().toStdString());

        // 3. Mettre à jour la table JOUEURS (équipe actuelle)
        query.prepare("UPDATE joueurs SET id_equipe_actuelle = :idequipe WHERE id_joueur = :idj");
        query.bindValue(":idequipe", destTeamId == NO_TEAM_ID ? QVariant() : destTeamId); // Met NULL si destination est "Libre"
        query.bindValue(":idj", playerId);
        if (!query.exec()) throw std::runtime_error("Erreur mise à jour équipe joueur: " + query.lastError().text().toStdString());

        // 4. Mettre à jour la table EQUIPE_JOUEURS (liaison N-N)
        // 4a. Retirer de l'ancienne équipe (si ce n'était pas "Libre")
        if (originTeamId != NO_TEAM_ID) {
            query.prepare("DELETE FROM equipe_joueurs WHERE id_equipe = :idequipe AND id_joueur = :idj");
            query.bindValue(":idequipe", originTeamId);
            query.bindValue(":idj", playerId);
            if (!query.exec()) throw std::runtime_error("Erreur suppression lien ancienne équipe: " + query.lastError().text().toStdString());
        }
        // 4b. Ajouter à la nouvelle équipe (si ce n'est pas "Libre")
        if (destTeamId != NO_TEAM_ID) {
            query.prepare("INSERT INTO equipe_joueurs (id_equipe, id_joueur) VALUES (:idequipe, :idj)");
            query.bindValue(":idequipe", destTeamId);
            query.bindValue(":idj", playerId);
            // Gérer le cas où le joueur est déjà dans l'équipe (peut arriver si données incohérentes)
            if (!query.exec() && query.lastError().type() != QSqlError::NoError) {
                bool isDuplicateKeyError = query.lastError().nativeErrorCode().contains("00001"); // ORA-00001
                if (!isDuplicateKeyError) {
                    throw std::runtime_error("Erreur insertion lien nouvelle équipe: " + query.lastError().text().toStdString());
                } else {
                    qWarning() << "Joueur" << playerId << "déjà présent dans équipe" << destTeamId << ", insertion ignorée.";
                }
            }
        }

        // 5. Commit si tout va bien
        if (!db.commit()) {
            throw std::runtime_error("Erreur commit transaction transfert: " + db.lastError().text().toStdString());
        }
        success = true;
        QMessageBox::information(this, "Succès", "Transfert enregistré avec succès.");

    } catch (const std::runtime_error &e) {
        qWarning() << "Erreur lors de l'enregistrement du transfert, rollback..." << e.what();
        db.rollback(); // Annule tout en cas d'erreur
        QMessageBox::critical(this, "Erreur Enregistrement", QString("L'opération a échoué: %1").arg(e.what()));
        success = false;
    }

    QApplication::restoreOverrideCursor();

    // Recharger les listes si succès
    if (success) {
        refreshLists();
        // Optionnel: réinitialiser le formulaire d'ajout
        playerComboBox->setCurrentIndex(0);
        originTeamComboBox->setCurrentIndex(0);
        destTeamComboBox->setCurrentIndex(0);
        transferDateEdit->setDate(QDate::currentDate());
        amountSpinBox->setValue(0.0);
    }
}


// --- Implémentation des Fonctions Privées ---

// Charge la liste des transferts depuis la DB et remplit la table UI
void TransferManagementWidget::loadTransfersList() {
    if (!m_connection || !m_connection->database().isOpen()) {
        qWarning() << "loadTransfersList: Connexion DB non disponible.";
        transferTableWidget->setRowCount(0);
        return;
    }
    transferTableWidget->setRowCount(0); // Vide avant de remplir
    transferTableWidget->setSortingEnabled(false); // Désactiver tri pendant remplissage
    QApplication::setOverrideCursor(Qt::WaitCursor);

    QSqlDatabase db = m_connection->database();
    QSqlQuery query(db);
    // Requête complexe avec des jointures pour récupérer les noms
    // Utilise || pour la concaténation Oracle, adapter si besoin pour autre SGBD
    QString sql = "SELECT t.id_transfert, t.date_transfert, "
                  "j.prenom || ' ' || j.nom AS joueur_nom, "
                  "eq_o.nom AS origine_nom, "
                  "eq_d.nom AS destination_nom, "
                  "t.montant "
                  "FROM TRANSFERTS t "
                  "LEFT JOIN JOUEURS j ON t.id_joueur = j.id_joueur "
                  "LEFT JOIN EQUIPES eq_o ON t.id_equipe_origine = eq_o.id_equipe "
                  "LEFT JOIN EQUIPES eq_d ON t.id_equipe_destination = eq_d.id_equipe "
                  "ORDER BY t.date_transfert DESC, t.id_transfert DESC"; // Tri par date puis ID

    if (query.exec(sql)) {
        int row = 0;
        while (query.next()) {
            transferTableWidget->insertRow(row);

            // ID Transfert (Colonne 0)
            QTableWidgetItem *idItem = new QTableWidgetItem(query.value(0).toString());
            idItem->setFlags(idItem->flags() & ~Qt::ItemIsEditable);

            // Date (Colonne 1)
            QTableWidgetItem *dateItem = new QTableWidgetItem(query.value(1).toDate().toString("dd/MM/yyyy"));
            dateItem->setFlags(dateItem->flags() & ~Qt::ItemIsEditable);

            // Joueur (Colonne 2)
            QTableWidgetItem *playerItem = new QTableWidgetItem(query.value(2).toString());
            playerItem->setFlags(playerItem->flags() & ~Qt::ItemIsEditable);

            // Origine (Colonne 3)
            QString originName = query.value(3).isNull() ? "Libre/Inconnu" : query.value(3).toString();
            QTableWidgetItem *originItem = new QTableWidgetItem(originName);
            originItem->setFlags(originItem->flags() & ~Qt::ItemIsEditable);

            // Destination (Colonne 4)
            QString destName = query.value(4).isNull() ? "Libre/Inconnu" : query.value(4).toString();
            QTableWidgetItem *destItem = new QTableWidgetItem(destName);
            destItem->setFlags(destItem->flags() & ~Qt::ItemIsEditable);

            // Montant (Colonne 5)
            QVariant amountVal = query.value(5);
            QTableWidgetItem *amountItem = new QTableWidgetItem();
            if (!amountVal.isNull()) {
                // Stocker la valeur numérique pour permettre le tri correct
                amountItem->setData(Qt::DisplayRole, amountVal.toDouble());
                // L'affichage par défaut d'un double peut convenir, ou formater spécifiquement:
                // amountItem->setText(QString::number(amountVal.toDouble(), 'f', 2) + " €");
            } else {
                amountItem->setText("N/A"); // Ou laisser vide
                amountItem->setData(Qt::DisplayRole, QVariant()); // Assurer que la donnée est nulle pour le tri
            }
            amountItem->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter); // Aligner à droite
            amountItem->setFlags(amountItem->flags() & ~Qt::ItemIsEditable);


            // Ajouter les items à la ligne
            transferTableWidget->setItem(row, 0, idItem);
            transferTableWidget->setItem(row, 1, dateItem);
            transferTableWidget->setItem(row, 2, playerItem);
            transferTableWidget->setItem(row, 3, originItem);
            transferTableWidget->setItem(row, 4, destItem);
            transferTableWidget->setItem(row, 5, amountItem);

            row++;
        }
        // Ajuster la taille finale si query.size() n'était pas fiable
        transferTableWidget->setRowCount(row);
    } else {
        qWarning() << "Erreur chargement historique transferts:" << query.lastError().text();
        QMessageBox::critical(this, "Erreur Chargement", "Impossible de charger l'historique des transferts.\n" + query.lastError().text());
    }

    transferTableWidget->setSortingEnabled(true); // Réactiver le tri
    transferTableWidget->resizeColumnsToContents(); // Ajuster largeur colonnes (sauf celles étirées)
    QApplication::restoreOverrideCursor();
}

// Charge les joueurs depuis la DB dans le cache m_allPlayers
void TransferManagementWidget::loadPlayersCache() {
    if (!m_connection || !m_connection->database().isOpen()) {
        qWarning() << "loadPlayersCache: Connexion DB non disponible.";
        m_allPlayers.clear(); return;
    }
    m_allPlayers.clear();
    QSqlDatabase db = m_connection->database();
    QSqlQuery query(db);
    if(query.exec("SELECT id_joueur, nom, prenom FROM joueurs ORDER BY nom, prenom")) {
        while(query.next()) {
            m_allPlayers.append(Joueur(query.value(0).toInt(), query.value(1).toString(), query.value(2).toString()));
        }
        qInfo() << "Cache joueurs rechargé:" << m_allPlayers.count() << "joueurs.";
    } else {
        qWarning() << "Erreur rechargement cache joueurs:" << query.lastError().text();
        // Pas de QMessageBox ici pour ne pas être trop intrusif lors d'un simple refresh de cache
    }
}

// Charge les équipes depuis la DB dans le cache m_allTeams
void TransferManagementWidget::loadTeamsCache() {
    if (!m_connection || !m_connection->database().isOpen()) {
        qWarning() << "loadTeamsCache: Connexion DB non disponible.";
        m_allTeams.clear(); return;
    }
    m_allTeams.clear();
    QSqlDatabase db = m_connection->database();
    QSqlQuery query(db);
    if(query.exec("SELECT id_equipe, nom FROM equipes ORDER BY nom")) {
        while(query.next()) {
            Equipe equipe;
            equipe.setId(query.value(0).toInt());
            equipe.setNom(query.value(1).toString());
            m_allTeams.append(equipe);
        }
        qInfo() << "Cache équipes rechargé:" << m_allTeams.count() << "équipes.";
    } else {
        qWarning() << "Erreur rechargement cache équipes:" << query.lastError().text();
    }
}

// Remplit les ComboBox à partir des caches chargés
void TransferManagementWidget::populateComboBoxes() {
    // Vider les ComboBox
    playerComboBox->clear();
    originTeamComboBox->clear();
    destTeamComboBox->clear();

    // Remplir ComboBox Joueurs
    playerComboBox->addItem("Sélectionner Joueur...", -1); // Invite + ID invalide
    for (const Joueur &player : m_allPlayers) {
        playerComboBox->addItem(QString("%1 %2 (ID:%3)").arg(player.getPrenom()).arg(player.getNom()).arg(player.getId()), player.getId());
    }

    // Remplir ComboBox Équipes (Origine et Destination)
    originTeamComboBox->addItem("Libre / Inconnu", NO_TEAM_ID); // Option spéciale
    destTeamComboBox->addItem("Libre / Inconnu", NO_TEAM_ID);   // Option spéciale
    for (const Equipe &team : m_allTeams) {
        originTeamComboBox->addItem(QString("%1 (ID:%2)").arg(team.getNom()).arg(team.getId()), team.getId());
        destTeamComboBox->addItem(QString("%1 (ID:%2)").arg(team.getNom()).arg(team.getId()), team.getId());
    }
}
