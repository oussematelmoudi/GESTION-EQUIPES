// standingswidget.cpp (Corrigé pour setCodec)
#include "standingswidget.h"

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGroupBox>
#include <QTableWidget>
#include <QPushButton>
#include <QHeaderView>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlError>
#include <QSqlDatabase>
#include <QDebug>
#include <QApplication>
#include <algorithm> // Pour std::sort

// Includes pour l'export CSV
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QDir> // Pour toNativeSeparators

// Constructeur (Liste d'initialisation correspond à l'ordre du .h corrigé)
StandingsWidget::StandingsWidget(Connection *connection, QWidget *parent) :
    QWidget(parent),
    mainLayout(nullptr), standingsGroupBox(nullptr), groupBoxLayout(nullptr),
    standingsTableWidget(nullptr), buttonsLayout(nullptr),
    refreshButton(nullptr), exportButton(nullptr),
    m_connection(connection) // m_connection initialisé après les widgets
// m_currentStandings est initialisé par défaut
{
    if (!m_connection) {
        qCritical() << "FATAL: StandingsWidget a reçu un pointeur Connection nul!";
        setEnabled(false);
    }

    setupUi();
    connectSignalsSlots();

    if (m_connection && m_connection->database().isOpen()) {
        refreshStandings();
    } else {
        if(m_connection && m_connection->createconnect()) {
            refreshStandings();
        } else {
            qWarning() << "Connexion DB non disponible lors de l'initialisation de StandingsWidget.";
            QMessageBox::warning(this, "Connexion Base de Données",
                                 "La connexion à la base de données n'est pas disponible.\n"
                                 "Le classement ne peut pas être calculé.");
            if(standingsGroupBox) standingsGroupBox->setEnabled(false);
        }
    }
}

// Crée l'interface utilisateur
void StandingsWidget::setupUi() {
    mainLayout = new QVBoxLayout(this);
    standingsGroupBox = new QGroupBox("Classement de la Ligue", this);
    groupBoxLayout = new QVBoxLayout(standingsGroupBox);

    standingsTableWidget = new QTableWidget(standingsGroupBox);
    standingsTableWidget->setColumnCount(10);
    standingsTableWidget->setHorizontalHeaderLabels({
        "Rang", "Équipe", "MJ", "V", "N", "D", "BP", "BC", "Diff", "Pts"
    });
    standingsTableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    standingsTableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    standingsTableWidget->setSelectionMode(QAbstractItemView::SingleSelection);
    standingsTableWidget->setAlternatingRowColors(true);
    standingsTableWidget->verticalHeader()->setVisible(false);
    standingsTableWidget->setSortingEnabled(false);

    buttonsLayout = new QHBoxLayout();
    refreshButton = new QPushButton("Rafraîchir", this);
    exportButton = new QPushButton("Exporter vers Excel (CSV)", this);
    buttonsLayout->addStretch();
    buttonsLayout->addWidget(refreshButton);
    buttonsLayout->addWidget(exportButton);

    groupBoxLayout->addWidget(standingsTableWidget);
    groupBoxLayout->addLayout(buttonsLayout);
    mainLayout->addWidget(standingsGroupBox);

    styleTable();
}

// Applique le style et ajuste les colonnes du tableau
void StandingsWidget::styleTable() {
    if (!standingsTableWidget) return;
    standingsTableWidget->setColumnWidth(0, 50);
    standingsTableWidget->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch);
    standingsTableWidget->setColumnWidth(2, 45);
    standingsTableWidget->setColumnWidth(3, 45);
    standingsTableWidget->setColumnWidth(4, 45);
    standingsTableWidget->setColumnWidth(5, 45);
    standingsTableWidget->setColumnWidth(6, 45);
    standingsTableWidget->setColumnWidth(7, 45);
    standingsTableWidget->setColumnWidth(8, 50);
    standingsTableWidget->setColumnWidth(9, 50);

    standingsTableWidget->horizontalHeader()->setDefaultAlignment(Qt::AlignCenter | Qt::Alignment(Qt::TextWordWrap));
    standingsTableWidget->horizontalHeader()->setStyleSheet("QHeaderView::section { text-align: center; }");
}

// Connecte les signaux
void StandingsWidget::connectSignalsSlots() {
    if (refreshButton) {
        connect(refreshButton, &QPushButton::clicked, this, &StandingsWidget::refreshStandings);
    }
    if (exportButton) {
        connect(exportButton, &QPushButton::clicked, this, &StandingsWidget::exportStandingsToCsv);
    }
}

// Slot pour rafraîchir le classement
void StandingsWidget::refreshStandings() {
    if (!m_connection || !m_connection->database().isOpen()) {
        if(m_connection && m_connection->createconnect()) {
            qInfo() << "Connexion rétablie pour refreshStandings.";
        } else {
            QMessageBox::warning(this, "Connexion Base de Données", "La connexion n'est pas disponible pour rafraîchir le classement.");
            return;
        }
    }
    QApplication::setOverrideCursor(Qt::WaitCursor);
    calculateAndDisplayStandings();
    QApplication::restoreOverrideCursor();
}

// Slot pour l'export CSV
void StandingsWidget::exportStandingsToCsv() {
    if (!standingsTableWidget || standingsTableWidget->rowCount() == 0) {
        QMessageBox::information(this, "Export CSV", "Le tableau de classement est vide.\nAucune donnée à exporter.");
        return;
    }

    QString defaultFileName = "classement_" + QDate::currentDate().toString("yyyyMMdd") + ".csv";
    QString fileName = QFileDialog::getSaveFileName(this, "Exporter le classement en CSV", defaultFileName,
                                                    "Fichiers CSV (*.csv);;Tous les fichiers (*)");

    if (fileName.isEmpty()) {
        return;
    }

    QFile file(fileName);
    if (!file.open(QFile::WriteOnly | QFile::Text)) { // QFile::Text gère les fins de ligne correctement
        QMessageBox::critical(this, "Erreur Export CSV", QString("Impossible d'ouvrir le fichier '%1' en écriture:\n%2.")
                                                             .arg(QDir::toNativeSeparators(fileName), file.errorString()));
        return;
    }

    QApplication::setOverrideCursor(Qt::WaitCursor);
    QTextStream stream(&file);
    // CORRECTION: setCodec est retiré. L'encodage UTF-8 est souvent le défaut avec QFile::Text.
    // stream.setCodec("UTF-8"); // << LIGNE SUPPRIMÉE
    stream.setGenerateByteOrderMark(true); // Garder le BOM pour aider Excel

    // Écrire l'en-tête
    QStringList headers;
    for (int col = 0; col < standingsTableWidget->columnCount(); ++col) {
        if(standingsTableWidget->horizontalHeaderItem(col)) { // Vérifier si l'item existe
            headers << escapeCsvValue(standingsTableWidget->horizontalHeaderItem(col)->text());
        } else {
            headers << ""; // Colonne sans titre ?
        }
    }
    stream << headers.join(';') << "\n"; // Utiliser le point-virgule

    // Écrire les données
    for (int row = 0; row < standingsTableWidget->rowCount(); ++row) {
        QStringList rowData;
        for (int col = 0; col < standingsTableWidget->columnCount(); ++col) {
            QTableWidgetItem *item = standingsTableWidget->item(row, col);
            rowData << escapeCsvValue(item ? item->text() : "");
        }
        stream << rowData.join(';') << "\n";
    }

    file.close();
    QApplication::restoreOverrideCursor();

    if (stream.status() != QTextStream::Ok || file.error() != QFile::NoError) { // Vérifier aussi l'erreur du fichier
        QMessageBox::critical(this, "Erreur Export CSV", QString("Une erreur est survenue lors de l'écriture dans le fichier '%1'.").arg(QDir::toNativeSeparators(fileName)));
    } else {
        QMessageBox::information(this, "Export CSV Réussi", QString("Le classement a été exporté avec succès dans le fichier:\n%1").arg(QDir::toNativeSeparators(fileName)));
    }
}

// Fonction helper pour échapper les valeurs CSV
QString StandingsWidget::escapeCsvValue(const QString &value) {
    if (value.contains(';') || value.contains('"') || value.contains('\n') || value.contains('\r')) {
        QString escaped = value;
        escaped.replace("\"", "\"\"");
        return "\"" + escaped + "\"";
    }
    return value;
}


// Fonction principale qui appelle le calcul et l'affichage
void StandingsWidget::calculateAndDisplayStandings() {
    m_currentStandings = calculateStandingsLogic();
    displayStandingsInTable(m_currentStandings);
}

// Logique de calcul du classement
QList<TeamStats> StandingsWidget::calculateStandingsLogic() {
    QMap<int, TeamStats> statsMap;

    if (!m_connection || !m_connection->database().isOpen()) {
        qWarning() << "calculateStandingsLogic: Connexion DB non disponible.";
        return {};
    }
    QSqlDatabase db = m_connection->database();

    // 1. Récupérer toutes les équipes
    QSqlQuery teamQuery(db);
    if (teamQuery.exec("SELECT id_equipe, nom FROM equipes")) { // Table EQUIPES
        while (teamQuery.next()) {
            int teamId = teamQuery.value(0).toInt();
            if (teamId < 0) continue;
            statsMap[teamId].teamId = teamId;
            statsMap[teamId].teamName = teamQuery.value(1).toString();
        }
    } else {
        qWarning() << "Erreur récupération des équipes pour le classement:" << teamQuery.lastError().text();
        QMessageBox::critical(this, "Erreur Calcul Classement", "Impossible de récupérer la liste des équipes.");
        return {};
    }
    if (statsMap.isEmpty()) {
        qWarning() << "Aucune équipe trouvée dans la base de données pour le classement.";
        return {};
    }

    // 2. Récupérer tous les matchs terminés
    QSqlQuery matchQuery(db);
    QString sql = "SELECT id_equipe_domicile, id_equipe_exterieur, score_domicile, score_exterieur "
                  "FROM MATCHS " // Table MATCHS
                  "WHERE score_domicile IS NOT NULL AND score_exterieur IS NOT NULL";
    if (matchQuery.exec(sql)) {
        while (matchQuery.next()) {
            int homeId = matchQuery.value(0).toInt();
            int awayId = matchQuery.value(1).toInt();
            int homeScore = matchQuery.value(2).toInt();
            int awayScore = matchQuery.value(3).toInt();

            if (statsMap.contains(homeId) && statsMap.contains(awayId)) {
                // Domicile
                statsMap[homeId].played++;
                statsMap[homeId].goalsFor += homeScore;
                statsMap[homeId].goalsAgainst += awayScore;
                // Extérieur
                statsMap[awayId].played++;
                statsMap[awayId].goalsFor += awayScore;
                statsMap[awayId].goalsAgainst += homeScore;
                // Résultat
                if (homeScore > awayScore) { statsMap[homeId].wins++; statsMap[homeId].points += 3; statsMap[awayId].losses++; }
                else if (homeScore < awayScore) { statsMap[awayId].wins++; statsMap[awayId].points += 3; statsMap[homeId].losses++; }
                else { statsMap[homeId].draws++; statsMap[homeId].points += 1; statsMap[awayId].draws++; statsMap[awayId].points += 1; }
            } else {
                qWarning() << "Match ignoré car une des équipes (ID" << homeId << "ou ID" << awayId << ") n'a pas été trouvée.";
            }
        }
    } else {
        qWarning() << "Erreur récupération des matchs pour le classement:" << matchQuery.lastError().text();
        QMessageBox::critical(this, "Erreur Calcul Classement", "Impossible de récupérer les résultats des matchs.");
    }

    // 3. Calculer la différence de buts
    for (auto it = statsMap.begin(); it != statsMap.end(); ++it) {
        it.value().goalDifference = it.value().goalsFor - it.value().goalsAgainst;
    }

    // 4. Convertir la map en liste pour le tri
    QList<TeamStats> standingsList = statsMap.values();

    // 5. Trier la liste
    std::sort(standingsList.begin(), standingsList.end(), [](const TeamStats &a, const TeamStats &b) {
        if (a.points != b.points) return a.points > b.points;
        if (a.goalDifference != b.goalDifference) return a.goalDifference > b.goalDifference;
        if (a.goalsFor != b.goalsFor) return a.goalsFor > b.goalsFor;
        return a.teamName.compare(b.teamName, Qt::CaseInsensitive) < 0;
    });

    return standingsList;
}

// Remplit le tableau avec les données triées
void StandingsWidget::displayStandingsInTable(const QList<TeamStats>& standings) {
    if (!standingsTableWidget) return;

    standingsTableWidget->setRowCount(0);
    standingsTableWidget->setSortingEnabled(false);

    int rank = 1;
    for (const TeamStats &stats : standings) {
        int row = standingsTableWidget->rowCount();
        standingsTableWidget->insertRow(row);

        auto createItem = [&](const QVariant &value, Qt::Alignment align = Qt::AlignCenter) {
            QTableWidgetItem *item = new QTableWidgetItem();
            if (value.typeId() == QMetaType::Int || value.typeId() == QMetaType::Double) {
                item->setData(Qt::DisplayRole, value);
            } else {
                item->setText(value.toString());
            }
            item->setTextAlignment(align);
            item->setFlags(item->flags() & ~Qt::ItemIsEditable);
            return item;
        };

        standingsTableWidget->setItem(row, 0, createItem(rank++));
        standingsTableWidget->setItem(row, 1, createItem(stats.teamName, Qt::AlignLeft | Qt::AlignVCenter));
        standingsTableWidget->setItem(row, 2, createItem(stats.played));
        standingsTableWidget->setItem(row, 3, createItem(stats.wins));
        standingsTableWidget->setItem(row, 4, createItem(stats.draws));
        standingsTableWidget->setItem(row, 5, createItem(stats.losses));
        standingsTableWidget->setItem(row, 6, createItem(stats.goalsFor));
        standingsTableWidget->setItem(row, 7, createItem(stats.goalsAgainst));
        QString diffStr = QString::number(stats.goalDifference);
        if (stats.goalDifference > 0) diffStr.prepend('+');
        standingsTableWidget->setItem(row, 8, createItem(diffStr));
        QTableWidgetItem *pointsItem = createItem(stats.points);
        QFont font = pointsItem->font(); font.setBold(true);
        pointsItem->setFont(font);
        standingsTableWidget->setItem(row, 9, pointsItem);
    }

    standingsTableWidget->setSortingEnabled(true);
}
