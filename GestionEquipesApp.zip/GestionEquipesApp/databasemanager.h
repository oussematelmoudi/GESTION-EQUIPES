// databasemanager.h
#ifndef DATABASEMANAGER_H
#define DATABASEMANAGER_H

#include <QObject>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QList>
#include <QString>

// Includes directs car fichiers dans le même dossier
#include "equipe.h"
#include "joueur.h"
#include "coach.h"

class DatabaseManager : public QObject {
    Q_OBJECT
public:
    explicit DatabaseManager(QObject *parent = nullptr);
    ~DatabaseManager();
    bool openDatabase();
    void closeDatabase();
    bool isConnected() const;
    // CRUD Equipe
    bool addEquipe(Equipe &equipe);
    Equipe getEquipeById(int id);
    QList<Equipe> getAllEquipes();
    bool updateEquipe(const Equipe &equipe);
    bool deleteEquipe(int id);
    // Effectif Equipe
    QList<int> getEquipeJoueurIds(int equipeId);
    bool updateEquipeEffectif(int equipeId, const QList<int> &newJoueurIds);
    // CRUD Joueur (Placeholders)
    bool addJoueur(Joueur &joueur);
    Joueur getJoueurById(int id);
    QList<Joueur> getAllJoueurs();
    bool updateJoueur(const Joueur &joueur);
    bool deleteJoueur(int id);
    // CRUD Coach (Placeholders)
    bool addCoach(Coach &coach);
    Coach getCoachById(int id);
    QList<Coach> getAllCoaches();
    bool updateCoach(const Coach &coach);
    bool deleteCoach(int id);
signals:
    void errorOccurred(const QString &errorMsg);
private:
    QSqlDatabase m_db;
    bool executeQuery(QSqlQuery &query, const QString &queryString = "");
};
#endif // DATABASEMANAGER_H
