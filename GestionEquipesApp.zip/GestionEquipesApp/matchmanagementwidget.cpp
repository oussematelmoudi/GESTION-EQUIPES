// matchmanagementwidget.cpp
#include "matchmanagementwidget.h"

// Includes Qt nécessaires
#include <QApplication> // Pour le curseur d'attente
#include <QTableWidget>
#include <QPushButton>
#include <QComboBox>
#include <QLabel>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QFormLayout>
#include <QDateEdit>
#include <QSpinBox>
#include <QLineEdit>
#include <QCalendarWidget>
#include <QHeaderView>
#include <QMessageBox>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QVariant>
#include <stdexcept> // Pour std::runtime_error

// Constructeur
MatchManagementWidget::MatchManagementWidget(Connection *connection, QWidget *parent) :
    QWidget(parent),
    m_connection(connection)
{
    if (!m_connection) {
        qCritical() << "FATAL: MatchManagementWidget a reçu un pointeur Connection nul!";
    }

    setupUi();
    connectSignalsSlots();

    // Charger les données initiales si la connexion est prête
    if (m_connection && m_connection->database().isOpen()) {
        refreshAll(); // Charge équipes et matchs au démarrage
    } else {
        qWarning() << "Connexion DB non disponible lors de l'initialisation de MatchManagementWidget.";
        QMessageBox::warning(this, "Connexion Base de Données",
                             "La connexion à la base de données n'est pas disponible.\n"
                             "Les données des matchs ne peuvent pas être gérées.");
        // Désactiver les contrôles
        addMatchGroupBox->setEnabled(false);
        historyGroupBox->setEnabled(false);
    }
}

// Crée et arrange les widgets de l'interface
void MatchManagementWidget::setupUi() {
    mainLayout = new QHBoxLayout(this); // Layout principal Horizontal
    leftLayout = new QVBoxLayout();
    rightLayout = new QVBoxLayout();

    // --- Section Gauche : Formulaire Ajout Match ---
    addMatchGroupBox = new QGroupBox("Enregistrer un Nouveau Match", this);
    addMatchFormLayout = new QFormLayout(addMatchGroupBox);

    homeTeamLabel = new QLabel("Équipe Domicile:", addMatchGroupBox);
    homeTeamComboBox = new QComboBox(addMatchGroupBox);
    awayTeamLabel = new QLabel("Équipe Extérieur:", addMatchGroupBox);
    awayTeamComboBox = new QComboBox(addMatchGroupBox);
    homeScoreLabel = new QLabel("Score Domicile:", addMatchGroupBox);
    homeScoreSpinBox = new QSpinBox(addMatchGroupBox);
    homeScoreSpinBox->setRange(0, 99); // Score max raisonnable
    awayScoreLabel = new QLabel("Score Extérieur:", addMatchGroupBox);
    awayScoreSpinBox = new QSpinBox(addMatchGroupBox);
    awayScoreSpinBox->setRange(0, 99);
    dateLabel = new QLabel("Date Match:", addMatchGroupBox);
    matchDateEdit = new QDateEdit(QDate::currentDate(), addMatchGroupBox);
    matchDateEdit->setCalendarPopup(true);
    matchDateEdit->setDisplayFormat("dd/MM/yyyy");
    locationLabel = new QLabel("Lieu:", addMatchGroupBox);
    locationLineEdit = new QLineEdit(addMatchGroupBox);

    saveMatchButton = new QPushButton("Enregistrer Match", addMatchGroupBox);

    addMatchFormLayout->addRow(homeTeamLabel, homeTeamComboBox);
    addMatchFormLayout->addRow(awayTeamLabel, awayTeamComboBox);
    addMatchFormLayout->addRow(homeScoreLabel, homeScoreSpinBox);
    addMatchFormLayout->addRow(awayScoreLabel, awayScoreSpinBox);
    addMatchFormLayout->addRow(dateLabel, matchDateEdit);
    addMatchFormLayout->addRow(locationLabel, locationLineEdit);
    addMatchFormLayout->addRow(saveMatchButton);

    leftLayout->addWidget(addMatchGroupBox);
    leftLayout->addStretch(); // Pousse le formulaire vers le haut

    // --- Section Droite : Historique ---
    historyGroupBox = new QGroupBox("Historique des Matchs", this);
    historyVBoxLayout = new QVBoxLayout(historyGroupBox);

    matchTableWidget = new QTableWidget(historyGroupBox);
    matchTableWidget->setColumnCount(6); // ID, Date, Domicile, Score, Extérieur, Lieu
    matchTableWidget->setHorizontalHeaderLabels({"ID", "Date", "Domicile", "Score", "Extérieur", "Lieu"});
    matchTableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    matchTableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    matchTableWidget->setColumnWidth(0, 50); // ID
    matchTableWidget->setColumnWidth(1, 80); // Date
    matchTableWidget->setColumnWidth(3, 60); // Score
    matchTableWidget->horizontalHeader()->setSectionResizeMode(2, QHeaderView::Stretch); // Domicile
    matchTableWidget->horizontalHeader()->setSectionResizeMode(4, QHeaderView::Stretch); // Extérieur
    matchTableWidget->horizontalHeader()->setSectionResizeMode(5, QHeaderView::Stretch); // Lieu
    matchTableWidget->setAlternatingRowColors(true); // Améliore lisibilité
    matchTableWidget->setSortingEnabled(true); // Activer tri par colonne

    refreshButton = new QPushButton("Rafraîchir l'Historique", historyGroupBox);

    historyVBoxLayout->addWidget(matchTableWidget);
    historyVBoxLayout->addWidget(refreshButton);

    rightLayout->addWidget(historyGroupBox);

    // --- Assemblage Final ---
    mainLayout->addLayout(leftLayout, 1);  // Formulaire prend 1 part
    mainLayout->addLayout(rightLayout, 2); // Liste prend 2 parts
}

// Connecte les signaux des widgets UI aux slots
void MatchManagementWidget::connectSignalsSlots() {
    connect(saveMatchButton, &QPushButton::clicked, this, &MatchManagementWidget::saveNewMatch);
    connect(refreshButton, &QPushButton::clicked, this, &MatchManagementWidget::refreshAll); // Rafraîchit tout
}

// --- Implémentation des Slots ---

// Recharge toutes les données nécessaires
void MatchManagementWidget::refreshAll() {
    if (!m_connection || !m_connection->database().isOpen()) {
        QMessageBox::warning(this, "Connexion Base de Données", "La connexion n'est pas disponible pour rafraîchir.");
        return;
    }
    QApplication::setOverrideCursor(Qt::WaitCursor);
    loadTeamsCache();       // Recharge le cache équipes
    populateTeamCombos();   // Remplit les ComboBox équipes
    loadMatchesList();      // Recharge la table de l'historique
    QApplication::restoreOverrideCursor();
}

// Enregistre un nouveau match
void MatchManagementWidget::saveNewMatch() {
    if (!m_connection || !m_connection->database().isOpen()) {
        QMessageBox::critical(this, "Erreur", "Connexion à la base de données non disponible.");
        return;
    }

    // Récupérer les données du formulaire
    int homeTeamId = homeTeamComboBox->currentData().toInt();
    int awayTeamId = awayTeamComboBox->currentData().toInt();
    int homeScore = homeScoreSpinBox->value();
    int awayScore = awayScoreSpinBox->value();
    QDate matchDate = matchDateEdit->date();
    QString location = locationLineEdit->text().trimmed();

    // Validations
    if (homeTeamId < 0 || awayTeamId < 0) {
        QMessageBox::warning(this, "Données Manquantes", "Veuillez sélectionner les deux équipes.");
        return;
    }
    if (homeTeamId == awayTeamId) {
        QMessageBox::warning(this, "Données Invalides", "L'équipe à domicile et l'équipe extérieure doivent être différentes.");
        return;
    }
    if (!matchDate.isValid()) {
        QMessageBox::warning(this, "Données Invalides", "Veuillez entrer une date de match valide.");
        matchDateEdit->setFocus();
        return;
    }

    // --- Logique d'Insertion (pas besoin de transaction pour un simple INSERT ici) ---
    QSqlDatabase db = m_connection->database();
    bool success = false;

    // Pas besoin de transaction complexe ici, mais on pourrait en ajouter si
    // d'autres tables devaient être mises à jour en même temps.
    // if (!db.transaction()) { ... }

    QApplication::setOverrideCursor(Qt::WaitCursor);

    try {
        QSqlQuery query(db);

        // 1. Obtenir le nouvel ID pour le match (Syntaxe Oracle !)
        // !!! ATTENTION : Adapter si DB != Oracle !!!
        query.prepare("SELECT match_seq.NEXTVAL FROM DUAL");
        if (!query.exec()) throw std::runtime_error("Erreur obtention ID match: " + query.lastError().text().toStdString());
        int newMatchId = -1;
        if (query.next()) newMatchId = query.value(0).toInt();
        else throw std::runtime_error("Impossible de récupérer le nouvel ID match.");

        // 2. Insérer dans la table MATCHS
        query.prepare("INSERT INTO matchs (id_match, date_match, id_equipe_domicile, id_equipe_exterieur, "
                      "score_domicile, score_exterieur, lieu) "
                      "VALUES (:id, :datem, :idom, :iext, :sdom, :sext, :lieu)");
        query.bindValue(":id", newMatchId);
        query.bindValue(":datem", matchDate);
        query.bindValue(":idom", homeTeamId);
        query.bindValue(":iext", awayTeamId);
        query.bindValue(":sdom", homeScore);
        query.bindValue(":sext", awayScore);
        query.bindValue(":lieu", location.isEmpty() ? QVariant() : location); // Gère lieu NULL/vide

        if (!query.exec()) throw std::runtime_error("Erreur insertion match: " + query.lastError().text().toStdString());

        // Pas besoin de commit explicite si autocommit est activé (défaut pour beaucoup de drivers)
        // ou si on n'a pas démarré de transaction manuellement.
        // if (!db.commit()) { throw ... }

        success = true;
        QMessageBox::information(this, "Succès", "Match enregistré avec succès.");

    } catch (const std::runtime_error &e) {
        qWarning() << "Erreur lors de l'enregistrement du match..." << e.what();
        // db.rollback(); // Pas nécessaire si pas de transaction explicite démarrée
        QMessageBox::critical(this, "Erreur Enregistrement", QString("L'opération a échoué: %1").arg(e.what()));
        success = false;
    }

    QApplication::restoreOverrideCursor();

    // Recharger la liste des matchs et vider le formulaire si succès
    if (success) {
        loadMatchesList();
        clearAddForm();
    }
}


// --- Implémentation des Fonctions Privées ---

// Charge la liste des matchs depuis la DB et remplit la table UI
void MatchManagementWidget::loadMatchesList() {
    if (!m_connection || !m_connection->database().isOpen()) {
        qWarning() << "loadMatchesList: Connexion DB non disponible.";
        matchTableWidget->setRowCount(0);
        return;
    }
    matchTableWidget->setRowCount(0); // Vide avant de remplir
    matchTableWidget->setSortingEnabled(false); // Désactiver tri pendant remplissage
    QApplication::setOverrideCursor(Qt::WaitCursor);

    QSqlDatabase db = m_connection->database();
    QSqlQuery query(db);
    // Requête avec jointures pour obtenir les noms des équipes
    QString sql = "SELECT m.id_match, m.date_match, "
                  "eq_d.nom AS domicile_nom, "
                  "m.score_domicile, m.score_exterieur, "
                  "eq_e.nom AS exterieur_nom, "
                  "m.lieu "
                  "FROM MATCHS m "
                  "LEFT JOIN EQUIPES eq_d ON m.id_equipe_domicile = eq_d.id_equipe "
                  "LEFT JOIN EQUIPES eq_e ON m.id_equipe_exterieur = eq_e.id_equipe "
                  "ORDER BY m.date_match DESC, m.id_match DESC"; // Tri

    if (query.exec(sql)) {
        int row = 0;
        while (query.next()) {
            matchTableWidget->insertRow(row);

            // ID Match (Col 0)
            QTableWidgetItem *idItem = new QTableWidgetItem(query.value(0).toString());
            idItem->setFlags(idItem->flags() & ~Qt::ItemIsEditable);

            // Date (Col 1)
            QTableWidgetItem *dateItem = new QTableWidgetItem(query.value(1).toDate().toString("dd/MM/yyyy"));
            dateItem->setFlags(dateItem->flags() & ~Qt::ItemIsEditable);

            // Domicile (Col 2)
            QString homeName = query.value(2).isNull() ? "???" : query.value(2).toString();
            QTableWidgetItem *homeItem = new QTableWidgetItem(homeName);
            homeItem->setFlags(homeItem->flags() & ~Qt::ItemIsEditable);

            // Score (Col 3) - Formaté
            QVariant homeScore = query.value(3);
            QVariant awayScore = query.value(4);
            QString scoreText = (homeScore.isNull() || awayScore.isNull()) ?
                                    "N/A" :
                                    QString("%1 - %2").arg(homeScore.toInt()).arg(awayScore.toInt());
            QTableWidgetItem *scoreItem = new QTableWidgetItem(scoreText);
            scoreItem->setTextAlignment(Qt::AlignCenter);
            scoreItem->setFlags(scoreItem->flags() & ~Qt::ItemIsEditable);

            // Extérieur (Col 4)
            QString awayName = query.value(5).isNull() ? "???" : query.value(5).toString();
            QTableWidgetItem *awayItem = new QTableWidgetItem(awayName);
            awayItem->setFlags(awayItem->flags() & ~Qt::ItemIsEditable);

            // Lieu (Col 5)
            QTableWidgetItem *locationItem = new QTableWidgetItem(query.value(6).toString());
            locationItem->setFlags(locationItem->flags() & ~Qt::ItemIsEditable);


            // Ajouter les items à la ligne
            matchTableWidget->setItem(row, 0, idItem);
            matchTableWidget->setItem(row, 1, dateItem);
            matchTableWidget->setItem(row, 2, homeItem);
            matchTableWidget->setItem(row, 3, scoreItem);
            matchTableWidget->setItem(row, 4, awayItem);
            matchTableWidget->setItem(row, 5, locationItem);

            row++;
        }
        matchTableWidget->setRowCount(row); // Ajuster la taille finale
    } else {
        qWarning() << "Erreur chargement historique matchs:" << query.lastError().text();
        QMessageBox::critical(this, "Erreur Chargement", "Impossible de charger l'historique des matchs.\n" + query.lastError().text());
    }

    matchTableWidget->setSortingEnabled(true); // Réactiver le tri
    // Pas de resizeColumnsToContents ici pour garder les largeurs définies et stretch
    // matchTableWidget->resizeColumnsToContents();
    QApplication::restoreOverrideCursor();
}

// Charge les équipes depuis la DB dans le cache m_allTeams
void MatchManagementWidget::loadTeamsCache() {
    if (!m_connection || !m_connection->database().isOpen()) {
        qWarning() << "loadTeamsCache (Match): Connexion DB non disponible.";
        m_allTeams.clear(); return;
    }
    m_allTeams.clear();
    QSqlDatabase db = m_connection->database();
    QSqlQuery query(db);
    if(query.exec("SELECT id_equipe, nom FROM equipes ORDER BY nom")) {
        while(query.next()) {
            Equipe equipe;
            equipe.setId(query.value(0).toInt());
            equipe.setNom(query.value(1).toString());
            m_allTeams.append(equipe);
        }
        qInfo() << "Cache équipes (Match) rechargé:" << m_allTeams.count() << "équipes.";
    } else {
        qWarning() << "Erreur rechargement cache équipes (Match):" << query.lastError().text();
    }
}

// Remplit les ComboBox Équipe à partir du cache
void MatchManagementWidget::populateTeamCombos() {
    homeTeamComboBox->clear();
    awayTeamComboBox->clear();

    homeTeamComboBox->addItem("Sélectionner Équipe...", -1); // Invite
    awayTeamComboBox->addItem("Sélectionner Équipe...", -1); // Invite

    for (const Equipe &team : m_allTeams) {
        QString itemText = QString("%1 (ID:%2)").arg(team.getNom()).arg(team.getId());
        homeTeamComboBox->addItem(itemText, team.getId());
        awayTeamComboBox->addItem(itemText, team.getId());
    }
}

// Réinitialise le formulaire d'ajout de match
void MatchManagementWidget::clearAddForm() {
    homeTeamComboBox->setCurrentIndex(0); // Sélectionne l'invite
    awayTeamComboBox->setCurrentIndex(0); // Sélectionne l'invite
    homeScoreSpinBox->setValue(0);
    awayScoreSpinBox->setValue(0);
    matchDateEdit->setDate(QDate::currentDate());
    locationLineEdit->clear();
    homeTeamComboBox->setFocus(); // Focus sur le premier champ
}
