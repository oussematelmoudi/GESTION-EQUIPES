// performancewidget.h (Corrigé)
#ifndef PERFORMANCEWIDGET_H
#define PERFORMANCEWIDGET_H

#include <QWidget>
#include <QList>

// Includes spécifiques Qt Charts
#include <QtCharts/QChartView>
#include <QtCharts/QChart>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QValueAxis>
#include <QtCharts/QBarCategoryAxis>
#include <QtCharts/QLegend>

// << CORRECTION: Utilisation du namespace pour éviter les erreurs >>

    // Alternative: Ne pas mettre cette ligne et préfixer QChartView, QChart, etc. avec QtCharts::

    // Forward declarations Qt (pour les autres widgets)
    class QComboBox; class QPushButton; class QLabel; class QGroupBox;
class QVBoxLayout; class QGridLayout; class QSpacerItem; class QHBoxLayout;

// Includes directs des classes du projet
#include "equipe.h"
#include "connection.h"

class PerformanceWidget : public QWidget
{
    Q_OBJECT

public:
    explicit PerformanceWidget(Connection *connection, QWidget *parent = nullptr);
    ~PerformanceWidget();

private slots:
    void analyzeSelectedTeam();
    void refreshTeamList();
    void clearStatsOnTeamChange(int index);

private:
    // Widgets et Layouts membres
    QVBoxLayout *mainLayout;
    QHBoxLayout *selectionLayout;
    QLabel *selectTeamLabel;
    QComboBox *teamComboBox;
    QPushButton *analyzeButton;
    QPushButton *refreshTeamsButton;
    QGroupBox *statsGroupBox;
    QGridLayout *statsLayout;
    QLabel *matchesPlayedLabel, *matchesPlayedValue;
    QLabel *winsLabel,          *winsValue;
    QLabel *drawsLabel,         *drawsValue;
    QLabel *lossesLabel,        *lossesValue;
    QLabel *goalsForLabel,      *goalsForValue;
    QLabel *goalsAgainstLabel,  *goalsAgainstValue;
    QLabel *goalDiffLabel,      *goalDiffValue;
    QGroupBox *chartGroupBox;
    QVBoxLayout *chartLayout;
    // Plus besoin de préfixe si QT_CHARTS_USE_NAMESPACE est utilisé ci-dessus
    QChartView *statsChartView;
    QChart *chart;

    // Données membres
    Connection *m_connection;
    QList<Equipe> m_allTeams;

    // Méthodes privées
    void setupUi();
    void setupChart();
    void connectSignalsSlots();
    void loadTeamsCache();
    void populateTeamCombo();
    void updateChart(int wins, int draws, int losses, int teamId); // Garde 4 paramètres
    void clearStatsDisplay();

};

#endif // PERFORMANCEWIDGET_H
