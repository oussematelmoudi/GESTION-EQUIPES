// teammanagementwidget.h (Utilise Connection)
#ifndef TEAMMANAGEMENTWIDGET_H
#define TEAMMANAGEMENTWIDGET_H

#include <QWidget>
#include <QListWidgetItem>
// Inclure les headers Qt SQL nécessaires car les requêtes sont faites ici
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QVariant> // Pour QVariant() utilisé dans bindValue

// Forward declarations des widgets Qt utilisés pour alléger les includes ici
class QPushButton; class QLineEdit; class QLabel; class QSpinBox; class QComboBox;
class QListWidget; class QGroupBox; class QHBoxLayout; class QVBoxLayout;
class QFormLayout; class QTableWidget; class QTableWidgetItem;

// Includes directs des classes du projet
#include "equipe.h"
#include "joueur.h"
#include "coach.h"
#include "connection.h" // Utilise la classe Connection

class TeamManagementWidget : public QWidget {
    Q_OBJECT
public:
    // Constructeur prend un pointeur vers l'objet Connection
    explicit TeamManagementWidget(Connection *connection, QWidget *parent = nullptr);

private slots:
    // Slots pour les actions de l'utilisateur
    void refreshTeamList();
    void teamSelectionChanged();
    void prepareNewTeam();
    void saveTeamData(); // Contient maintenant la logique INSERT/UPDATE
    void deleteSelectedTeam(); // Contient maintenant la logique DELETE
    void addPlayersToTeamRoster(); // Logique UI seulement
    void removePlayersFromTeamRoster(); // Logique UI seulement

private:
    // --- Widgets et Layouts membres ---
    QHBoxLayout *mainLayout; QVBoxLayout *leftLayout; QVBoxLayout *rightLayout;
    QGroupBox *leftGroupBox; QVBoxLayout *leftVboxLayout; QTableWidget *teamTableWidget; QPushButton *refreshButton;
    QGroupBox *detailsGroupBox; QFormLayout *detailsFormLayout; QLabel *idLabelInfo; QLabel *idLabelValue;
    QLabel *nameLabel; QLineEdit *nameLineEdit; QLabel *rankLabel; QSpinBox *rankSpinBox; QLabel *coachLabel; QComboBox *coachComboBox;
    QGroupBox *rosterGroupBox; QHBoxLayout *rosterHBoxLayout; QVBoxLayout *availablePlayersVLayout; QLabel *availablePlayersLabel;
    QListWidget *availablePlayersListWidget; QVBoxLayout *addRemoveVLayout; QPushButton *addButton; QPushButton *removeButton;
    QVBoxLayout *teamPlayersVLayout; QLabel *teamPlayersLabel; QListWidget *teamPlayersListWidget;
    QHBoxLayout *actionButtonsLayout; QPushButton *newButton; QPushButton *saveButton; QPushButton *deleteButton;

    // --- Méthodes privées ---
    void setupUi(); // Crée l'interface
    void connectSignalsSlots(); // Connecte les signaux UI aux slots
    // Fonctions principales contenant maintenant la logique SQL
    void loadTeamsList();
    void loadAvailablePlayers(); // Charge le cache m_allPlayers
    void loadAvailableCoaches(); // Charge le cache m_allCoaches
    void populateTeamDetails(int teamId);
    // Fonctions UI
    void clearForm();
    Equipe getCurrentFormData(); // Récupère les données du formulaire UI
    void updatePlayerLists(const QList<int> &teamPlayerIds); // Met à jour les listes UI
    // Fonctions helper pour la logique DB spécifique à ce widget
    QList<int> getEquipeJoueurIdsFromDb(int equipeId);
    bool updateEquipeEffectifInDb(int equipeId, const QList<int> &newJoueurIds, QSqlDatabase& db); // Nécessite la connexion DB active

    // --- Données membres ---
    Connection *m_connection; // Pointeur vers l'objet Connection principal
    int m_currentTeamId;      // ID de l'équipe sélectionnée/éditée (-1 si nouvelle)
    QList<Joueur> m_allPlayers; // Cache des joueurs chargés depuis la DB
    QList<Coach> m_allCoaches; // Cache des coachs chargés depuis la DB
};
#endif // TEAMMANAGEMENTWIDGET_H
