// playermanagementwidget.cpp (Corrigé avec préfixes, includes, et -Wreorder)
#include "playermanagementwidget.h"

// Includes Qt nécessaires
#include <QApplication>
#include <QTableWidget>
#include <QPushButton>
#include <QLineEdit>
#include <QLabel>
#include <QDateEdit>
#include <QSpinBox>
#include <QComboBox>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QFormLayout>
#include <QHeaderView>
#include <QMessageBox>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QVariant>
#include <stdexcept> // Gardé car utilisé

// Constante
const int NO_TEAM_ID_PLAYER = -1;

// Constructeur (avec liste d'initialisation réordonnée pour correspondre au .h reconstruit)
PlayerManagementWidget::PlayerManagementWidget(Connection *connection, QWidget *parent) :
    QWidget(parent),
    // Initialiser les widgets pointeurs à nullptr
    mainLayout(nullptr), leftLayout(nullptr), rightLayout(nullptr), listGroupBox(nullptr),
    listVBoxLayout(nullptr), playerTableWidget(nullptr), refreshButton(nullptr), detailsGroupBox(nullptr),
    detailsFormLayout(nullptr), idLabelInfo(nullptr), idLabelValue(nullptr), nameLabel(nullptr),
    nameLineEdit(nullptr), firstNameLabel(nullptr), firstNameLineEdit(nullptr), birthDateLabel(nullptr),
    birthDateEdit(nullptr), positionLabel(nullptr), positionLineEdit(nullptr), jerseyNumberLabel(nullptr),
    jerseyNumberSpinBox(nullptr), currentTeamLabel(nullptr), currentTeamComboBox(nullptr),
    actionButtonsLayout(nullptr), newButton(nullptr), saveButton(nullptr), deleteButton(nullptr),
    // Initialiser les membres de données (l'ordre ici est moins critique que la déclaration)
    m_connection(connection),
    m_currentPlayerId(-1),
    m_currentPlayerOldTeamId(NO_TEAM_ID_PLAYER)
// m_allTeams est initialisé par défaut
{
    if (!m_connection) {
        qCritical() << "FATAL: PlayerManagementWidget a reçu un pointeur Connection nul!";
        setEnabled(false);
    }

    setupUi();
    connectSignalsSlots();

    if (m_connection && m_connection->database().isOpen()) {
        loadTeamsCache();
        populateTeamCombo();
        loadPlayersList();
    } else {
        // Tenter de connecter
        if (m_connection && m_connection->createconnect()) {
            loadTeamsCache();
            populateTeamCombo();
            loadPlayersList();
        } else {
            qWarning() << "Connexion DB non disponible lors de l'initialisation de PlayerManagementWidget.";
            QMessageBox::warning(this, "Connexion Base de Données",
                                 "La connexion à la base de données n'est pas disponible.\n"
                                 "Les données des joueurs ne peuvent pas être gérées.");
            if(detailsGroupBox) detailsGroupBox->setEnabled(false);
            if(listGroupBox) listGroupBox->setEnabled(false);
            if(saveButton) saveButton->setEnabled(false);
            if(deleteButton) deleteButton->setEnabled(false);
            if(refreshButton) refreshButton->setEnabled(false);
        }
    }
    clearForm();
}

// --- Définitions des méthodes membres (AVEC PRÉFIXES) ---

void PlayerManagementWidget::setupUi() {
    mainLayout = new QHBoxLayout(this);
    leftLayout = new QVBoxLayout();
    rightLayout = new QVBoxLayout();

    listGroupBox = new QGroupBox("Joueurs Existants", this);
    listVBoxLayout = new QVBoxLayout(listGroupBox);
    playerTableWidget = new QTableWidget(listGroupBox);
    playerTableWidget->setColumnCount(6);
    playerTableWidget->setHorizontalHeaderLabels({"ID", "Nom", "Prénom", "Position", "N°", "Équipe Actuelle"});
    playerTableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    playerTableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    playerTableWidget->setColumnWidth(0, 40);
    playerTableWidget->setColumnWidth(4, 40);
    playerTableWidget->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch);
    playerTableWidget->horizontalHeader()->setSectionResizeMode(2, QHeaderView::Stretch);
    playerTableWidget->horizontalHeader()->setSectionResizeMode(5, QHeaderView::Stretch);
    playerTableWidget->setAlternatingRowColors(true);
    playerTableWidget->setSortingEnabled(true);
    refreshButton = new QPushButton("Rafraîchir Liste", listGroupBox);
    listVBoxLayout->addWidget(playerTableWidget);
    listVBoxLayout->addWidget(refreshButton);
    leftLayout->addWidget(listGroupBox);

    detailsGroupBox = new QGroupBox("Détails du Joueur", this);
    detailsFormLayout = new QFormLayout(detailsGroupBox);
    idLabelInfo = new QLabel("ID:", detailsGroupBox);
    idLabelValue = new QLabel("N/A", detailsGroupBox);
    nameLabel = new QLabel("Nom:", detailsGroupBox);
    nameLineEdit = new QLineEdit(detailsGroupBox);
    firstNameLabel = new QLabel("Prénom:", detailsGroupBox);
    firstNameLineEdit = new QLineEdit(detailsGroupBox);
    birthDateLabel = new QLabel("Date Naissance:", detailsGroupBox);
    birthDateEdit = new QDateEdit(detailsGroupBox);
    birthDateEdit->setCalendarPopup(true);
    birthDateEdit->setDisplayFormat("dd/MM/yyyy");
    birthDateEdit->setDate(QDate::currentDate().addYears(-20));
    birthDateEdit->setMinimumDate(QDate(1950, 1, 1));
    birthDateEdit->setMaximumDate(QDate::currentDate().addYears(-15));
    positionLabel = new QLabel("Position:", detailsGroupBox);
    positionLineEdit = new QLineEdit(detailsGroupBox);
    jerseyNumberLabel = new QLabel("Numéro Maillot:", detailsGroupBox);
    jerseyNumberSpinBox = new QSpinBox(detailsGroupBox);
    jerseyNumberSpinBox->setRange(0, 99);
    currentTeamLabel = new QLabel("Équipe Actuelle:", detailsGroupBox);
    currentTeamComboBox = new QComboBox(detailsGroupBox);

    detailsFormLayout->addRow(idLabelInfo, idLabelValue);
    detailsFormLayout->addRow(nameLabel, nameLineEdit);
    detailsFormLayout->addRow(firstNameLabel, firstNameLineEdit);
    detailsFormLayout->addRow(birthDateLabel, birthDateEdit);
    detailsFormLayout->addRow(positionLabel, positionLineEdit);
    detailsFormLayout->addRow(jerseyNumberLabel, jerseyNumberSpinBox);
    detailsFormLayout->addRow(currentTeamLabel, currentTeamComboBox);
    rightLayout->addWidget(detailsGroupBox);

    actionButtonsLayout = new QHBoxLayout();
    newButton = new QPushButton("Nouveau", this);
    saveButton = new QPushButton("Enregistrer", this);
    deleteButton = new QPushButton("Supprimer", this);
    actionButtonsLayout->addStretch();
    actionButtonsLayout->addWidget(newButton);
    actionButtonsLayout->addWidget(saveButton);
    actionButtonsLayout->addWidget(deleteButton);
    rightLayout->addLayout(actionButtonsLayout);
    rightLayout->addStretch();

    mainLayout->addLayout(leftLayout, 2);
    mainLayout->addLayout(rightLayout, 1);
}

void PlayerManagementWidget::connectSignalsSlots() {
    if(playerTableWidget) connect(playerTableWidget, &QTableWidget::itemSelectionChanged, this, &PlayerManagementWidget::playerSelectionChanged);
    if(refreshButton) connect(refreshButton, &QPushButton::clicked, this, &PlayerManagementWidget::refreshPlayerList);
    if(newButton) connect(newButton, &QPushButton::clicked, this, &PlayerManagementWidget::prepareNewPlayer);
    if(saveButton) connect(saveButton, &QPushButton::clicked, this, &PlayerManagementWidget::savePlayerData);
    if(deleteButton) connect(deleteButton, &QPushButton::clicked, this, &PlayerManagementWidget::deleteSelectedPlayer);
}

void PlayerManagementWidget::refreshPlayerList() {
    if (m_connection && m_connection->database().isOpen()) {
        loadTeamsCache();
        populateTeamCombo();
        loadPlayersList();
    } else {
        if (m_connection && m_connection->createconnect()) {
            loadTeamsCache();
            populateTeamCombo();
            loadPlayersList();
        } else {
            QMessageBox::warning(this, "Connexion Base de Données", "La connexion n'est pas disponible pour rafraîchir.");
        }
    }
    clearForm();
}

void PlayerManagementWidget::playerSelectionChanged() {
    if (!playerTableWidget) return;
    QList<QTableWidgetItem*> selectedItems = playerTableWidget->selectedItems();
    if (selectedItems.isEmpty()) { clearForm(); return; }

    if (!m_connection || !m_connection->database().isOpen()) {
        QMessageBox::warning(this, "Connexion Base de Données", "La connexion n'est pas disponible pour charger les détails.");
        clearForm(); return;
    }

    int selectedRow = playerTableWidget->row(selectedItems.first());
    if (selectedRow < 0) {clearForm(); return;}
    QTableWidgetItem* idItem = playerTableWidget->item(selectedRow, 0);
    if (!idItem) {clearForm(); return;}
    bool ok;
    int playerId = idItem->text().toInt(&ok);
    if (ok) { populatePlayerDetails(playerId); }
    else { qWarning() << "ID joueur invalide dans la table:" << idItem->text(); clearForm(); }
}

void PlayerManagementWidget::prepareNewPlayer() {
    clearForm();
}

void PlayerManagementWidget::savePlayerData() {
    if (!m_connection || !m_connection->database().isOpen()) {
        QMessageBox::critical(this, "Erreur", "Connexion à la base de données non disponible."); return;
    }

    QString nom = nameLineEdit->text().trimmed();
    QString prenom = firstNameLineEdit->text().trimmed();
    QDate dateNaissance = birthDateEdit->date();
    QString position = positionLineEdit->text().trimmed();
    int numeroMaillot = jerseyNumberSpinBox->value();
    int currentTeamId = currentTeamComboBox->currentData().toInt();

    if (nom.isEmpty()) {
        QMessageBox::warning(this, "Champ Requis", "Le nom du joueur est obligatoire."); nameLineEdit->setFocus(); return;
    }
    if (prenom.isEmpty()) {
        QMessageBox::warning(this, "Champ Requis", "Le prénom du joueur est obligatoire."); firstNameLineEdit->setFocus(); return;
    }

    QSqlDatabase db = m_connection->database();
    bool success = false; QString finalMessage; int savedPlayerId = -1;

    if (!db.transaction()) {
        finalMessage = "Impossible de démarrer la transaction: " + db.lastError().text(); qWarning() << finalMessage;
        QMessageBox::critical(this, "Erreur Transaction", finalMessage); return;
    }
    QApplication::setOverrideCursor(Qt::WaitCursor);

    try {
        QSqlQuery query(db);
        int playerIdToUpdateLinks = -1;
        int oldTeamIdForLinks = NO_TEAM_ID_PLAYER;
        int newTeamIdForLinks = currentTeamId;

        if (m_currentPlayerId < 0) { // --- CREATION (INSERT) ---
            query.prepare("SELECT joueur_seq.NEXTVAL FROM DUAL");
            if (!query.exec()) throw std::runtime_error("Erreur obtention ID joueur: " + query.lastError().text().toStdString());
            int newId = -1; if (query.next()) newId = query.value(0).toInt(); else throw std::runtime_error("Impossible de récupérer le nouvel ID joueur.");
            playerIdToUpdateLinks = newId;
            oldTeamIdForLinks = NO_TEAM_ID_PLAYER;
            savedPlayerId = newId; // Stocker pour sélection potentielle

            query.prepare("INSERT INTO joueurs (id_joueur, nom, prenom, date_naissance, position, numero_maillot, id_equipe_actuelle) "
                          "VALUES (:id, :nom, :prenom, :daten, :pos, :num, :idequipe)");
            query.bindValue(":id", newId);
            query.bindValue(":nom", nom);
            query.bindValue(":prenom", prenom);
            query.bindValue(":daten", dateNaissance.isValid() ? QVariant(dateNaissance) : QVariant());
            query.bindValue(":pos", position.isEmpty() ? QVariant() : position);
            query.bindValue(":num", numeroMaillot == 0 ? QVariant() : numeroMaillot);
            query.bindValue(":idequipe", currentTeamId == NO_TEAM_ID_PLAYER ? QVariant() : currentTeamId);
            if (!query.exec()) throw std::runtime_error("Erreur insertion joueur: " + query.lastError().text().toStdString());
            finalMessage = QString("Joueur '%1 %2' créé (ID: %3).").arg(prenom).arg(nom).arg(newId);

        } else { // --- MISE A JOUR (UPDATE) ---
            playerIdToUpdateLinks = m_currentPlayerId;
            oldTeamIdForLinks = m_currentPlayerOldTeamId;
            savedPlayerId = m_currentPlayerId; // Garder l'ID pour sélection

            query.prepare("UPDATE joueurs SET nom = :nom, prenom = :prenom, date_naissance = :daten, "
                          "position = :pos, numero_maillot = :num, id_equipe_actuelle = :idequipe "
                          "WHERE id_joueur = :id");
            query.bindValue(":nom", nom);
            query.bindValue(":prenom", prenom);
            query.bindValue(":daten", dateNaissance.isValid() ? QVariant(dateNaissance) : QVariant());
            query.bindValue(":pos", position.isEmpty() ? QVariant() : position);
            query.bindValue(":num", numeroMaillot == 0 ? QVariant() : numeroMaillot);
            query.bindValue(":idequipe", currentTeamId == NO_TEAM_ID_PLAYER ? QVariant() : currentTeamId);
            query.bindValue(":id", m_currentPlayerId);
            if (!query.exec()) throw std::runtime_error("Erreur mise à jour joueur: " + query.lastError().text().toStdString());
            finalMessage = QString("Joueur '%1 %2' mis à jour.").arg(prenom).arg(nom);
        }

        if (oldTeamIdForLinks != newTeamIdForLinks) {
            if (!updatePlayerTeamLink(playerIdToUpdateLinks, oldTeamIdForLinks, newTeamIdForLinks, db)) {
                throw std::runtime_error("Erreur interne lors de la mise à jour du lien équipe-joueur.");
            }
        }

        if (!db.commit()) { throw std::runtime_error("Erreur commit: " + db.lastError().text().toStdString()); }
        success = true;
        QMessageBox::information(this, "Succès", finalMessage);

    } catch (const std::runtime_error &e) {
        qWarning() << "Erreur savePlayerData, rollback..." << e.what(); db.rollback();
        QMessageBox::critical(this, "Erreur Sauvegarde", QString("Échec: %1").arg(e.what())); success = false;
        savedPlayerId = -1; // Réinitialiser si erreur
    } catch (const QSqlError &e) { // Attraper aussi les erreurs SQL non converties en runtime_error
        qWarning() << "Erreur SQL savePlayerData, rollback..." << e.text(); db.rollback();
        QMessageBox::critical(this, "Erreur Sauvegarde", QString("Échec SQL: %1").arg(e.text())); success = false;
        savedPlayerId = -1;
    }
    QApplication::restoreOverrideCursor();

    if (success) {
        loadPlayersList();
        clearForm();
            // Optionnel: sélectionner la ligne
        if (savedPlayerId >= 0 && playerTableWidget) {
            for (int i = 0; i < playerTableWidget->rowCount(); ++i) {
                QTableWidgetItem *item = playerTableWidget->item(i, 0);
                if (item && item->text().toInt() == savedPlayerId) {
                    playerTableWidget->selectRow(i);
                    break;
                }
            }
        }
    }
}

void PlayerManagementWidget::deleteSelectedPlayer() {
    if (m_currentPlayerId < 0) { QMessageBox::warning(this, "Action Impossible", "Sélectionner un joueur à supprimer."); return; }
    if (!m_connection || !m_connection->database().isOpen()) { QMessageBox::critical(this, "Erreur", "Connexion DB non disponible."); return; }

    QString playerName = (firstNameLineEdit ? firstNameLineEdit->text() : "") + " " + (nameLineEdit ? nameLineEdit->text() : "");
    playerName = playerName.trimmed().isEmpty() ? "[Joueur ID: "+QString::number(m_currentPlayerId)+"]" : playerName;
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Confirmation",
                                  QString("Supprimer le joueur '%1' ?\n"
                                          "Cela supprimera ses liens avec les équipes et son historique de transfert.").arg(playerName),
                                  QMessageBox::Yes | QMessageBox::No, QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        QSqlDatabase db = m_connection->database(); bool success = false;
        if (!db.transaction()) { qWarning() << "Échec démarrage transaction delete: " + db.lastError().text(); QMessageBox::critical(this, "Erreur Transaction", "Impossible de démarrer."); return; }
        QApplication::setOverrideCursor(Qt::WaitCursor);
        try {
            QSqlQuery query(db);
            query.prepare("DELETE FROM equipe_joueurs WHERE id_joueur = :id"); query.bindValue(":id", m_currentPlayerId);
            if (!query.exec()) throw std::runtime_error("Erreur suppression liens équipe-joueur: " + query.lastError().text().toStdString());
            qInfo() << query.numRowsAffected() << "liens équipe-joueur supprimés pour joueur" << m_currentPlayerId;

            query.prepare("DELETE FROM transferts WHERE id_joueur = :id"); query.bindValue(":id", m_currentPlayerId);
            if (!query.exec()) throw std::runtime_error("Erreur suppression transferts: " + query.lastError().text().toStdString());
            qInfo() << query.numRowsAffected() << "transferts supprimés pour joueur" << m_currentPlayerId;

            // Ajoutez ici la suppression d'autres dépendances si nécessaire

            query.prepare("DELETE FROM joueurs WHERE id_joueur = :id"); query.bindValue(":id", m_currentPlayerId);
            if (!query.exec()) throw std::runtime_error("Erreur suppression joueur: " + query.lastError().text().toStdString());
            int rowsAffected = query.numRowsAffected();

            if (!db.commit()) throw std::runtime_error("Erreur commit suppression joueur: " + db.lastError().text().toStdString());

            if (rowsAffected > 0) { QMessageBox::information(this, "Succès", QString("Joueur '%1' supprimé.").arg(playerName)); success = true; }
            else { QMessageBox::warning(this, "Avertissement", QString("Joueur '%1' non trouvé (ou déjà supprimé).").arg(playerName)); success = true; }

        } catch (const std::runtime_error &e) {
            qWarning() << "Erreur deleteSelectedPlayer, rollback..." << e.what(); db.rollback();
            QMessageBox::critical(this, "Erreur Suppression", QString("Échec: %1").arg(e.what())); success = false;
        } catch (const QSqlError &e) { // Attraper aussi les erreurs SQL
            qWarning() << "Erreur SQL deleteSelectedPlayer, rollback..." << e.text(); db.rollback();
            QMessageBox::critical(this, "Erreur Suppression", QString("Échec SQL: %1").arg(e.text())); success = false;
        }
        QApplication::restoreOverrideCursor();
        if (success) { loadPlayersList(); clearForm(); }
    }
}


void PlayerManagementWidget::loadPlayersList() {
    if (!m_connection || !m_connection->database().isOpen()) { qWarning() << "loadPlayersList: Connexion DB indisponible."; if(playerTableWidget) playerTableWidget->setRowCount(0); return; }
    if (!playerTableWidget) return;
    playerTableWidget->setRowCount(0); playerTableWidget->setSortingEnabled(false);
    QApplication::setOverrideCursor(Qt::WaitCursor);
    QSqlDatabase db = m_connection->database(); QSqlQuery query(db);
    QString sql = "SELECT j.id_joueur, j.nom, j.prenom, j.position, j.numero_maillot, eq.nom AS equipe_nom "
                  "FROM JOUEURS j LEFT JOIN EQUIPES eq ON j.id_equipe_actuelle = eq.id_equipe "
                  "ORDER BY j.nom, j.prenom";
    if (query.exec(sql)) {
        int row = 0;
        while (query.next()) {
            playerTableWidget->insertRow(row);
            QTableWidgetItem *idItem = new QTableWidgetItem(query.value(0).toString()); idItem->setFlags(idItem->flags() & ~Qt::ItemIsEditable);
            QTableWidgetItem *nomItem = new QTableWidgetItem(query.value(1).toString()); nomItem->setFlags(nomItem->flags() & ~Qt::ItemIsEditable);
            QTableWidgetItem *prenomItem = new QTableWidgetItem(query.value(2).toString()); prenomItem->setFlags(prenomItem->flags() & ~Qt::ItemIsEditable);
            QTableWidgetItem *posItem = new QTableWidgetItem(query.value(3).toString()); posItem->setFlags(posItem->flags() & ~Qt::ItemIsEditable);
            QVariant numVal = query.value(4);
            QTableWidgetItem *numItem = new QTableWidgetItem(numVal.isNull() || numVal.toInt() == 0 ? "" : numVal.toString());
            numItem->setTextAlignment(Qt::AlignCenter); numItem->setFlags(numItem->flags() & ~Qt::ItemIsEditable);
            QTableWidgetItem *teamItem = new QTableWidgetItem(query.value(5).isNull() ? "Libre" : query.value(5).toString()); teamItem->setFlags(teamItem->flags() & ~Qt::ItemIsEditable);

            playerTableWidget->setItem(row, 0, idItem); playerTableWidget->setItem(row, 1, nomItem); playerTableWidget->setItem(row, 2, prenomItem);
            playerTableWidget->setItem(row, 3, posItem); playerTableWidget->setItem(row, 4, numItem); playerTableWidget->setItem(row, 5, teamItem);
            row++;
        }
        playerTableWidget->setRowCount(row);
    } else { qWarning() << "Erreur chargement joueurs:" << query.lastError().text(); QMessageBox::critical(this, "Erreur Chargement", "Impossible de charger joueurs.\n" + query.lastError().text()); }
    QApplication::restoreOverrideCursor();
    if(playerTableWidget) {
        playerTableWidget->setSortingEnabled(true);
        playerTableWidget->resizeColumnsToContents();
        playerTableWidget->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch); // Réappliquer après resize
        playerTableWidget->horizontalHeader()->setSectionResizeMode(2, QHeaderView::Stretch);
        playerTableWidget->horizontalHeader()->setSectionResizeMode(5, QHeaderView::Stretch);
    }
}

void PlayerManagementWidget::loadTeamsCache() {
    if (!m_connection || !m_connection->database().isOpen()) { qWarning() << "loadTeamsCache (Player): Connexion DB indisponible."; m_allTeams.clear(); return; }
    m_allTeams.clear(); QSqlDatabase db = m_connection->database(); QSqlQuery query(db);
    if(query.exec("SELECT id_equipe, nom FROM equipes ORDER BY nom")) { // Assurez-vous table EQUIPES existe
        while(query.next()) { Equipe equipe; equipe.setId(query.value(0).toInt()); equipe.setNom(query.value(1).toString()); m_allTeams.append(equipe); }
        qInfo() << "Cache équipes (Player) rechargé:" << m_allTeams.count() << "équipes.";
    } else { qWarning() << "Erreur rechargement cache équipes (Player):" << query.lastError().text(); }
}

void PlayerManagementWidget::populateTeamCombo() {
    if (!currentTeamComboBox) return;
    currentTeamComboBox->clear();
    currentTeamComboBox->addItem("Libre / Aucune", NO_TEAM_ID_PLAYER);
    for (const Equipe &team : m_allTeams) {
        currentTeamComboBox->addItem(QString("%1 (ID:%2)").arg(team.getNom()).arg(team.getId()), team.getId());
    }
}

void PlayerManagementWidget::populatePlayerDetails(int playerId) {
    if (!m_connection || !m_connection->database().isOpen()) { qWarning() << "populatePlayerDetails: Connexion DB indisponible."; clearForm(); return; }
    QApplication::setOverrideCursor(Qt::WaitCursor);
    QSqlDatabase db = m_connection->database(); QSqlQuery query(db);
    query.prepare("SELECT nom, prenom, date_naissance, position, numero_maillot, id_equipe_actuelle "
                  "FROM joueurs WHERE id_joueur = :id"); // Assurez-vous table JOUEURS existe
    query.bindValue(":id", playerId);

    if (query.exec() && query.next()) {
        m_currentPlayerId = playerId;
        if(idLabelValue) idLabelValue->setText(QString::number(playerId));
        if(nameLineEdit) nameLineEdit->setText(query.value(0).toString());
        if(firstNameLineEdit) firstNameLineEdit->setText(query.value(1).toString());
        if(birthDateEdit) {
            QVariant dateVal = query.value(2);
            if (dateVal.isNull() || !dateVal.isValid() || !dateVal.toDate().isValid()) birthDateEdit->setDate(QDate(1990,1,1)); // Mettre une date par défaut si invalide
            else birthDateEdit->setDate(dateVal.toDate());
        }
        if(positionLineEdit) positionLineEdit->setText(query.value(3).toString());
        if(jerseyNumberSpinBox) jerseyNumberSpinBox->setValue(query.value(4).isNull() ? 0 : query.value(4).toInt());

        int teamId = query.value(5).isNull() ? NO_TEAM_ID_PLAYER : query.value(5).toInt();
        m_currentPlayerOldTeamId = teamId;
        if(currentTeamComboBox){
            int teamIndex = currentTeamComboBox->findData(teamId);
            currentTeamComboBox->setCurrentIndex(qMax(0, teamIndex));
        }

        if(deleteButton) deleteButton->setEnabled(true);
        if(saveButton) saveButton->setText("Enregistrer Modifications");
    } else {
        qWarning() << "Erreur chargement joueur ID" << playerId << ":" << query.lastError().text();
        QMessageBox::warning(this, "Non trouvé", QString("Joueur ID %1 non chargé.").arg(playerId)); clearForm();
    }
    QApplication::restoreOverrideCursor();
}

void PlayerManagementWidget::clearForm() {
    m_currentPlayerId = -1;
    m_currentPlayerOldTeamId = NO_TEAM_ID_PLAYER;
    if(idLabelValue) idLabelValue->setText("Nouveau");
    if(nameLineEdit) nameLineEdit->clear();
    if(firstNameLineEdit) firstNameLineEdit->clear();
    if(birthDateEdit) birthDateEdit->setDate(QDate::currentDate().addYears(-20));
    if(positionLineEdit) positionLineEdit->clear();
    if(jerseyNumberSpinBox) jerseyNumberSpinBox->setValue(0);
    if(currentTeamComboBox) currentTeamComboBox->setCurrentIndex(0);
    if(playerTableWidget) playerTableWidget->clearSelection();
    if(deleteButton) deleteButton->setEnabled(false);
    if(saveButton) saveButton->setText("Créer Joueur");
    if(nameLineEdit) nameLineEdit->setFocus();
}

bool PlayerManagementWidget::updatePlayerTeamLink(int playerId, int oldTeamId, int newTeamId, QSqlDatabase& db) {
    if (oldTeamId == newTeamId) return true;

    QSqlQuery queryDelete(db);
    QSqlQuery queryInsert(db);

    try {
        if (oldTeamId != NO_TEAM_ID_PLAYER) {
            queryDelete.prepare("DELETE FROM equipe_joueurs WHERE id_equipe = :idequipe AND id_joueur = :idj"); // Assurez-vous table EQUIPE_JOUEURS existe
            queryDelete.bindValue(":idequipe", oldTeamId);
            queryDelete.bindValue(":idj", playerId);
            if (!queryDelete.exec()) throw std::runtime_error("Erreur suppression ancien lien equipe_joueurs: " + queryDelete.lastError().text().toStdString());
        }
        if (newTeamId != NO_TEAM_ID_PLAYER) {
            queryInsert.prepare("INSERT INTO equipe_joueurs (id_equipe, id_joueur) VALUES (:idequipe, :idj)");
            queryInsert.bindValue(":idequipe", newTeamId);
            queryInsert.bindValue(":idj", playerId);
            if (!queryInsert.exec() && queryInsert.lastError().type() != QSqlError::NoError) {
                // Vérifier si l'erreur est une violation de clé unique (ORA-00001 pour Oracle)
                // Le code exact peut varier selon la DB
                bool isDuplicateKeyError = queryInsert.lastError().nativeErrorCode().contains("00001");
                if (!isDuplicateKeyError) throw std::runtime_error("Erreur insertion nouveau lien equipe_joueurs: " + queryInsert.lastError().text().toStdString());
                else qWarning() << "Lien joueur" << playerId << "- équipe" << newTeamId << "existe déjà, insertion ignorée.";
            }
        }
        qInfo() << "Lien Equipe-Joueur mis à jour pour joueur" << playerId << "(Ancien:" << oldTeamId << ", Nouveau:" << newTeamId << ")";
        return true;
    } catch (const std::runtime_error &e) {
        qWarning() << "Erreur dans updatePlayerTeamLink:" << e.what();
        // Remonter l'erreur pour que la transaction principale fasse un rollback
        // Ne pas juste retourner false ici silencieusement.
        throw; // Relance l'exception pour le bloc catch de savePlayerData
    }
    // Ne devrait pas être atteint si une exception est lancée
    return false;
}
