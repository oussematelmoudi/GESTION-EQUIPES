// standingswidget.h (Corrigé pour l'ordre et l'export)
#ifndef STANDINGSWIDGET_H
#define STANDINGSWIDGET_H

#include <QWidget>
#include <QList>
#include <QMap>

// Forward declarations Qt
class QTableWidget;
class QPushButton;
class QVBoxLayout;
class QGroupBox;
class QHeaderView;
class QHBoxLayout;

// Includes du projet
#include "connection.h"
#include "equipe.h" // Pour obtenir la liste des équipes

// Structure simple pour stocker les statistiques d'une équipe
struct TeamStats {
    int teamId = -1;
    QString teamName = "Inconnu";
    int played = 0;
    int wins = 0;
    int draws = 0;
    int losses = 0;
    int goalsFor = 0;
    int goalsAgainst = 0;
    int goalDifference = 0;
    int points = 0;
};

class StandingsWidget : public QWidget
{
    Q_OBJECT

public:
    explicit StandingsWidget(Connection *connection, QWidget *parent = nullptr);
    ~StandingsWidget() override = default; // Destructeur par défaut

private slots:
    void refreshStandings();
    void exportStandingsToCsv();

private:
    // --- Widgets et Layouts (Déclarés avant les membres de données pour l'ordre) ---
    QVBoxLayout *mainLayout;
    QGroupBox *standingsGroupBox;
    QVBoxLayout *groupBoxLayout;
    QTableWidget *standingsTableWidget;
    QHBoxLayout *buttonsLayout;
    QPushButton *refreshButton;
    QPushButton *exportButton;

    // --- Données membres ---
    Connection *m_connection; // << Déclaré après les pointeurs widgets
    QList<TeamStats> m_currentStandings;

    // --- Méthodes privées ---
    void setupUi();
    void connectSignalsSlots();
    void calculateAndDisplayStandings();
    QList<TeamStats> calculateStandingsLogic();
    void displayStandingsInTable(const QList<TeamStats>& standings);
    void styleTable();
    QString escapeCsvValue(const QString &value);
};

#endif // STANDINGSWIDGET_H
