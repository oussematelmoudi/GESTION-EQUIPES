// coachmanagementwidget.h (Avec Historique Complet Modifiable)
#ifndef COACHMANAGEMENTWIDGET_H
#define COACHMANAGEMENTWIDGET_H

#include <QWidget>
#include <QList>
#include <QMap> // Pour le cache équipes

// Forward declarations Qt
class QTableWidget; class QPushButton; class QLineEdit; class QLabel;
class QGroupBox; class QHBoxLayout; class QVBoxLayout; class QFormLayout;
class QDateEdit; class QTableWidgetItem;
// class QListWidget; // Remplacé par QTableWidget

// Includes directs des classes du projet
#include "coach.h"
#include "connection.h"
#include "equipe.h" // Pour le cache équipes

class CoachHistoryDialog; // Forward declaration pour la nouvelle fenêtre

class CoachManagementWidget : public QWidget
{
    Q_OBJECT

public:
    explicit CoachManagementWidget(Connection *connection, QWidget *parent = nullptr);

private slots:
    void refreshCoachList();
    void coachSelectionChanged();
    void prepareNewCoach();
    void saveCoachData();
    void deleteSelectedCoach();

    // Slots pour gérer l'historique
    void onAddHistoryClicked();
    void onEditHistoryClicked();
    void onDeleteHistoryClicked();
    void onHistoryTableSelectionChanged(); // Pour activer/désactiver Modifier/Supprimer

private:
    // --- Widgets et Layouts membres ---
    QHBoxLayout *mainLayout;
    QVBoxLayout *leftLayout;
    QVBoxLayout *rightLayout;

    // Section Gauche (Liste Coachs)
    QGroupBox *listGroupBox;
    QVBoxLayout *listVBoxLayout;
    QTableWidget *coachTableWidget;
    QPushButton *refreshButton;

    // Section Droite (Formulaire Détails Coach)
    QGroupBox *detailsGroupBox;
    QFormLayout *detailsFormLayout;
    QLabel *idLabelInfo, *idLabelValue, *nameLabel, *firstNameLabel, *birthDateLabel, *licenceLabel;
    QLineEdit *nameLineEdit, *firstNameLineEdit, *licenceLineEdit;
    QDateEdit *birthDateEdit;
    QHBoxLayout *actionButtonsLayout;
    QPushButton *newButton, *saveButton, *deleteButton;

    // --- Section Historique (Modifiable) ---
    QGroupBox *historyGroupBox;
    QVBoxLayout *historyVBoxLayout;
    QTableWidget *historyTableWidget; // <<< Table pour l'historique
    QHBoxLayout *historyButtonsLayout;
    QPushButton *addHistoryButton;
    QPushButton *editHistoryButton;
    QPushButton *deleteHistoryButton;

    // --- Méthodes privées ---
    void setupUi();
    void connectSignalsSlots();
    void loadCoachesList();
    void populateCoachDetails(int coachId);
    void clearForm();
    void loadCoachHistoryTable(int coachId); // Charge la table historique
    void loadTeamsCache();                 // Charge les équipes pour le dialogue

    // --- Données membres ---
    Connection *m_connection;
    int m_currentCoachId;
    QMap<int, QString> m_teamsMap; // Cache ID -> Nom pour le dialogue
};

#endif // COACHMANAGEMENTWIDGET_H
