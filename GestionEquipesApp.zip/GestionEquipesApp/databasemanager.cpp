// databasemanager.cpp (Corrigé pour QODBC et Warnings)

#include "databasemanager.h" // Include direct
#include <QDebug>
#include <stdexcept> // Pour std::runtime_error
#include <QVariant>  // Nécessaire pour QVariant()
#include <QMetaType> // Optionnel, pour l'alternative QMetaType si QVariant() pose problème

// --- CONSTRUCTEUR MODIFIÉ POUR QODBC ---
DatabaseManager::DatabaseManager(QObject *parent) : QObject(parent) {
    const QString connectionName = "maConnexionOdbcDribbtech"; // Nom unique pour la connexion

    // Utiliser la connexion nommée si elle existe déjà, sinon l'ajouter
    if (QSqlDatabase::contains(connectionName)) {
        m_db = QSqlDatabase::database(connectionName);
        if (!m_db.isOpen()) { // Tenter de rouvrir si elle était fermée
            qWarning() << "Connexion ODBC existante trouvée mais fermée. Tentative de réouverture...";
            openDatabase(); // Appelle la méthode pour ouvrir et gérer les erreurs
        } else {
            qInfo() << "Réutilisation de la connexion ODBC existante:" << connectionName;
        }
    } else {
        // Ajouter une nouvelle connexion avec le driver QODBC
        m_db = QSqlDatabase::addDatabase("QODBC", connectionName);
        qInfo() << "Configuration d'une nouvelle connexion avec le driver QODBC:" << connectionName;

        // --- Configuration spécifique ODBC ---
        // Nom de la source de données (DSN) configurée dans le système d'exploitation
        m_db.setDatabaseName("DRIBBTECH"); // !! DOIT correspondre au DSN configuré !!
        qInfo() << "Utilisation du DSN ODBC:" << m_db.databaseName();

        // Identifiants fournis
        m_db.setUserName("DRIBBTECH");
        m_db.setPassword("DRIBBTECH");

        // HostName et Port ne sont généralement pas nécessaires pour ODBC (configurés dans le DSN)
    }
}

// --- DESTRUCTEUR ---
DatabaseManager::~DatabaseManager() {
    closeDatabase(); // Assure la fermeture propre
}

// --- OUVERTURE / FERMETURE ---
bool DatabaseManager::openDatabase() {
    if (m_db.isOpen()) {
        return true;
    }
    if (!m_db.open()) {
        qWarning() << "ERREUR de connexion ODBC:" << m_db.lastError().text() << "(DSN:" << m_db.databaseName() << ")";
        emit errorOccurred("Impossible de se connecter via ODBC DSN '" + m_db.databaseName() + "': " + m_db.lastError().text());
        return false;
    }
    qInfo() << "Connexion ODBC réussie (DSN:" << m_db.databaseName() << ")";
    return true;
}

void DatabaseManager::closeDatabase() {
    if (m_db.isOpen()) {
        QString connName = m_db.connectionName();
        m_db.close();
        qInfo() << "Connexion ODBC" << connName << "fermée.";
        // Important de retirer la connexion pour éviter les problèmes si l'objet est recréé
        QSqlDatabase::removeDatabase(connName);
    }
}

bool DatabaseManager::isConnected() const {
    return m_db.isOpen();
}

// --- HELPER INTERNE ---
bool DatabaseManager::executeQuery(QSqlQuery &query, const QString &queryString) {
    if (!m_db.isOpen() && !openDatabase()) {
        qWarning() << "Tentative d'exécution de requête sans connexion DB ouverte.";
        return false;
    }

    // Si une query string est fournie, préparer la requête
    if (!queryString.isEmpty()) {
        if(!query.prepare(queryString)) {
            qWarning() << "Erreur SQL Prepare:" << query.lastError().text() << "Query:" << queryString;
            emit errorOccurred("Erreur SQL (prepare): " + query.lastError().text());
            return false;
        }
    }
    // Les bindValue doivent avoir été faits avant cet appel si prepare a été utilisé

    // Exécuter la requête (préparée ou directe)
    if (!query.exec()) {
        qWarning() << "Erreur SQL Exec:" << query.lastError().text() << "Query:" << query.lastQuery();
        emit errorOccurred("Erreur SQL (exec): " + query.lastError().text());
        return false;
    }
    // qInfo() << "Requête exécutée avec succès:" << query.lastQuery(); // Optionnel: pour débug
    return true;
}


// --- CRUD pour Equipe ---

bool DatabaseManager::addEquipe(Equipe &equipe) {
    if (!m_db.transaction()) {
        qWarning() << "Impossible de démarrer la transaction pour addEquipe.";
        emit errorOccurred("Erreur de transaction (début) lors de l'ajout.");
        return false;
    }

    QSqlQuery query(m_db);
    bool success = false;

    try {
        // 1. Obtenir le nouvel ID
        // !!! ATTENTION : Spécifique à ORACLE. Doit être adapté pour d'autres SGBD !!!
        // Exemples :
        // - SQL Server: Utiliser OUTPUT inserted.id_equipe dans l'INSERT ou SCOPE_IDENTITY() après.
        // - MySQL: Utiliser LAST_INSERT_ID() après l'INSERT.
        // - PostgreSQL: Utiliser RETURNING id_equipe dans l'INSERT.
        // Si votre SGBD gère les ID auto-incrémentés sans séquence explicite,
        // vous pourriez insérer sans l'ID, puis le récupérer.
        if (!executeQuery(query, "SELECT equipe_seq.NEXTVAL FROM DUAL")) {
            // Si la requête échoue (par ex. si la DB n'est pas Oracle), lever une erreur
            throw std::runtime_error("Erreur obtention ID (Syntaxe Oracle spécifique échouée?): " + query.lastError().text().toStdString());
        }
        int newId = -1;
        if (query.next()) {
            newId = query.value(0).toInt();
            equipe.setId(newId); // Met à jour l'objet Equipe passé par référence
        } else {
            throw std::runtime_error("Impossible de récupérer le nouvel ID via la séquence Oracle.");
        }


        // 2. Insérer l'équipe
        // La requête INSERT est relativement standard, mais vérifiez les types si nécessaire.
        query.prepare("INSERT INTO equipes (id_equipe, nom, classement, id_entraineur_actuel) "
                      "VALUES (:id, :nom, :cls, :id_coach)");
        query.bindValue(":id", equipe.getId());
        query.bindValue(":nom", equipe.getNom());
        query.bindValue(":cls", equipe.getClassement());
        // Correction pour le NULL (utilise QVariant() pour le type NULL générique)
        query.bindValue(":id_coach", equipe.getIdEntraineurActuel() < 0 ? QVariant() : equipe.getIdEntraineurActuel());

        if (!executeQuery(query)) { // Exécute la requête préparée
            throw std::runtime_error("Erreur insertion équipe: " + query.lastError().text().toStdString());
        }

        // 3. Mettre à jour l'effectif (dans la même transaction)
        if (!updateEquipeEffectif(equipe.getId(), equipe.getEffectifIds())) {
            throw std::runtime_error("Erreur mise à jour effectif pendant ajout");
        }

        // Si tout s'est bien passé, commit
        if (!m_db.commit()) {
            throw std::runtime_error("Erreur de commit transaction: " + m_db.lastError().text().toStdString());
        }
        success = true;
        qInfo() << "Equipe ajoutée avec succès ID:" << equipe.getId();

    } catch (const std::runtime_error &e) {
        qWarning() << "Erreur dans addEquipe:" << e.what() << "- Rollback...";
        emit errorOccurred(QString("Erreur lors de l'ajout de l'équipe: %1").arg(e.what()));
        m_db.rollback(); // Annule la transaction en cas d'erreur
        success = false;
    }

    return success;
}

Equipe DatabaseManager::getEquipeById(int id) {
    QSqlQuery query(m_db);
    // Requête SELECT standard
    query.prepare("SELECT id_equipe, nom, classement, id_entraineur_actuel FROM equipes WHERE id_equipe = :id");
    query.bindValue(":id", id);

    if (executeQuery(query) && query.next()) {
        Equipe equipe(
            query.value(0).toInt(),                          // id_equipe
            query.value(1).toString(),                       // nom
            query.value(2).toInt(),                          // classement
            query.value(3).isNull() ? -1 : query.value(3).toInt() // id_entraineur_actuel (gère NULL)
            );
        // Charger l'effectif et autres listes d'IDs
        equipe.setEffectifIds(getEquipeJoueurIds(id));
        // TODO: Charger historique coachs, historique matchs...
        return equipe;
    } else {
        qWarning() << "Equipe non trouvée pour ID:" << id << " Erreur:" << query.lastError().text();
        return Equipe(); // Retourne une équipe "vide" ou invalide
    }
}


QList<Equipe> DatabaseManager::getAllEquipes() {
    QList<Equipe> equipes;
    QSqlQuery query(m_db);
    // Requête SELECT standard
    query.prepare("SELECT id_equipe, nom, classement, id_entraineur_actuel FROM equipes ORDER BY nom");

    if (executeQuery(query)) {
        while (query.next()) {
            Equipe equipe(
                query.value(0).toInt(),
                query.value(1).toString(),
                query.value(2).toInt(),
                query.value(3).isNull() ? -1 : query.value(3).toInt()
                );
            // Optionnel: charger l'effectif ici (peut être lourd si beaucoup d'équipes)
            // equipe.setEffectifIds(getEquipeJoueurIds(equipe.getId()));
            equipes.append(equipe);
        }
    } else {
        qWarning() << "Erreur getAllEquipes:" << query.lastError().text();
    }
    return equipes;
}


bool DatabaseManager::updateEquipe(const Equipe &equipe) {
    // Correction indentation/logique
    if (equipe.getId() < 0) { return false; } // Vérification ID d'abord
    if (!m_db.transaction()) {                // Ensuite transaction
        qWarning() << "Impossible de démarrer la transaction pour updateEquipe.";
        emit errorOccurred("Erreur de transaction (début) lors de la MAJ.");
        return false;
    }

    QSqlQuery query(m_db);
    bool success = false;

    try {
        // 1. Mettre à jour les données de l'équipe (Requête UPDATE standard)
        query.prepare("UPDATE equipes SET nom = :nom, classement = :cls, id_entraineur_actuel = :id_coach "
                      "WHERE id_equipe = :id");
        query.bindValue(":nom", equipe.getNom());
        query.bindValue(":cls", equipe.getClassement());
        // Correction pour le NULL
        query.bindValue(":id_coach", equipe.getIdEntraineurActuel() < 0 ? QVariant() : equipe.getIdEntraineurActuel());
        query.bindValue(":id", equipe.getId());

        if (!executeQuery(query)) {
            throw std::runtime_error("Erreur MAJ équipe: " + query.lastError().text().toStdString());
        }
        if (query.numRowsAffected() == 0) {
            // Ce n'est pas forcément une erreur, l'équipe pouvait ne pas exister ou les données étaient identiques
            qWarning() << "Aucune ligne affectée pour updateEquipe ID:" << equipe.getId();
        }


        // 2. Mettre à jour l'effectif (dans la même transaction)
        if (!updateEquipeEffectif(equipe.getId(), equipe.getEffectifIds())) {
            throw std::runtime_error("Erreur MAJ effectif pendant update");
        }

        // Commit
        if (!m_db.commit()) {
            throw std::runtime_error("Erreur commit transaction MAJ: " + m_db.lastError().text().toStdString());
        }
        success = true;
        qInfo() << "Equipe mise à jour avec succès ID:" << equipe.getId();

    } catch (const std::runtime_error &e) {
        qWarning() << "Erreur dans updateEquipe:" << e.what() << "- Rollback...";
        emit errorOccurred(QString("Erreur lors de la MAJ de l'équipe: %1").arg(e.what()));
        m_db.rollback();
        success = false;
    }
    return success;
}


bool DatabaseManager::deleteEquipe(int id) {
    // Correction indentation/logique
    if (id < 0) { return false; } // Vérif ID
    if (!m_db.transaction()) {    // Ensuite transaction
        qWarning() << "Impossible de démarrer la transaction pour deleteEquipe.";
        emit errorOccurred("Erreur de transaction (début) lors de la suppression.");
        return false;
    }

    QSqlQuery query(m_db);
    bool success = false;

    try {
        // 1. Supprimer les dépendances (Requêtes DELETE standard)
        // Table de liaison equipe_joueurs (Adapter noms si besoin)
        query.prepare("DELETE FROM equipe_joueurs WHERE id_equipe = :id");
        query.bindValue(":id", id);
        if (!executeQuery(query)) {
            throw std::runtime_error("Erreur suppression liens effectif: " + query.lastError().text().toStdString());
        }
        qInfo() << query.numRowsAffected() << "liens effectif supprimés pour equipe" << id;

        // TODO: Supprimer les autres liens (historique coachs, matchs, transferts...)


        // 2. Supprimer l'équipe elle-même
        query.prepare("DELETE FROM equipes WHERE id_equipe = :id");
        query.bindValue(":id", id);
        if (!executeQuery(query)) {
            throw std::runtime_error("Erreur suppression équipe: " + query.lastError().text().toStdString());
        }
        int rowsAffected = query.numRowsAffected();

        // Commit
        if (!m_db.commit()) {
            throw std::runtime_error("Erreur commit transaction suppression: " + m_db.lastError().text().toStdString());
        }

        // Décider du succès
        if (rowsAffected > 0) {
            qInfo() << "Equipe supprimée avec succès ID:" << id;
            success = true;
        } else {
            // Si l'équipe n'existait pas mais les liens (si existants) ont été supprimés, on peut considérer ça comme un succès partiel ou complet.
            qWarning() << "Equipe ID" << id << "non trouvée pour suppression (ou déjà supprimée). Suppression des liens effectuée.";
            success = true;
        }

    } catch (const std::runtime_error &e) {
        qWarning() << "Erreur dans deleteEquipe:" << e.what() << "- Rollback...";
        emit errorOccurred(QString("Erreur lors de la suppression de l'équipe: %1").arg(e.what()));
        m_db.rollback();
        success = false;
    }
    return success;
}


// --- Fonctions liées à l'effectif Equipe ---

QList<int> DatabaseManager::getEquipeJoueurIds(int equipeId) {
    QList<int> ids;
    QSqlQuery query(m_db);
    // Requête SELECT standard
    query.prepare("SELECT id_joueur FROM equipe_joueurs WHERE id_equipe = :id");
    query.bindValue(":id", equipeId);

    if (executeQuery(query)) {
        while(query.next()) {
            ids.append(query.value(0).toInt());
        }
    } else {
        qWarning() << "Erreur getEquipeJoueurIds pour equipe" << equipeId << query.lastError().text();
    }
    return ids;
}

// Doit être appelée DANS une transaction existante
bool DatabaseManager::updateEquipeEffectif(int equipeId, const QList<int> &newJoueurIds) {
    QSqlQuery query(m_db);

    try {
        // 1. Supprimer tous les anciens joueurs pour cette équipe (DELETE standard)
        query.prepare("DELETE FROM equipe_joueurs WHERE id_equipe = :id");
        query.bindValue(":id", equipeId);
        if (!executeQuery(query)) {
            throw std::runtime_error("Erreur suppression anciens joueurs effectif: " + query.lastError().text().toStdString());
        }

        // 2. Insérer les nouveaux joueurs (si la liste n'est pas vide) (INSERT standard)
        if (!newJoueurIds.isEmpty()) {
            // Utiliser execBatch pour potentiellement plus d'efficacité
            query.prepare("INSERT INTO equipe_joueurs (id_equipe, id_joueur) VALUES (:id_equipe, :id_joueur)");
            QVariantList equipeIdsList; // Utiliser des noms de variables différents de ceux des paramètres
            QVariantList joueurIdsList;
            for(int joueurId : newJoueurIds) {
                equipeIdsList << equipeId;
                joueurIdsList << joueurId;
            }
            query.bindValue(":id_equipe", equipeIdsList);
            query.bindValue(":id_joueur", joueurIdsList);

            if (!query.execBatch()) { // Utiliser execBatch pour les insertions multiples
                throw std::runtime_error("Erreur execBatch effectif: " + query.lastError().text().toStdString());
            }
        }
        qInfo() << "Effectif mis à jour dans DB pour equipe" << equipeId;
        return true;

    } catch (const std::runtime_error &e) {
        qWarning() << "Erreur dans updateEquipeEffectif:" << e.what();
        // Ne pas faire de rollback ici, laisser la transaction appelante gérer
        return false;
    }
}


// --- CRUD pour Joueur (Placeholders - NON IMPLEMENTES) ---
bool DatabaseManager::addJoueur(Joueur & /*joueur*/) { qWarning() << "addJoueur NYI"; return false; }
Joueur DatabaseManager::getJoueurById(int /*id*/) { qWarning() << "getJoueurById NYI"; return Joueur(); }
QList<Joueur> DatabaseManager::getAllJoueurs() {
    qWarning() << "getAllJoueurs NYI - Returning dummy data";
    QList<Joueur> dummyPlayers; dummyPlayers << Joueur(101, "Dupont", "Jean") << Joueur(102, "Martin", "Pierre") << Joueur(103, "Dubois", "Alice") << Joueur(104, "Petit", "Lucas");
    return dummyPlayers;
}
bool DatabaseManager::updateJoueur(const Joueur & /*joueur*/) { qWarning() << "updateJoueur NYI"; return false; }
bool DatabaseManager::deleteJoueur(int /*id*/) { qWarning() << "deleteJoueur NYI"; return false; }

// --- CRUD pour Coach (Placeholders - NON IMPLEMENTES) ---
bool DatabaseManager::addCoach(Coach & /*coach*/) { qWarning() << "addCoach NYI"; return false; }
Coach DatabaseManager::getCoachById(int /*id*/) { qWarning() << "getCoachById NYI"; return Coach(); }
QList<Coach> DatabaseManager::getAllCoaches() {
    qWarning() << "getAllCoaches NYI - Returning dummy data";
    QList<Coach> dummyCoaches; dummyCoaches << Coach(51, "Garcia", "Luis") << Coach(52, "Blanc", "Laurent") << Coach(53, "Zidane", "Zinedine");
    return dummyCoaches;
}
bool DatabaseManager::updateCoach(const Coach & /*coach*/) { qWarning() << "updateCoach NYI"; return false; }
bool DatabaseManager::deleteCoach(int /*id*/) { qWarning() << "deleteCoach NYI"; return false; }
