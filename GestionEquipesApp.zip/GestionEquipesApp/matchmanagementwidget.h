// matchmanagementwidget.h
#ifndef MATCHMANAGEMENTWIDGET_H
#define MATCHMANAGEMENTWIDGET_H

#include <QWidget>
#include <QList> // Pour cache équipes

// Forward declarations Qt
class QTableWidget; class QPushButton; class QComboBox; class QLabel;
class QGroupBox; class QHBoxLayout; class QVBoxLayout; class QFormLayout;
class QDateEdit; class QSpinBox; class QLineEdit; class QTableWidgetItem;

// Includes directs des classes du projet
#include "equipe.h"     // Pour le cache et les ComboBox Équipe
#include "connection.h" // Pour interagir avec la DB

class MatchManagementWidget : public QWidget
{
    Q_OBJECT

public:
    // Constructeur prend un pointeur vers l'objet Connection partagé
    explicit MatchManagementWidget(Connection *connection, QWidget *parent = nullptr);
    // Destructeur par défaut

private slots:
    // Slots pour les actions de l'utilisateur
    void refreshAll();       // Recharge équipes et liste des matchs
    void saveNewMatch();     // Enregistre un nouveau match

private:
    // --- Widgets et Layouts membres ---
    // Layouts principaux
    QHBoxLayout *mainLayout; // Layout Horizontal principal
    QVBoxLayout *leftLayout; // Pour le formulaire d'ajout
    QVBoxLayout *rightLayout;// Pour la liste des matchs

    // Section Gauche (Formulaire Ajout)
    QGroupBox *addMatchGroupBox;
    QFormLayout *addMatchFormLayout;
    QLabel *homeTeamLabel;
    QComboBox *homeTeamComboBox;    // Sélection équipe domicile
    QLabel *awayTeamLabel;
    QComboBox *awayTeamComboBox;    // Sélection équipe extérieur
    QLabel *homeScoreLabel;
    QSpinBox *homeScoreSpinBox;     // Score domicile
    QLabel *awayScoreLabel;
    QSpinBox *awayScoreSpinBox;     // Score extérieur
    QLabel *dateLabel;
    QDateEdit *matchDateEdit;       // Date du match
    QLabel *locationLabel;
    QLineEdit *locationLineEdit;    // Lieu du match
    QPushButton *saveMatchButton;   // Bouton pour enregistrer

    // Section Droite (Liste Historique)
    QGroupBox *historyGroupBox;
    QVBoxLayout *historyVBoxLayout;
    QTableWidget *matchTableWidget; // Tableau pour l'historique
    QPushButton *refreshButton;     // Bouton pour rafraîchir la liste

    // --- Méthodes privées ---
    void setupUi();             // Crée et arrange les widgets de l'interface
    void connectSignalsSlots(); // Connecte les signaux UI aux slots
    void loadMatchesList();     // Charge l'historique des matchs depuis la DB
    void loadTeamsCache();      // Charge les équipes dans le cache m_allTeams
    void populateTeamCombos();  // Remplit les ComboBox Équipe à partir du cache
    void clearAddForm();        // Réinitialise le formulaire d'ajout

    // --- Données membres ---
    Connection *m_connection;   // Pointeur vers l'objet Connection principal
    QList<Equipe> m_allTeams;   // Cache des équipes pour ComboBoxes
};

#endif // MATCHMANAGEMENTWIDGET_H
