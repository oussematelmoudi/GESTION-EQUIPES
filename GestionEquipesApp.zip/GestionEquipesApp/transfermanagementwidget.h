// transfermanagementwidget.h
#ifndef TRANSFERMANAGEMENTWIDGET_H
#define TRANSFERMANAGEMENTWIDGET_H

#include <QWidget>
#include <QList> // Pour les caches

// Forward declarations Qt
class QTableWidget; class QPushButton; class QComboBox; class QLabel;
class QGroupBox; class QHBoxLayout; class QVBoxLayout; class QFormLayout;
class QDateEdit; class QDoubleSpinBox; class QTableWidgetItem;

// Includes directs des classes du projet
#include "joueur.h"     // Pour le cache et le ComboBox Joueur
#include "equipe.h"     // Pour le cache et les ComboBox Equipe
#include "connection.h" // Pour interagir avec la DB

// Constante globale ou membre statique pour ID équipe "Libre"
const int NO_TEAM_ID = -1;

class TransferManagementWidget : public QWidget
{
    Q_OBJECT

public:
    // Constructeur prend un pointeur vers l'objet Connection partagé
    explicit TransferManagementWidget(Connection *connection, QWidget *parent = nullptr);
    // Destructeur par défaut

private slots:
    // Slots pour les actions de l'utilisateur
    void refreshLists();       // Recharge toutes les listes (transferts, joueurs, équipes)
    void saveNewTransfer();    // Enregistre un nouveau transfert

private:
    // --- Widgets et Layouts membres ---
    // Layouts principaux
    QVBoxLayout *mainLayout; // Layout vertical principal
    QHBoxLayout *topLayout;  // Layout pour le formulaire et la liste

    // Section Gauche (Formulaire Ajout)
    QGroupBox *addTransferGroupBox;
    QFormLayout *addTransferFormLayout;
    QLabel *playerLabel;
    QComboBox *playerComboBox;       // Sélection du joueur
    QLabel *originTeamLabel;
    QComboBox *originTeamComboBox;   // Sélection équipe origine (avec "Libre")
    QLabel *destTeamLabel;
    QComboBox *destTeamComboBox;     // Sélection équipe destination (avec "Libre")
    QLabel *dateLabel;
    QDateEdit *transferDateEdit;   // Date du transfert
    QLabel *amountLabel;
    QDoubleSpinBox *amountSpinBox;   // Montant du transfert
    QPushButton *saveTransferButton; // Bouton pour enregistrer

    // Section Droite (Liste Historique)
    QGroupBox *historyGroupBox;
    QVBoxLayout *historyVBoxLayout;
    QTableWidget *transferTableWidget; // Tableau pour l'historique
    QPushButton *refreshButton;        // Bouton pour rafraîchir la liste

    // --- Méthodes privées ---
    void setupUi();             // Crée et arrange les widgets de l'interface
    void connectSignalsSlots(); // Connecte les signaux UI aux slots
    void loadTransfersList();   // Charge l'historique des transferts depuis la DB
    void loadPlayersCache();    // Charge les joueurs dans le cache m_allPlayers
    void loadTeamsCache();      // Charge les équipes dans le cache m_allTeams
    void populateComboBoxes();  // Remplit les ComboBox à partir des caches

    // --- Données membres ---
    Connection *m_connection;   // Pointeur vers l'objet Connection principal
    QList<Joueur> m_allPlayers; // Cache des joueurs pour ComboBox
    QList<Equipe> m_allTeams;   // Cache des équipes pour ComboBoxes
};

#endif // TRANSFERMANAGEMENTWIDGET_H
