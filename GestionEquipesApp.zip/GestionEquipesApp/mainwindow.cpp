// mainwindow.cpp (Sans logo dans l'UI)
#include "mainwindow.h"

// Includes Qt nécessaires
#include <QTabWidget>
#include <QVBoxLayout> // Pour le layout du centralWidget
#include <QLabel>      // Peut être retiré si non utilisé ailleurs
#include <QMessageBox>
#include <QStatusBar>
#include <QMetaObject>
#include <QDebug>
// Pas besoin de QToolBar, QPixmap ici

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent)
    // Initialiser les pointeurs
    , centralArea(nullptr)
    , tabWidget(nullptr)
    // Pas d'initialisation pour mainToolBar ou logoLabel
    , m_teamManagementTab(nullptr)
    , m_playerManagementTab(nullptr)
    , m_coachManagementTab(nullptr)
    , m_transferManagementTab(nullptr)
    , m_matchManagementTab(nullptr)
    , m_performanceTab(nullptr)
    , m_standingsTab(nullptr)
{
    setupUi();
    setupDatabase();
    setupTabs();
    setWindowTitle("Dribb Tech - Gestion d'Équipes"); // Garder le titre mis à jour
    resize(1000, 700); // Taille initiale
}

MainWindow::~MainWindow() {
    // Géré par Qt
}

void MainWindow::setupUi() {
    // --- Widget Central (Contient uniquement les onglets via un layout) ---
    centralArea = new QWidget(this);
    setCentralWidget(centralArea);
    QVBoxLayout *centralLayout = new QVBoxLayout(centralArea); // Layout simple pour le centralArea
    centralLayout->setContentsMargins(5,5,5,5); // Marges standard
    tabWidget = new QTabWidget(centralArea); // tabWidget enfant du centralArea
    centralLayout->addWidget(tabWidget); // tabWidget remplit le layout

    // --- Pas de barre d'outils ou de label pour le logo ici ---

    // --- Barre de Statut ---
    setStatusBar(new QStatusBar(this));
    statusBar()->showMessage("Prêt.");
}

// setupDatabase reste identique
void MainWindow::setupDatabase() {
    if (!m_dbConnection.createconnect()) {
        statusBar()->showMessage("Échec de la connexion à la base de données!", 0);
        QMessageBox::critical(this, "Erreur Base de Données",
                              "Impossible de se connecter à la base de données.\n"
                              "Vérifiez la configuration ODBC/DSN et la disponibilité de la base.\n"
                              "Voir la sortie de l'application pour plus de détails.", QMessageBox::Ok);
    } else {
        statusBar()->showMessage("Connecté à la base de données.", 5000);
    }
}

// setupTabs reste identique
void MainWindow::setupTabs() {
    if (!tabWidget) return;

    m_teamManagementTab = new TeamManagementWidget(&m_dbConnection, tabWidget);
    tabWidget->addTab(m_teamManagementTab, "Gestion Équipes");

    m_playerManagementTab = new PlayerManagementWidget(&m_dbConnection, tabWidget);
    tabWidget->addTab(m_playerManagementTab, "Gestion Joueurs");

    m_coachManagementTab = new CoachManagementWidget(&m_dbConnection, tabWidget);
    tabWidget->addTab(m_coachManagementTab, "Gestion Coachs");

    m_transferManagementTab = new TransferManagementWidget(&m_dbConnection, tabWidget);
    tabWidget->addTab(m_transferManagementTab, "Gestion Transferts");

    m_matchManagementTab = new MatchManagementWidget(&m_dbConnection, tabWidget);
    tabWidget->addTab(m_matchManagementTab, "Gestion Matchs");

    m_performanceTab = new PerformanceWidget(&m_dbConnection, tabWidget);
    tabWidget->addTab(m_performanceTab, "Analyse Performances");

    m_standingsTab = new StandingsWidget(&m_dbConnection, tabWidget);
    tabWidget->addTab(m_standingsTab, "Classement");
}
