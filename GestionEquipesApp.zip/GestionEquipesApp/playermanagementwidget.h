// playermanagementwidget.h (Corrigé - Structure basée sur .cpp et erreurs)
#ifndef PLAYERMANAGEMENTWIDGET_H
#define PLAYERMANAGEMENTWIDGET_H

#include <QWidget>
#include <QList> // Pour m_allTeams

// Includes Qt nécessaires (basé sur .cpp)
#include <QString>
#include <QDate>
#include <QComboBox> // <<< Include ajouté
class QTableWidget; class QPushButton; class QLineEdit; class QLabel; // Forward declarations
class QDateEdit; class QSpinBox; class QGroupBox; class QHBoxLayout;
class QVBoxLayout; class QFormLayout; class QTableWidgetItem; class QSqlDatabase; // Forward declarations

// Includes du projet
#include "connection.h"
#include "equipe.h" // Pour QList<Equipe> m_allTeams
// Assurez-vous que ce fichier existe et est correct
// #include "joueur.h" // Si vous avez une classe Joueur séparée

// Constante (peut être définie ici ou dans le .cpp)
// const int NO_TEAM_ID_PLAYER = -1; // Définie dans le .cpp actuellement

class PlayerManagementWidget : public QWidget
{
    Q_OBJECT

public:
    explicit PlayerManagementWidget(Connection *connection, QWidget *parent = nullptr);
    // ~PlayerManagementWidget(); // Ajoutez si nécessaire

private slots:
    void refreshPlayerList();
    void playerSelectionChanged();
    void prepareNewPlayer();
    void savePlayerData();
    void deleteSelectedPlayer();

private:
    // --- Widgets et Layouts membres (Ordre basé sur l'apparition dans .cpp) ---
    QHBoxLayout *mainLayout;
    QVBoxLayout *leftLayout;
    QVBoxLayout *rightLayout;
    QGroupBox *listGroupBox;
    QVBoxLayout *listVBoxLayout;
    QTableWidget *playerTableWidget;
    QPushButton *refreshButton;
    QGroupBox *detailsGroupBox;
    QFormLayout *detailsFormLayout;
    QLabel *idLabelInfo;
    QLabel *idLabelValue;
    QLabel *nameLabel;
    QLineEdit *nameLineEdit;
    QLabel *firstNameLabel;
    QLineEdit *firstNameLineEdit;
    QLabel *birthDateLabel;
    QDateEdit *birthDateEdit;
    QLabel *positionLabel;
    QLineEdit *positionLineEdit;
    QLabel *jerseyNumberLabel;
    QSpinBox *jerseyNumberSpinBox;
    QLabel *currentTeamLabel;
    QComboBox *currentTeamComboBox; // <<< Type QComboBox maintenant reconnu
    QHBoxLayout *actionButtonsLayout;
    QPushButton *newButton;
    QPushButton *saveButton;
    QPushButton *deleteButton;


    // --- Données membres ---
    Connection *m_connection;
    int m_currentPlayerId;
    int m_currentPlayerOldTeamId; // Pour gérer les changements d'équipe
    QList<Equipe> m_allTeams;   // Cache des équipes pour le ComboBox

    // --- Méthodes privées ---
    void setupUi();
    void connectSignalsSlots();
    void loadPlayersList();
    void loadTeamsCache();
    void populateTeamCombo();
    void populatePlayerDetails(int playerId);
    void clearForm();
    // Méthode utilitaire pour mettre à jour la table de liaison
    bool updatePlayerTeamLink(int playerId, int oldTeamId, int newTeamId, QSqlDatabase& db);

};

#endif // PLAYERMANAGEMENTWIDGET_H
