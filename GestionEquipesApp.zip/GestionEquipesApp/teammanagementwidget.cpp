// teammanagementwidget.cpp (Utilise Connection, logique SQL intégrée)
#include "teammanagementwidget.h"
#include "connection.h" // Include direct

// Includes Qt nécessaires
#include <QApplication> // Pour le curseur d'attente
#include <QTableWidget>
#include <QPushButton>
#include <QLineEdit>
#include <QLabel>
#include <QSpinBox>
#include <QComboBox>
#include <QListWidget>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QFormLayout>
#include <QHeaderView>
#include <QMessageBox>
#include <QDebug>
#include <QSet>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QVariant>
#include <stdexcept> // Pour std::runtime_error dans les transactions

// Constructeur prend Connection*
TeamManagementWidget::TeamManagementWidget(Connection *connection, QWidget *parent) :
    QWidget(parent),
    m_connection(connection), // Stocke le pointeur
    m_currentTeamId(-1)
{
    // Vérification essentielle
    if (!m_connection) {
        qCritical() << "FATAL: TeamManagementWidget a reçu un pointeur Connection nul!";
    }

    setupUi(); // Construit l'interface graphique
    connectSignalsSlots(); // Connecte les boutons, etc.

    // Charger les données initiales seulement si la connexion est établie
    if (m_connection && m_connection->database().isOpen()) {
        loadAvailablePlayers(); // Charge la liste globale des joueurs
        loadAvailableCoaches(); // Charge la liste globale des coachs
        loadTeamsList();        // Charge la liste des équipes dans la table
    } else {
        qWarning() << "Connexion DB non disponible lors de l'initialisation de TeamManagementWidget.";
        QMessageBox::warning(this, "Connexion Base de Données",
                             "La connexion à la base de données n'a pas pu être établie.\n"
                             "Les données des équipes ne peuvent pas être chargées ou sauvegardées.");
        // Désactiver les widgets si nécessaire
        detailsGroupBox->setEnabled(false);
        rosterGroupBox->setEnabled(false);
        leftGroupBox->setEnabled(false); // Ou juste les boutons d'action?
        saveButton->setEnabled(false);
        deleteButton->setEnabled(false);
        newButton->setEnabled(false);
    }
    clearForm(); // Efface le formulaire pour commencer
}

// --- setupUi ---
// Crée tous les widgets et les arrange dans les layouts
void TeamManagementWidget::setupUi() {
    mainLayout = new QHBoxLayout(this); leftLayout = new QVBoxLayout(); rightLayout = new QVBoxLayout();
    // Section Gauche (Tableau)
    leftGroupBox = new QGroupBox("Équipes Existantes", this); leftVboxLayout = new QVBoxLayout(leftGroupBox);
    teamTableWidget = new QTableWidget(leftGroupBox); teamTableWidget->setColumnCount(3);
    teamTableWidget->setHorizontalHeaderLabels({"ID", "Nom", "Classement"});
    teamTableWidget->setSelectionBehavior(QAbstractItemView::SelectRows); teamTableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    teamTableWidget->setColumnWidth(0, 50); teamTableWidget->setColumnWidth(1, 150); teamTableWidget->horizontalHeader()->setStretchLastSection(true);
    refreshButton = new QPushButton("Rafraîchir Liste", leftGroupBox); leftVboxLayout->addWidget(teamTableWidget); leftVboxLayout->addWidget(refreshButton); leftLayout->addWidget(leftGroupBox);
    // Section Droite (Formulaire Détails)
    detailsGroupBox = new QGroupBox("Détails de l'Équipe", this); detailsFormLayout = new QFormLayout(detailsGroupBox);
    idLabelInfo = new QLabel("ID:", detailsGroupBox); idLabelValue = new QLabel("N/A", detailsGroupBox); nameLabel = new QLabel("Nom:", detailsGroupBox);
    nameLineEdit = new QLineEdit(detailsGroupBox); rankLabel = new QLabel("Classement:", detailsGroupBox); rankSpinBox = new QSpinBox(detailsGroupBox); rankSpinBox->setRange(0,9999);
    coachLabel = new QLabel("Entraîneur Actuel:", detailsGroupBox); coachComboBox = new QComboBox(detailsGroupBox);
    detailsFormLayout->addRow(idLabelInfo, idLabelValue); detailsFormLayout->addRow(nameLabel, nameLineEdit); detailsFormLayout->addRow(rankLabel, rankSpinBox); detailsFormLayout->addRow(coachLabel, coachComboBox);
    rightLayout->addWidget(detailsGroupBox);
    // Section Droite (Formulaire Effectif)
    rosterGroupBox = new QGroupBox("Gestion de l'Effectif", this); rosterHBoxLayout = new QHBoxLayout(rosterGroupBox); availablePlayersVLayout = new QVBoxLayout();
    availablePlayersLabel = new QLabel("Joueurs Disponibles", rosterGroupBox); availablePlayersListWidget = new QListWidget(rosterGroupBox); availablePlayersListWidget->setSelectionMode(QAbstractItemView::ExtendedSelection);
    availablePlayersVLayout->addWidget(availablePlayersLabel); availablePlayersVLayout->addWidget(availablePlayersListWidget); addRemoveVLayout = new QVBoxLayout();
    addButton = new QPushButton(">> Ajouter >>", rosterGroupBox); removeButton = new QPushButton("<< Retirer <<", rosterGroupBox); addRemoveVLayout->addStretch();
    addRemoveVLayout->addWidget(addButton); addRemoveVLayout->addWidget(removeButton); addRemoveVLayout->addStretch(); teamPlayersVLayout = new QVBoxLayout();
    teamPlayersLabel = new QLabel("Joueurs dans l'Équipe", rosterGroupBox); teamPlayersListWidget = new QListWidget(rosterGroupBox); teamPlayersListWidget->setSelectionMode(QAbstractItemView::ExtendedSelection);
    teamPlayersVLayout->addWidget(teamPlayersLabel); teamPlayersVLayout->addWidget(teamPlayersListWidget); rosterHBoxLayout->addLayout(availablePlayersVLayout, 2); rosterHBoxLayout->addLayout(addRemoveVLayout, 1); rosterHBoxLayout->addLayout(teamPlayersVLayout, 2);
    rightLayout->addWidget(rosterGroupBox);
    // Section Droite (Boutons Action)
    actionButtonsLayout = new QHBoxLayout(); newButton = new QPushButton("Nouveau", this); saveButton = new QPushButton("Enregistrer", this); deleteButton = new QPushButton("Supprimer", this);
    actionButtonsLayout->addWidget(newButton); actionButtonsLayout->addWidget(saveButton); actionButtonsLayout->addWidget(deleteButton); actionButtonsLayout->addStretch();
    rightLayout->addLayout(actionButtonsLayout); rightLayout->addStretch();
    // Assemblage final
    mainLayout->addLayout(leftLayout, 1); mainLayout->addLayout(rightLayout, 2);
}

// --- connectSignalsSlots ---
// Connecte les signaux des widgets UI aux slots de cette classe
void TeamManagementWidget::connectSignalsSlots() {
    connect(teamTableWidget, &QTableWidget::itemSelectionChanged, this, &TeamManagementWidget::teamSelectionChanged);
    connect(refreshButton, &QPushButton::clicked, this, &TeamManagementWidget::refreshTeamList);
    connect(newButton, &QPushButton::clicked, this, &TeamManagementWidget::prepareNewTeam);
    connect(saveButton, &QPushButton::clicked, this, &TeamManagementWidget::saveTeamData);
    connect(deleteButton, &QPushButton::clicked, this, &TeamManagementWidget::deleteSelectedTeam);
    connect(addButton, &QPushButton::clicked, this, &TeamManagementWidget::addPlayersToTeamRoster);
    connect(removeButton, &QPushButton::clicked, this, &TeamManagementWidget::removePlayersFromTeamRoster);
}

// --- Implémentation des Slots ---

void TeamManagementWidget::refreshTeamList() {
    // Recharge les listes depuis la DB et réinitialise le formulaire
    if (m_connection && m_connection->database().isOpen()) {
        loadAvailablePlayers();
        loadAvailableCoaches();
        loadTeamsList();
    } else {
        QMessageBox::warning(this, "Connexion Base de Données", "La connexion n'est pas disponible pour rafraîchir.");
    }
    clearForm();
}

void TeamManagementWidget::teamSelectionChanged() {
    // Quand une ligne est sélectionnée dans la table, charge ses détails dans le formulaire
    QList<QTableWidgetItem*> selectedItems = teamTableWidget->selectedItems();
    if (selectedItems.isEmpty()) { return; }
    int selectedRow = teamTableWidget->row(selectedItems.first());
    if (selectedRow < 0) return;
    QTableWidgetItem* idItem = teamTableWidget->item(selectedRow, 0);
    if (!idItem) return;
    bool ok;
    int teamId = idItem->text().toInt(&ok);
    if (ok) { populateTeamDetails(teamId); } // Charge les détails de la DB
    else { qWarning() << "ID équipe invalide dans la table:" << idItem->text(); clearForm(); }
}

void TeamManagementWidget::prepareNewTeam() {
    // Réinitialise le formulaire pour une nouvelle saisie
    clearForm();
}

// Slot pour Sauvegarder (INSERT ou UPDATE)
void TeamManagementWidget::saveTeamData() {
    // Vérifier la connexion
    if (!m_connection || !m_connection->database().isOpen()) {
        QMessageBox::critical(this, "Erreur", "Connexion à la base de données non disponible."); return;
    }
    // Récupérer les données du formulaire
    Equipe equipe = getCurrentFormData();
    // Validation simple
    if (equipe.getNom().isEmpty()) {
        QMessageBox::warning(this, "Champ Requis", "Le nom de l'équipe est obligatoire."); nameLineEdit->setFocus(); return;
    }

    QSqlDatabase db = m_connection->database(); // Obtenir l'objet DB
    bool success = false; QString finalMessage;

    // Démarrer une transaction
    if (!db.transaction()) {
        finalMessage = "Impossible de démarrer la transaction: " + db.lastError().text(); qWarning() << finalMessage;
        QMessageBox::critical(this, "Erreur Transaction", finalMessage); return;
    }
    QApplication::setOverrideCursor(Qt::WaitCursor); // Curseur d'attente

    try {
        QSqlQuery query(db); // Créer la requête DANS la transaction
        if (m_currentTeamId < 0) { // --- CREATION (INSERT) ---
            // 1. Obtenir nouvel ID (Syntaxe Oracle !)
            query.prepare("SELECT equipe_seq.NEXTVAL FROM DUAL"); // !!! Adapter si DB != Oracle !!!
            if (!query.exec()) throw std::runtime_error("Erreur obtention ID équipe: " + query.lastError().text().toStdString());
            int newId = -1; if (query.next()) newId = query.value(0).toInt(); else throw std::runtime_error("Impossible de récupérer le nouvel ID équipe.");
            equipe.setId(newId);
            // 2. Insérer l'équipe
            query.prepare("INSERT INTO equipes (id_equipe, nom, classement, id_entraineur_actuel) VALUES (:id, :nom, :cls, :id_coach)");
            query.bindValue(":id", equipe.getId()); query.bindValue(":nom", equipe.getNom()); query.bindValue(":cls", equipe.getClassement());
            query.bindValue(":id_coach", equipe.getIdEntraineurActuel() < 0 ? QVariant() : equipe.getIdEntraineurActuel());
            if (!query.exec()) throw std::runtime_error("Erreur insertion équipe: " + query.lastError().text().toStdString());
            // 3. Mettre à jour l'effectif
            if (!updateEquipeEffectifInDb(equipe.getId(), equipe.getEffectifIds(), db)) throw std::runtime_error("Erreur interne MAJ effectif.");
            success = true; finalMessage = QString("Équipe '%1' créée (ID: %2).").arg(equipe.getNom()).arg(equipe.getId());
        } else { // --- MISE A JOUR (UPDATE) ---
            equipe.setId(m_currentTeamId);
            // 1. Mettre à jour l'équipe
            query.prepare("UPDATE equipes SET nom = :nom, classement = :cls, id_entraineur_actuel = :id_coach WHERE id_equipe = :id");
            query.bindValue(":nom", equipe.getNom()); query.bindValue(":cls", equipe.getClassement());
            query.bindValue(":id_coach", equipe.getIdEntraineurActuel() < 0 ? QVariant() : equipe.getIdEntraineurActuel());
            query.bindValue(":id", equipe.getId());
            if (!query.exec()) throw std::runtime_error("Erreur mise à jour équipe: " + query.lastError().text().toStdString());
            // 2. Mettre à jour l'effectif
            if (!updateEquipeEffectifInDb(equipe.getId(), equipe.getEffectifIds(), db)) throw std::runtime_error("Erreur interne MAJ effectif.");
            success = true; finalMessage = QString("Équipe '%1' mise à jour.").arg(equipe.getNom());
        }
        // Valider la transaction
        if (!db.commit()) { success = false; throw std::runtime_error("Erreur commit: " + db.lastError().text().toStdString()); }
        QMessageBox::information(this, "Succès", finalMessage);
    } catch (const std::runtime_error &e) {
        qWarning() << "Erreur saveTeamData, rollback..." << e.what(); db.rollback();
        QMessageBox::critical(this, "Erreur Sauvegarde", QString("Échec: %1").arg(e.what())); success = false;
    }
    QApplication::restoreOverrideCursor(); // Restaurer curseur
    if (success) { loadTeamsList(); clearForm(); } // Mettre à jour UI si succès
}

// Slot pour Supprimer
void TeamManagementWidget::deleteSelectedTeam() {
    if (m_currentTeamId < 0) { QMessageBox::warning(this, "Action Impossible", "Sélectionner une équipe à supprimer."); return; }
    if (!m_connection || !m_connection->database().isOpen()) { QMessageBox::critical(this, "Erreur", "Connexion DB non disponible."); return; }

    QString teamName = nameLineEdit->text();
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Confirmation", QString("Supprimer '%1' (ID: %2)?\nLiens joueurs retirés.").arg(teamName).arg(m_currentTeamId), QMessageBox::Yes | QMessageBox::No, QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        QSqlDatabase db = m_connection->database(); bool success = false;
        if (!db.transaction()) { qWarning() << "Échec démarrage transaction delete: " + db.lastError().text(); QMessageBox::critical(this, "Erreur Transaction", "Impossible de démarrer."); return; }
        QApplication::setOverrideCursor(Qt::WaitCursor);
        try {
            QSqlQuery query(db);
            // 1. Supprimer liens EQUIPE_JOUEURS
            query.prepare("DELETE FROM equipe_joueurs WHERE id_equipe = :id"); query.bindValue(":id", m_currentTeamId);
            if (!query.exec()) throw std::runtime_error("Erreur suppression liens effectif: " + query.lastError().text().toStdString());
            qInfo() << query.numRowsAffected() << "liens effectif supprimés pour equipe" << m_currentTeamId;
            // TODO: Supprimer/Mettre à jour autres liens (Matchs, Transferts, Joueurs.id_equipe_actuelle si pas ON DELETE SET NULL)
            // Exemple: query.prepare("UPDATE JOUEURS SET id_equipe_actuelle = NULL WHERE id_equipe_actuelle = :id"); query.bindValue(":id", m_currentTeamId); query.exec();
            // 2. Supprimer l'équipe
            query.prepare("DELETE FROM equipes WHERE id_equipe = :id"); query.bindValue(":id", m_currentTeamId);
            if (!query.exec()) throw std::runtime_error("Erreur suppression équipe: " + query.lastError().text().toStdString());
            int rowsAffected = query.numRowsAffected();
            // Commit
            if (!db.commit()) throw std::runtime_error("Erreur commit suppression: " + db.lastError().text().toStdString());
            if (rowsAffected > 0) { QMessageBox::information(this, "Succès", QString("Équipe '%1' supprimée.").arg(teamName)); success = true; }
            else { QMessageBox::warning(this, "Avertissement", QString("Équipe '%1' non trouvée.").arg(teamName)); success = true; }
        } catch (const std::runtime_error &e) {
            qWarning() << "Erreur deleteSelectedTeam, rollback..." << e.what(); db.rollback();
            QMessageBox::critical(this, "Erreur Suppression", QString("Échec: %1").arg(e.what())); success = false;
        }
        QApplication::restoreOverrideCursor();
        if (success) { loadTeamsList(); clearForm(); } // Mettre à jour UI
    }
}

// Slots pour gérer les listes de joueurs (UI seulement)
void TeamManagementWidget::addPlayersToTeamRoster() {
    QList<QListWidgetItem*> selectedItems = availablePlayersListWidget->selectedItems(); if (selectedItems.isEmpty()) return;
    QSet<int> currentTeamPlayerIdsSet; for(int i = 0; i < teamPlayersListWidget->count(); ++i) currentTeamPlayerIdsSet.insert(teamPlayersListWidget->item(i)->data(Qt::UserRole).toInt());
    for(QListWidgetItem* item : selectedItems) { int playerId = item->data(Qt::UserRole).toInt(); if (!currentTeamPlayerIdsSet.contains(playerId)) teamPlayersListWidget->addItem(item->clone()); }
    qDeleteAll(availablePlayersListWidget->selectedItems()); teamPlayersListWidget->sortItems();
}
void TeamManagementWidget::removePlayersFromTeamRoster() {
    QList<QListWidgetItem*> selectedItems = teamPlayersListWidget->selectedItems(); if (selectedItems.isEmpty()) return;
    for(QListWidgetItem* item : selectedItems) availablePlayersListWidget->addItem(item->clone());
    qDeleteAll(teamPlayersListWidget->selectedItems()); availablePlayersListWidget->sortItems();
}

// --- Implémentation des Fonctions Privées ---

// Charge la liste des équipes depuis la DB
void TeamManagementWidget::loadTeamsList() {
    if (!m_connection || !m_connection->database().isOpen()) { qWarning() << "loadTeamsList: Connexion DB indisponible."; teamTableWidget->setRowCount(0); return; }
    teamTableWidget->setRowCount(0); QApplication::setOverrideCursor(Qt::WaitCursor);
    QSqlDatabase db = m_connection->database(); QSqlQuery query(db);
    if (query.exec("SELECT id_equipe, nom, classement FROM equipes ORDER BY nom")) {
        int row = 0;
        while (query.next()) {
            teamTableWidget->insertRow(row);
            QTableWidgetItem *idItem = new QTableWidgetItem(query.value(0).toString()); idItem->setFlags(idItem->flags() & ~Qt::ItemIsEditable);
            QTableWidgetItem *nomItem = new QTableWidgetItem(query.value(1).toString()); nomItem->setFlags(nomItem->flags() & ~Qt::ItemIsEditable);
            QTableWidgetItem *rankItem = new QTableWidgetItem(query.value(2).toString()); rankItem->setFlags(rankItem->flags() & ~Qt::ItemIsEditable);
            teamTableWidget->setItem(row, 0, idItem); teamTableWidget->setItem(row, 1, nomItem); teamTableWidget->setItem(row, 2, rankItem);
            row++;
        }
    } else { qWarning() << "Erreur chargement équipes:" << query.lastError().text(); QMessageBox::critical(this, "Erreur Chargement", "Impossible de charger équipes.\n" + query.lastError().text()); }
    QApplication::restoreOverrideCursor(); teamTableWidget->resizeColumnsToContents(); teamTableWidget->horizontalHeader()->setStretchLastSection(true);
}

// Charge la liste complète des joueurs (cache)
void TeamManagementWidget::loadAvailablePlayers() {
    if (!m_connection || !m_connection->database().isOpen()) { qWarning() << "loadAvailablePlayers: Connexion DB indisponible."; m_allPlayers.clear(); updatePlayerLists({}); return; }
    QApplication::setOverrideCursor(Qt::WaitCursor); m_allPlayers.clear();
    QSqlDatabase db = m_connection->database(); QSqlQuery query(db);
    if(query.exec("SELECT id_joueur, nom, prenom FROM joueurs ORDER BY nom, prenom")) {
        while(query.next()) m_allPlayers.append(Joueur(query.value(0).toInt(), query.value(1).toString(), query.value(2).toString()));
        qInfo() << "Cache joueurs rechargé:" << m_allPlayers.count() << "joueurs.";
    } else { qWarning() << "Erreur chargement cache joueurs:" << query.lastError().text(); }
    QApplication::restoreOverrideCursor(); updatePlayerLists({});
}

// Charge la liste complète des coachs (cache + ComboBox)
void TeamManagementWidget::loadAvailableCoaches() {
    if (!m_connection || !m_connection->database().isOpen()) { qWarning() << "loadAvailableCoaches: Connexion DB indisponible."; m_allCoaches.clear(); coachComboBox->clear(); coachComboBox->addItem("Aucun", -1); return; }
    QApplication::setOverrideCursor(Qt::WaitCursor); m_allCoaches.clear();
    QSqlDatabase db = m_connection->database(); QSqlQuery query(db);
    if(query.exec("SELECT id_coach, nom, prenom FROM coachs ORDER BY nom, prenom")) {
        while(query.next()) m_allCoaches.append(Coach(query.value(0).toInt(), query.value(1).toString(), query.value(2).toString()));
        qInfo() << "Cache coachs rechargé:" << m_allCoaches.count() << "coachs.";
    } else { qWarning() << "Erreur chargement cache coachs:" << query.lastError().text(); }
    QApplication::restoreOverrideCursor();
    coachComboBox->clear(); coachComboBox->addItem("Aucun", -1);
    for(const Coach &coach : m_allCoaches) coachComboBox->addItem(QString("%1 %2").arg(coach.getPrenom()).arg(coach.getNom()), coach.getId());
}

// Charge les détails d'une équipe spécifique et remplit le formulaire
void TeamManagementWidget::populateTeamDetails(int teamId) {
    if (!m_connection || !m_connection->database().isOpen()) { qWarning() << "populateTeamDetails: Connexion DB indisponible."; clearForm(); return; }
    QApplication::setOverrideCursor(Qt::WaitCursor);
    QSqlDatabase db = m_connection->database(); QSqlQuery query(db);
    query.prepare("SELECT id_equipe, nom, classement, id_entraineur_actuel FROM equipes WHERE id_equipe = :id"); query.bindValue(":id", teamId);
    Equipe equipe;
    if (query.exec() && query.next()) {
        equipe.setId(query.value(0).toInt()); equipe.setNom(query.value(1).toString()); equipe.setClassement(query.value(2).toInt());
        equipe.setIdEntraineurActuel(query.value(3).isNull() ? -1 : query.value(3).toInt());
        equipe.setEffectifIds(getEquipeJoueurIdsFromDb(teamId)); // Appel helper
        m_currentTeamId = equipe.getId(); idLabelValue->setText(QString::number(equipe.getId())); nameLineEdit->setText(equipe.getNom());
        rankSpinBox->setValue(equipe.getClassement()); int coachIndex = coachComboBox->findData(equipe.getIdEntraineurActuel());
        coachComboBox->setCurrentIndex(qMax(0, coachIndex)); updatePlayerLists(equipe.getEffectifIds());
        deleteButton->setEnabled(true); saveButton->setText("Enregistrer Modifications");
    } else {
        qWarning() << "Erreur chargement équipe ID" << teamId << ":" << query.lastError().text();
        QMessageBox::warning(this, "Non trouvé", QString("Équipe ID %1 non chargée.").arg(teamId)); clearForm();
    }
    QApplication::restoreOverrideCursor();
}

// Met à jour les deux listes de joueurs (disponibles et dans l'équipe)
void TeamManagementWidget::updatePlayerLists(const QList<int> &teamPlayerIds) {
    availablePlayersListWidget->clear(); teamPlayersListWidget->clear();
    QSet<int> teamIdsSet(teamPlayerIds.constBegin(), teamPlayerIds.constEnd()); // Correction ici
    for (const Joueur &player : m_allPlayers) {
        QListWidgetItem *item = new QListWidgetItem(QString("%1 %2 (ID:%3)").arg(player.getPrenom()).arg(player.getNom()).arg(player.getId()));
        item->setData(Qt::UserRole, player.getId());
        if (teamIdsSet.contains(player.getId())) teamPlayersListWidget->addItem(item);
        else availablePlayersListWidget->addItem(item);
    }
    availablePlayersListWidget->sortItems(); teamPlayersListWidget->sortItems();
}

// Réinitialise le formulaire
void TeamManagementWidget::clearForm() {
    m_currentTeamId = -1; idLabelValue->setText("Nouveau"); nameLineEdit->clear(); rankSpinBox->setValue(0);
    coachComboBox->setCurrentIndex(0); teamTableWidget->clearSelection(); updatePlayerLists({});
    deleteButton->setEnabled(false); saveButton->setText("Créer Équipe"); nameLineEdit->setFocus();
}

// Récupère les données du formulaire
Equipe TeamManagementWidget::getCurrentFormData() {
    Equipe equipe; equipe.setNom(nameLineEdit->text().trimmed()); equipe.setClassement(rankSpinBox->value());
    equipe.setIdEntraineurActuel(coachComboBox->currentData().toInt()); QList<int> effectifIds;
    for(int i = 0; i < teamPlayersListWidget->count(); ++i) effectifIds.append(teamPlayersListWidget->item(i)->data(Qt::UserRole).toInt());
    equipe.setEffectifIds(effectifIds); return equipe;
}

// --- Implémentation des Fonctions Helper DB ---

// Récupère les IDs des joueurs d'une équipe
QList<int> TeamManagementWidget::getEquipeJoueurIdsFromDb(int equipeId) {
    if (!m_connection || !m_connection->database().isOpen()) { qWarning() << "getEquipeJoueurIdsFromDb: Connexion DB indisponible."; return {}; }
    QList<int> ids; QSqlDatabase db = m_connection->database(); QSqlQuery query(db);
    query.prepare("SELECT id_joueur FROM equipe_joueurs WHERE id_equipe = :id"); query.bindValue(":id", equipeId);
    if (query.exec()) { while(query.next()) ids.append(query.value(0).toInt()); }
    else { qWarning() << "Erreur getEquipeJoueurIdsFromDb pour equipe" << equipeId << query.lastError().text(); } return ids;
}

// Met à jour la table de liaison EQUIPE_JOUEURS (appelée dans une transaction)
bool TeamManagementWidget::updateEquipeEffectifInDb(int equipeId, const QList<int> &newJoueurIds, QSqlDatabase& db) {
    QSqlQuery queryDelete(db); QSqlQuery queryInsert(db);
    try {
        queryDelete.prepare("DELETE FROM equipe_joueurs WHERE id_equipe = :id"); queryDelete.bindValue(":id", equipeId);
        if (!queryDelete.exec()) throw std::runtime_error("Erreur suppression anciens liens effectif: " + queryDelete.lastError().text().toStdString());
        if (!newJoueurIds.isEmpty()) {
            queryInsert.prepare("INSERT INTO equipe_joueurs (id_equipe, id_joueur) VALUES (:id_equipe, :id_joueur)");
            QVariantList eqIds, jIds; for(int jid : newJoueurIds) { eqIds << equipeId; jIds << jid; }
            queryInsert.bindValue(":id_equipe", eqIds); queryInsert.bindValue(":id_joueur", jIds);
            if (!queryInsert.execBatch()) throw std::runtime_error("Erreur execBatch effectif: " + queryInsert.lastError().text().toStdString());
        } qInfo() << "Effectif MAJ dans DB (Widget) pour equipe" << equipeId; return true;
    } catch (const std::runtime_error &e) { qWarning() << "Erreur dans updateEquipeEffectifInDb:" << e.what(); return false; }
}
