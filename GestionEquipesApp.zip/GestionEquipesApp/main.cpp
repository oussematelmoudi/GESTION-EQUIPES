// main.cpp (Corrigé pour inclure l'icône de l'application)
#include "mainwindow.h" // Include de la fenêtre principale

#include <QApplication>
#include <QStyleFactory>
#include <QFile>       // Pour lire le fichier QSS
#include <QTextStream> // Pour lire le fichier QSS
#include <QIcon>       // <<< AJOUTÉ: Pour définir l'icône
#include <QDebug>

int main(int argc, char *argv[]) {
    // Initialise l'application Qt
    QApplication a(argc, argv);

    // --- Définir l'icône de l'application ---
    // Assurez-vous que photo.png est dans vos ressources Qt (resources.qrc)
    // avec l'alias "photo.png" au préfixe "/" (ou adaptez si besoin)
    a.setWindowIcon(QIcon(":/photo.png")); // <<< LIGNE AJOUTÉE

    // --- Chargement et Application du Style QSS ---
    // Chemin vers le fichier DANS les ressources Qt (notez le préfixe ':')
    QFile styleFile(":/style.css"); // <<< VOUS UTILISEZ CE FICHIER EXTERNE

    // Tenter d'ouvrir le fichier en lecture seule et en mode texte
    if (styleFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
        // Créer un flux texte pour lire le fichier
        QTextStream stream(&styleFile);
        // Lire tout le contenu du fichier dans une chaîne
        QString styleSheet = stream.readAll();
        // Appliquer la feuille de style à l'application entière
        a.setStyleSheet(styleSheet);
        // Fermer le fichier
        styleFile.close();
        qInfo() << "Feuille de style ':/style.css' chargée depuis les ressources et appliquée.";
    } else {
        // Afficher un avertissement si le fichier n'a pas pu être ouvert
        // (Vérifiez que le fichier est bien dans resources.qrc et que le chemin est correct)
        qWarning() << "ERREUR: Impossible d'ouvrir le fichier de style ':/style.css' depuis les ressources.";
        // L'application utilisera le style par défaut ou le style Fusion si défini ci-dessous
    }
    // -----------------------------------------------

    // Appliquer un style de base (Fusion est souvent un bon choix sous QSS)
    // Il sert de fallback et définit certains comportements de base.
    // Vous pouvez commenter cette partie si votre QSS est très complet.
    QString baseStyle = QStyleFactory::keys().contains("Fusion", Qt::CaseInsensitive) ? "Fusion" : "";
    if (!baseStyle.isEmpty()) {
        QApplication::setStyle(QStyleFactory::create(baseStyle));
        // qInfo() << "Style de base 'Fusion' appliqué."; // Log optionnel
    }

    // Créer et afficher la fenêtre principale
    MainWindow w;
    // Donner un nom d'objet si votre CSS utilise #MainWindow
    w.setObjectName("MainWindow");
    w.setMinimumSize(1100, 700); // Donner une taille minimale raisonnable
    w.show();                    // Afficher la fenêtre

    // Lancer la boucle d'événements Qt et retourner le code de sortie
    return a.exec();
}
