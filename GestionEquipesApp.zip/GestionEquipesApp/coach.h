// coach.h
#ifndef COACH_H
#define COACH_H

#include <QString>
#include <QList> // Pour historique potentiel (non utilisé en DB pour l'instant)
#include <QDate> // Ajout pour date_naissance

class Coach {
public:
    Coach();
    Coach(int id, const QString &nom, const QString &prenom); // Constructeur basique

    // Getters
    int getId() const;
    QString getNom() const;
    QString getPrenom() const;
    QDate getDateNaissance() const; // Ajouté
    QString getLicence() const; // Ajouté

    // Setters
    void setId(int id);
    void setNom(const QString &nom);
    void setPrenom(const QString &prenom);
    void setDateNaissance(const QDate &date); // Ajouté
    void setLicence(const QString &licence); // Ajouté

private:
    int m_id;
    QString m_nom;
    QString m_prenom;
    QDate m_dateNaissance; // Ajouté
    QString m_licence; // Ajouté
    // QList<int> m_historiqueEquipesIds; // Non persisté tel quel
};

#endif // COACH_H
