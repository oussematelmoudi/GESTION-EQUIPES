// equipe.h
#ifndef EQUIPE_H
#define EQUIPE_H

#include <QString>
#include <QList>
#include <QVariant>

class Equipe {
public:
    Equipe();
    Equipe(int id, const QString &nom, int classement = 0, int idCoach = -1);

    // Getters
    int getId() const;
    QString getNom() const;
    int getClassement() const;
    int getIdEntraineurActuel() const;
    QList<int> getEffectifIds() const;
    QList<int> getHistoriqueEntraineursIds() const; // Non utilisé actuellement dans la logique DB
    QList<int> getHistoriqueMatchsIds() const; // Non utilisé actuellement dans la logique DB
    int getNombreJoueurs() const;

    // Setters
    void setId(int id);
    void setNom(const QString &nom);
    void setClassement(int classement);
    void setIdEntraineurActuel(int idCoach);
    void setEffectifIds(const QList<int> &ids);
    void setHistoriqueEntraineursIds(const QList<int> &ids); // Non utilisé actuellement
    void setHistoriqueMatchsIds(const QList<int> &ids); // Non utilisé actuellement

    // Méthodes utilitaires
    void ajouterJoueurId(int joueurId);
    void retirerJoueurId(int joueurId);
    void ajouterEntraineurHistoriqueId(int coachId); // Non utilisé actuellement
    void ajouterMatchHistoriqueId(int matchId); // Non utilisé actuellement

private:
    int m_id;
    QString m_nom;
    int m_classement;
    int m_idEntraineurActuel;
    QList<int> m_effectifIds; // Liste des IDs des joueurs dans l'équipe
    QList<int> m_historiqueEntraineursIds; // Stockage simple, non persisté tel quel
    QList<int> m_historiqueMatchsIds; // Stockage simple, non persisté tel quel
};

#endif // EQUIPE_H
