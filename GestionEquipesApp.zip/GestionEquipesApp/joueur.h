// joueur.h
#ifndef JOUEUR_H
#define JOUEUR_H

#include <QString>
#include <QDate> // Ajout pour date_naissance

class Joueur {
public:
    Joueur();
    Joueur(int id, const QString &nom, const QString &prenom); // Constructeur basique
    // Ajouter un constructeur plus complet si nécessaire

    // Getters
    int getId() const;
    QString getNom() const;
    QString getPrenom() const;
    QDate getDateNaissance() const; // Ajouté
    QString getPosition() const; // Ajouté
    int getNumeroMaillot() const; // Ajouté
    int getIdEquipeActuelle() const; // Ajouté

    // Setters
    void setId(int id);
    void setNom(const QString &nom);
    void setPrenom(const QString &prenom);
    void setDateNaissance(const QDate &date); // Ajouté
    void setPosition(const QString &position); // Ajouté
    void setNumeroMaillot(int numero); // Ajouté
    void setIdEquipeActuelle(int idEquipe); // Ajouté

private:
    int m_id;
    QString m_nom;
    QString m_prenom;
    QDate m_dateNaissance; // Ajouté
    QString m_position; // Ajouté
    int m_numeroMaillot; // Ajouté
    int m_idEquipeActuelle; // Ajouté (-1 ou 0 si NULL)
};

#endif // JOUEUR_H
