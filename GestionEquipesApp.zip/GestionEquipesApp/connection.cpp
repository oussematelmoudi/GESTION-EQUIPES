// connection.cpp (Corrigé)
#include "connection.h" // Include direct
// QDebug est déjà inclus via connection.h

// Dans le constructeur de Connection (connection.cpp)
Connection::Connection()
{
    connectionName = "MaConnexionDirecteODBC"; // Nouveau nom pour test

    if (QSqlDatabase::contains(connectionName)) {
        db = QSqlDatabase::database(connectionName);
        qInfo() << "Réutilisation de la connexion directe existante:" << connectionName;
    } else {
        db = QSqlDatabase::addDatabase("QODBC", connectionName);
        qInfo() << "Nouvelle connexion directe ODBC ajoutée avec le nom:" << connectionName;

        // --- Configuration via Chaîne de Connexion Directe ---

        // 1. Trouvez ce nom dans l'Admin ODBC > Drivers (ex: "Oracle in OraClient11g_home1")
        QString driverName = "Oracle in XE"; // <<<=== METTEZ LE VRAI NOM ICI

        // 2. Informations de votre tnsnames.ora
        QString hostName = "souma";
        QString port = "1521";
        QString serviceName = "XE";
        QString uid = "DRIBBTECH";
        QString pwd = "DRIBBTECH";

        // 3. Construction de la chaîne (adaptez si ce format ne marche pas pour votre driver)
        QString connectString = QString("Driver={%1};Dbq=//%2:%3/%4;Uid=%5;Pwd=%6;")
                                    .arg(driverName)
                                    .arg(hostName)
                                    .arg(port)
                                    .arg(serviceName)
                                    .arg(uid)
                                    .arg(pwd);

        // 4. Utiliser la chaîne complète comme "Database Name" pour ODBC
        db.setDatabaseName(connectString);
        qInfo() << "Configuration avec chaîne directe (mot de passe masqué):" << QString("Driver={%1};Dbq=//%2:%3/%4;Uid=%5;Pwd=*****;").arg(driverName).arg(hostName).arg(port).arg(serviceName).arg(uid);

        // 5. Ne PAS appeler setUserName/setPassword séparément ici
        // db.setUserName("DRIBBTECH"); // INUTILE
        // db.setPassword("DRIBBTECH"); // INUTILE
    }
}

Connection::~Connection()
{
    // Ferme la connexion si elle est ouverte
    closeconnect();
    // Retire la connexion nommée du pool global de Qt pour un nettoyage propre
    // Vérifier si la connexion existe toujours avant de la retirer
    if (QSqlDatabase::contains(connectionName)) {
        QSqlDatabase::removeDatabase(connectionName);
        qInfo() << "Connexion retirée du pool:" << connectionName;
    }
}

// Tente d'ouvrir la connexion stockée dans le membre 'db'
bool Connection::createconnect()
{
    // Vérifier si la connexion est déjà ouverte
    if (db.isOpen()) {
        // qInfo() << "La connexion" << connectionName << "est déjà ouverte."; // Peut être verbeux
        return true; // Déjà connectée avec succès
    }

    // Tenter d'ouvrir la connexion configurée dans le constructeur
    if (db.open()) {
        qInfo() << "Connexion ODBC réussie (DSN:" << db.databaseName() << ") via" << connectionName;
        return true; // Succès
    } else {
        // Afficher l'erreur détaillée fournie par Qt/ODBC si l'ouverture échoue
        qWarning() << "ERREUR de connexion ODBC (" << connectionName << "):"
                   << db.lastError().driverText() << "[Driver]" // Message du driver ODBC
                   << db.lastError().databaseText() << "[Database]" // Message de la DB (si disponible)
                   << "(DSN:" << db.databaseName() << ")";
        return false; // Échec
    }
}

// Ferme la connexion si elle est ouverte
void Connection::closeconnect()
{
    if (db.isOpen()) {
        db.close();
        qInfo() << "Connexion ODBC fermée:" << connectionName;
    }
}

// Retourne une référence à l'objet db membre pour utilisation externe (création de QSqlQuery)
QSqlDatabase& Connection::database()
{
    // Il est de la responsabilité de l'appelant de vérifier si la connexion
    // est ouverte avant d'utiliser cet objet pour des requêtes.
    // Exemple: if(connectionObj.database().isOpen()) { QSqlQuery q(connectionObj.database()); ... }
    return db;
}

/* Optionnel: Version constante si nécessaire
const QSqlDatabase& Connection::database() const
{
    return db;
}
*/
