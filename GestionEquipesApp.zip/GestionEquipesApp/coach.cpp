// coach.cpp
#include "coach.h" // Include direct

Coach::Coach() : m_id(-1) {}

Coach::Coach(int id, const QString &nom, const QString &prenom) :
    m_id(id),
    m_nom(nom),
    m_prenom(prenom)
{}

// --- Getters ---
int Coach::getId() const { return m_id; }
QString Coach::getNom() const { return m_nom; }
QString Coach::getPrenom() const { return m_prenom; }
QDate Coach::getDateNaissance() const { return m_dateNaissance; }
QString Coach::getLicence() const { return m_licence; }

// --- Setters ---
void Coach::setId(int id) { m_id = id; }
void Coach::setNom(const QString &nom) { m_nom = nom; }
void Coach::setPrenom(const QString &prenom) { m_prenom = prenom; }
void Coach::setDateNaissance(const QDate &date) { m_dateNaissance = date; }
void Coach::setLicence(const QString &licence) { m_licence = licence; }
