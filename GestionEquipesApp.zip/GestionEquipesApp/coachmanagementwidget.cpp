// coachmanagementwidget.cpp (Avec Historique Complet Modifiable)
#include "coachmanagementwidget.h"
#include "coachhistorydialog.h" // <<< Inclure le nouveau dialogue

// Includes Qt nécessaires
#include <QApplication>
#include <QTableWidget>
#include <QPushButton>
#include <QLineEdit>
#include <QLabel>
#include <QDateEdit>
#include <QCalendarWidget> // Included for QDateEdit popup
#include <QGroupBox>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QFormLayout>
#include <QHeaderView>
#include <QMessageBox>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QVariant>
#include <stdexcept> // Included for exception handling
#include <QFont>     // Added for setBold
// #include <QSql>      // <<< REMOVED - No longer needed for QSql::Null

// Constructeur (Initializer list reordered to match declaration in .h)
CoachManagementWidget::CoachManagementWidget(Connection *connection, QWidget *parent) :
    QWidget(parent),
    // --- Widgets et Layouts membres --- (Initialize in declaration order from .h)
    mainLayout(nullptr),
    leftLayout(nullptr),
    rightLayout(nullptr),
    listGroupBox(nullptr),
    listVBoxLayout(nullptr),
    coachTableWidget(nullptr),
    refreshButton(nullptr),
    detailsGroupBox(nullptr),
    detailsFormLayout(nullptr),
    idLabelInfo(nullptr), idLabelValue(nullptr), nameLabel(nullptr), firstNameLabel(nullptr), birthDateLabel(nullptr), licenceLabel(nullptr), // Order within line doesn't matter for initialization
    nameLineEdit(nullptr), firstNameLineEdit(nullptr), licenceLineEdit(nullptr), // Order within line doesn't matter
    birthDateEdit(nullptr),
    actionButtonsLayout(nullptr),
    newButton(nullptr), saveButton(nullptr), deleteButton(nullptr), // Order within line doesn't matter
    historyGroupBox(nullptr),
    historyVBoxLayout(nullptr),
    historyTableWidget(nullptr),
    historyButtonsLayout(nullptr),
    addHistoryButton(nullptr),
    editHistoryButton(nullptr),
    deleteHistoryButton(nullptr),
    // --- Données membres --- (Initialize in declaration order from .h)
    m_connection(connection),
    m_currentCoachId(-1),
    m_teamsMap()              // Default constructor called
{
    if (!m_connection) {
        qCritical() << "FATAL: CoachManagementWidget a reçu un pointeur Connection nul!";
        setEnabled(false);
    }

    setupUi();
    connectSignalsSlots();

    // Try connecting if not already open
    if (!m_connection->database().isOpen()) {
        if (!m_connection->createconnect()) {
            qWarning() << "Connexion DB non disponible lors de l'initialisation de CoachManagementWidget.";
            QMessageBox::warning(this, "Connexion Base de Données",
                                 "La connexion à la base de données n'est pas disponible.\n"
                                 "Les données des coachs ne peuvent pas être gérées.");
            // Disable relevant widgets if connection fails
            if(detailsGroupBox) detailsGroupBox->setEnabled(false);
            if(listGroupBox) listGroupBox->setEnabled(false);
            if(saveButton) saveButton->setEnabled(false);
            if(deleteButton) deleteButton->setEnabled(false);
            if(newButton) newButton->setEnabled(false);
            if(historyGroupBox) historyGroupBox->setEnabled(false);
        }
    }

    // Load data if connection is now open
    if (m_connection->database().isOpen()) {
        loadTeamsCache(); // Load teams for history dialog
        loadCoachesList(); // Load coach list for the table
    }

    clearForm(); // Initialize form state
}

// Crée l'interface utilisateur
void CoachManagementWidget::setupUi() {
    mainLayout = new QHBoxLayout(this);
    leftLayout = new QVBoxLayout();
    rightLayout = new QVBoxLayout();

    // --- Section Gauche : Liste Coachs ---
    listGroupBox = new QGroupBox("Coachs Existants", this);
    listVBoxLayout = new QVBoxLayout(listGroupBox);
    coachTableWidget = new QTableWidget(listGroupBox);
    coachTableWidget->setColumnCount(4);
    coachTableWidget->setHorizontalHeaderLabels({"ID", "Nom", "Prénom", "Licence"});
    coachTableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    coachTableWidget->setSelectionMode(QAbstractItemView::SingleSelection);
    coachTableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    coachTableWidget->setColumnWidth(0, 50); // ID width
    coachTableWidget->setColumnWidth(3, 100); // Licence width
    coachTableWidget->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch); // Nom stretch
    coachTableWidget->horizontalHeader()->setSectionResizeMode(2, QHeaderView::Stretch); // Prénom stretch
    coachTableWidget->setAlternatingRowColors(true);
    coachTableWidget->verticalHeader()->setVisible(false);
    coachTableWidget->setSortingEnabled(true); // Enable sorting
    refreshButton = new QPushButton("Rafraîchir Liste", listGroupBox);
    listVBoxLayout->addWidget(coachTableWidget);
    listVBoxLayout->addWidget(refreshButton);
    leftLayout->addWidget(listGroupBox);

    // --- Section Droite : Formulaire Détails Coach ---
    detailsGroupBox = new QGroupBox("Détails du Coach", this);
    detailsFormLayout = new QFormLayout(detailsGroupBox);
    idLabelInfo = new QLabel("ID:", detailsGroupBox); idLabelValue = new QLabel("N/A", detailsGroupBox);
    nameLabel = new QLabel("Nom:", detailsGroupBox); nameLineEdit = new QLineEdit(detailsGroupBox);
    firstNameLabel = new QLabel("Prénom:", detailsGroupBox); firstNameLineEdit = new QLineEdit(detailsGroupBox);
    birthDateLabel = new QLabel("Date Naissance:", detailsGroupBox); birthDateEdit = new QDateEdit(detailsGroupBox);
    birthDateEdit->setCalendarPopup(true); birthDateEdit->setDisplayFormat("dd/MM/yyyy");
    birthDateEdit->setMinimumDate(QDate(1920, 1, 1)); birthDateEdit->setMaximumDate(QDate::currentDate());
    birthDateEdit->setSpecialValueText(" "); // Show blank when date is minimum
    birthDateEdit->setDate(birthDateEdit->minimumDate()); // Set initial date to minimum
    licenceLabel = new QLabel("Licence:", detailsGroupBox); licenceLineEdit = new QLineEdit(detailsGroupBox);
    detailsFormLayout->addRow(idLabelInfo, idLabelValue); detailsFormLayout->addRow(nameLabel, nameLineEdit);
    detailsFormLayout->addRow(firstNameLabel, firstNameLineEdit); detailsFormLayout->addRow(birthDateLabel, birthDateEdit);
    detailsFormLayout->addRow(licenceLabel, licenceLineEdit);
    rightLayout->addWidget(detailsGroupBox);

    // --- Section Droite : Boutons Actions Coach ---
    actionButtonsLayout = new QHBoxLayout();
    newButton = new QPushButton("Nouveau", this); saveButton = new QPushButton("Enregistrer", this); deleteButton = new QPushButton("Supprimer", this);
    actionButtonsLayout->addStretch(); actionButtonsLayout->addWidget(newButton); actionButtonsLayout->addWidget(saveButton); actionButtonsLayout->addWidget(deleteButton);
    rightLayout->addLayout(actionButtonsLayout);

    // --- Section Droite : Historique Modifiable ---
    historyGroupBox = new QGroupBox("Historique des Affectations", this);
    historyVBoxLayout = new QVBoxLayout(historyGroupBox);
    historyTableWidget = new QTableWidget(historyGroupBox);
    historyTableWidget->setColumnCount(4); // ID Hist, Équipe, Début, Fin
    historyTableWidget->setHorizontalHeaderLabels({"ID Hist", "Équipe", "Date Début", "Date Fin"});
    historyTableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    historyTableWidget->setSelectionMode(QAbstractItemView::SingleSelection);
    historyTableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    historyTableWidget->setColumnHidden(0, true); // Hide history entry ID
    historyTableWidget->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch); // Team name stretch
    historyTableWidget->setColumnWidth(2, 90); // Start Date width
    historyTableWidget->setColumnWidth(3, 90); // End Date width
    historyTableWidget->setAlternatingRowColors(true);
    historyTableWidget->verticalHeader()->setVisible(false);
    historyTableWidget->setMinimumHeight(120);
    historyTableWidget->setSortingEnabled(true); // Enable sorting for history

    historyButtonsLayout = new QHBoxLayout();
    addHistoryButton = new QPushButton("Ajouter Affectation", this);
    editHistoryButton = new QPushButton("Modifier Affectation", this);
    deleteHistoryButton = new QPushButton("Supprimer Affectation", this);
    editHistoryButton->setEnabled(false); // Disabled initially
    deleteHistoryButton->setEnabled(false); // Disabled initially
    historyButtonsLayout->addWidget(addHistoryButton);
    historyButtonsLayout->addStretch();
    historyButtonsLayout->addWidget(editHistoryButton);
    historyButtonsLayout->addWidget(deleteHistoryButton);

    historyVBoxLayout->addWidget(historyTableWidget);
    historyVBoxLayout->addLayout(historyButtonsLayout);
    rightLayout->addWidget(historyGroupBox);

    // Assemblage Final
    rightLayout->addStretch();
    mainLayout->addLayout(leftLayout, 1); // Left panel takes 1 part
    mainLayout->addLayout(rightLayout, 2); // Right panel takes 2 parts

    historyGroupBox->setVisible(false); // Hidden initially until a coach is selected
}

// Connecte les signaux
void CoachManagementWidget::connectSignalsSlots() {
    // Connect signals from widgets to the appropriate slots in this class
    if (coachTableWidget) connect(coachTableWidget, &QTableWidget::itemSelectionChanged, this, &CoachManagementWidget::coachSelectionChanged);
    if (refreshButton) connect(refreshButton, &QPushButton::clicked, this, &CoachManagementWidget::refreshCoachList);
    if (newButton) connect(newButton, &QPushButton::clicked, this, &CoachManagementWidget::prepareNewCoach);
    if (saveButton) connect(saveButton, &QPushButton::clicked, this, &CoachManagementWidget::saveCoachData);
    if (deleteButton) connect(deleteButton, &QPushButton::clicked, this, &CoachManagementWidget::deleteSelectedCoach);

    // Connections for the history section
    if (historyTableWidget) connect(historyTableWidget, &QTableWidget::itemSelectionChanged, this, &CoachManagementWidget::onHistoryTableSelectionChanged);
    if (addHistoryButton) connect(addHistoryButton, &QPushButton::clicked, this, &CoachManagementWidget::onAddHistoryClicked);
    if (editHistoryButton) connect(editHistoryButton, &QPushButton::clicked, this, &CoachManagementWidget::onEditHistoryClicked);
    if (deleteHistoryButton) connect(deleteHistoryButton, &QPushButton::clicked, this, &CoachManagementWidget::onDeleteHistoryClicked);
}

// --- Implémentation des Slots ---

// Slot to refresh the coach list and related data
void CoachManagementWidget::refreshCoachList() {
    if (m_connection && m_connection->database().isOpen()) {
        loadTeamsCache(); // Reload teams cache
        loadCoachesList(); // Reload coach list
    } else {
        // Try to reconnect if possible
        if(m_connection && m_connection->createconnect()){
            loadTeamsCache();
            loadCoachesList();
        } else {
            QMessageBox::warning(this, "Connexion Base de Données", "La connexion n'est pas disponible pour rafraîchir.");
        }
    }
    clearForm(); // Reset the form
}

// Slot called when the selection in the coach table changes
void CoachManagementWidget::coachSelectionChanged() {
    if (!coachTableWidget) return;
    QList<QTableWidgetItem*> selectedItems = coachTableWidget->selectedItems();

    if (selectedItems.isEmpty()) {
        clearForm(); // Clear form if selection is cleared
        return;
    }
    // Ensure DB connection is available
    if (!m_connection || !m_connection->database().isOpen()) {
        QMessageBox::warning(this, "Connexion Base de Données", "La connexion n'est pas disponible pour charger les détails.");
        clearForm(); return;
    }
    // Get the ID from the first column of the selected row
    int selectedRow = coachTableWidget->row(selectedItems.first());
    if (selectedRow < 0) {clearForm(); return;} // Invalid row
    QTableWidgetItem* idItem = coachTableWidget->item(selectedRow, 0);
    if (!idItem) {clearForm(); return;} // ID item not found

    bool ok;
    int coachId = idItem->text().toInt(&ok);
    if (ok && coachId >= 0) {
        populateCoachDetails(coachId); // Load details for the selected coach
    } else {
        qWarning() << "ID coach invalide ou non sélectionné dans la table:" << (idItem ? idItem->text() : "NULL");
        clearForm();
    }
}

// Slot to prepare the form for creating a new coach
void CoachManagementWidget::prepareNewCoach() {
    clearForm(); // Simply clear the form
}

// Slot to save coach data (handles both INSERT and UPDATE)
void CoachManagementWidget::saveCoachData() {
    if (!m_connection || !m_connection->database().isOpen()) {
        QMessageBox::critical(this, "Erreur", "Connexion à la base de données non disponible."); return;
    }

    // Retrieve data from the form widgets
    QString nom = nameLineEdit->text().trimmed();
    QString prenom = firstNameLineEdit->text().trimmed();
    QDate dateNaissance = birthDateEdit->date();
    QString licence = licenceLineEdit->text().trimmed();

    // Basic validation
    if (nom.isEmpty()) {
        QMessageBox::warning(this, "Champ Requis", "Le nom du coach est obligatoire."); nameLineEdit->setFocus(); return;
    }
    if (prenom.isEmpty()) {
        QMessageBox::warning(this, "Champ Requis", "Le prénom du coach est obligatoire."); firstNameLineEdit->setFocus(); return;
    }

    QSqlDatabase db = m_connection->database();
    bool success = false; QString finalMessage; int savedCoachId = -1;

    // Using try-catch for potential SQL errors or exceptions
    QApplication::setOverrideCursor(Qt::WaitCursor);
    try {
        QSqlQuery query(db);
        if (m_currentCoachId < 0) { // --- CREATE (INSERT) ---
            // Get new ID from sequence (Oracle specific!)
            query.prepare("SELECT coach_seq.NEXTVAL FROM DUAL"); // !!! Adapt if DB != Oracle !!!
            if (!query.exec() || !query.next()) throw std::runtime_error("Erreur obtention ID coach: " + query.lastError().text().toStdString());
            int newId = query.value(0).toInt();
            savedCoachId = newId;

            // Prepare INSERT statement
            query.prepare("INSERT INTO coachs (id_coach, nom, prenom, date_naissance, licence) "
                          "VALUES (:id, :nom, :prenom, :daten, :licence)");
            query.bindValue(":id", newId);
            query.bindValue(":nom", nom);
            query.bindValue(":prenom", prenom);
            // Check if date is the minimum date AND special text is shown
            bool isBirthDateSet = !(birthDateEdit->date() == birthDateEdit->minimumDate() && birthDateEdit->specialValueText() == " ");
            // *** Reverted NULL Binding ***
            query.bindValue(":daten", isBirthDateSet ? QVariant(dateNaissance) : QVariant());
            // *** Reverted NULL Binding ***
            query.bindValue(":licence", licence.isEmpty() ? QVariant() : licence);

            // Execute INSERT
            if (!query.exec()) throw std::runtime_error("Erreur insertion coach: " + query.lastError().text().toStdString());
            finalMessage = QString("Coach '%1 %2' créé (ID: %3).").arg(prenom).arg(nom).arg(newId);

        } else { // --- UPDATE ---
            savedCoachId = m_currentCoachId; // Keep track of the ID being updated
            // Prepare UPDATE statement
            query.prepare("UPDATE coachs SET nom = :nom, prenom = :prenom, date_naissance = :daten, licence = :licence "
                          "WHERE id_coach = :id");
            query.bindValue(":nom", nom);
            query.bindValue(":prenom", prenom);
            bool isBirthDateSet = !(birthDateEdit->date() == birthDateEdit->minimumDate() && birthDateEdit->specialValueText() == " ");
            // *** Reverted NULL Binding ***
            query.bindValue(":daten", isBirthDateSet ? QVariant(dateNaissance) : QVariant());
                // *** Reverted NULL Binding ***
            query.bindValue(":licence", licence.isEmpty() ? QVariant() : licence);
            query.bindValue(":id", m_currentCoachId);

            // Execute UPDATE
            if (!query.exec()) throw std::runtime_error("Erreur mise à jour coach: " + query.lastError().text().toStdString());
            finalMessage = QString("Coach '%1 %2' mis à jour.").arg(prenom).arg(nom);
        }
        // No explicit commit needed if autocommit is on and no manual transaction started
        success = true;
        QMessageBox::information(this, "Succès", finalMessage);

    } catch (const std::runtime_error &e) {
        qWarning() << "Erreur saveCoachData: " << e.what();
        QMessageBox::critical(this, "Erreur Sauvegarde", QString("Échec: %1").arg(e.what()));
        success = false;
        savedCoachId = -1; // Reset ID on error
    } catch (const QSqlError &e) { // Catch specific QSqlError as well
        qWarning() << "Erreur SQL saveCoachData: " << e.text();
        QMessageBox::critical(this, "Erreur SQL Sauvegarde", QString("Échec SQL: %1\nCode Natif: %2").arg(e.text()).arg(e.nativeErrorCode())); // Show native code too
        success = false;
        savedCoachId = -1;
    }
    QApplication::restoreOverrideCursor(); // Restore cursor

    // If save was successful, refresh list and optionally select the saved/created item
    if (success) {
        loadCoachesList(); // Refresh the coach list table
        clearForm(); // Clear the form
        // Try to select the row that was just saved/created
        if (savedCoachId >= 0 && coachTableWidget) {
            for (int i = 0; i < coachTableWidget->rowCount(); ++i) {
                QTableWidgetItem *item = coachTableWidget->item(i, 0); // Check ID in column 0
                if (item && item->text().toInt() == savedCoachId) {
                    coachTableWidget->selectRow(i); // Select the matching row
                    break; // Stop searching
                }
            }
        }
    }
}

// Slot to delete the currently selected coach and related data
void CoachManagementWidget::deleteSelectedCoach() {
    // Check if a coach is selected
    if (m_currentCoachId < 0) {
        QMessageBox::warning(this, "Action Impossible", "Sélectionner un coach à supprimer.");
        return;
    }
    // Check DB connection
    if (!m_connection || !m_connection->database().isOpen()) {
        QMessageBox::critical(this, "Erreur", "Connexion DB non disponible.");
        return;
    }

    // Get coach name for confirmation message
    QString coachName = (firstNameLineEdit ? firstNameLineEdit->text() : "") + " " + (nameLineEdit ? nameLineEdit->text() : "");
    coachName = coachName.trimmed().isEmpty() ? "[Coach ID: "+QString::number(m_currentCoachId)+"]" : coachName;

    // Confirm deletion with the user
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Confirmation Suppression",
                                  QString("Êtes-vous sûr de vouloir supprimer le coach '%1'?\n"
                                          "Cela supprimera aussi son historique d'affectations et le retirera des équipes où il est coach actuel.").arg(coachName),
                                  QMessageBox::Yes | QMessageBox::No, QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        QSqlDatabase db = m_connection->database();
        // Start transaction for multi-step deletion
        if (!db.transaction()) {
            qWarning() << "Échec démarrage transaction delete coach: " + db.lastError().text();
            QMessageBox::critical(this, "Erreur Transaction", "Impossible de démarrer la transaction."); return;
        }
        bool success = false;
        QApplication::setOverrideCursor(Qt::WaitCursor);
        try {
            QSqlQuery query(db);

            // 1. Delete assignment history
            query.prepare("DELETE FROM HISTORIQUE_COACHS WHERE id_coach = :id_c");
            query.bindValue(":id_c", m_currentCoachId);
            if (!query.exec()) throw std::runtime_error("Erreur suppression historique coach: " + query.lastError().text().toStdString());
            qInfo() << query.numRowsAffected() << "entrées d'historique supprimées pour coach" << m_currentCoachId;

            // 2. Remove coach as current coach from teams
            query.prepare("UPDATE equipes SET id_entraineur_actuel = NULL WHERE id_entraineur_actuel = :id_c");
            query.bindValue(":id_c", m_currentCoachId);
            if (!query.exec()) throw std::runtime_error("Erreur MAJ équipes (retrait coach actuel): " + query.lastError().text().toStdString());
            qInfo() << query.numRowsAffected() << "équipes mises à jour (retrait coach actuel)";

            // 3. Delete the coach record itself
            query.prepare("DELETE FROM coachs WHERE id_coach = :id_c");
            query.bindValue(":id_c", m_currentCoachId);
            if (!query.exec()) throw std::runtime_error("Erreur suppression coach: " + query.lastError().text().toStdString());
            int rowsAffected = query.numRowsAffected();

            // 4. Commit the transaction
            if (!db.commit()) throw std::runtime_error("Erreur commit suppression coach: " + db.lastError().text().toStdString());

            // Report success/warning based on whether the coach was found
            if (rowsAffected > 0) {
                QMessageBox::information(this, "Succès", QString("Coach '%1' supprimé avec succès.").arg(coachName));
                success = true;
            } else {
                QMessageBox::warning(this, "Avertissement", QString("Coach '%1' non trouvé (ou déjà supprimé).").arg(coachName));
                success = true; // Still success in terms of desired state
            }

        } catch (const std::runtime_error &e) {
            qWarning() << "Erreur deleteSelectedCoach, rollback..." << e.what();
            db.rollback(); // Rollback on error
            QMessageBox::critical(this, "Erreur Suppression", QString("Échec de la suppression: %1").arg(e.what()));
            success = false;
        } catch (const QSqlError &e) {
            qWarning() << "Erreur SQL deleteSelectedCoach, rollback..." << e.text();
            db.rollback(); // Rollback on error
            QMessageBox::critical(this, "Erreur SQL Suppression", QString("Échec SQL: %1\nCode Natif: %2").arg(e.text()).arg(e.nativeErrorCode())); // Show native code
            success = false;
        }
        QApplication::restoreOverrideCursor(); // Restore cursor

        // If deletion (or confirmation of non-existence) was successful, refresh UI
        if (success) {
            loadCoachesList(); // Refresh the main coach list
            loadTeamsCache();  // Refresh teams cache as current coach might have changed
            clearForm();       // Clear the form
        }
    }
}

// Slot to enable/disable history edit/delete buttons based on selection
void CoachManagementWidget::onHistoryTableSelectionChanged() {
    bool hasSelection = historyTableWidget && !historyTableWidget->selectedItems().isEmpty();
    if(editHistoryButton) editHistoryButton->setEnabled(hasSelection);
    if(deleteHistoryButton) deleteHistoryButton->setEnabled(hasSelection);
}

// --- Slots for History Buttons ---

// Slot to add a new history entry
void CoachManagementWidget::onAddHistoryClicked() {
    if (m_currentCoachId < 0) return; // No coach selected

    // Create and show the history dialog, passing the available teams
    CoachHistoryDialog dialog(m_teamsMap, this);
    if (dialog.exec() == QDialog::Accepted) {
        // Get data from the dialog
        int equipeId = dialog.getSelectedEquipeId();
        QDate dateDebut = dialog.getDateDebut();
        QDate dateFin = dialog.getDateFin(); // Will be invalid if "Current" was checked

        // Validate dialog data
        if (equipeId < 0) {
            QMessageBox::warning(&dialog, "Données Manquantes", "Veuillez sélectionner une équipe.");
            return;
        }
        if (!dateDebut.isValid()) {
            QMessageBox::warning(&dialog, "Données Manquantes", "La date de début est invalide.");
            return;
        }
        // Add more validation? e.g., end date after start date? Overlaps? (Not implemented here)

        // Insert into DB using a transaction
        if (!m_connection || !m_connection->database().isOpen()) {
            QMessageBox::critical(this, "Erreur DB", "Connexion perdue."); return;
        }
        QSqlDatabase db = m_connection->database();
        if (!db.transaction()) {
            QMessageBox::critical(this, "Erreur DB", "Impossible de démarrer la transaction."); return;
        }

        bool success = false;
        QApplication::setOverrideCursor(Qt::WaitCursor);
        QSqlQuery queryGetId(db); // Separate query object for sequence
        QSqlQuery queryInsertHist(db); // Separate query object for insert
        QSqlQuery queryUpdateEquipe(db); // Separate query object for updates

        try {
            // 1. Get new history ID (Oracle specific!)
            queryGetId.prepare("SELECT historique_coachs_seq.NEXTVAL FROM DUAL"); // !!! Adapt if DB != Oracle !!!
            if (!queryGetId.exec() || !queryGetId.next()) {
                throw std::runtime_error("Impossible d'obtenir un ID pour l'historique: " + queryGetId.lastError().text().toStdString());
            }
            int newHistId = queryGetId.value(0).toInt();
            queryGetId.finish(); // Explicitly finish query after use (optional but good practice)


            // 2. Insert the history record using queryInsertHist
            queryInsertHist.prepare("INSERT INTO HISTORIQUE_COACHS (id_historique, id_coach, id_equipe, date_debut, date_fin) "
                                    "VALUES (:id_h, :id_c, :id_e, :debut, :fin)");
            queryInsertHist.bindValue(":id_h", newHistId);
            queryInsertHist.bindValue(":id_c", m_currentCoachId);
            queryInsertHist.bindValue(":id_e", equipeId);
            queryInsertHist.bindValue(":debut", dateDebut);
            // *** Reverted NULL Binding ***
            queryInsertHist.bindValue(":fin", dateFin.isValid() ? QVariant(dateFin) : QVariant());

            // *** Execute the INSERT ***
            if (!queryInsertHist.exec()) {
                // Throw specific error for insertion failure, including DB error text
                throw std::runtime_error("Erreur insertion historique: " + queryInsertHist.lastError().text().toStdString());
            }
            queryInsertHist.finish(); // Finish insert query

            // 3. If this is the new "Current" assignment, update related tables using queryUpdateEquipe
            if (!dateFin.isValid()) {
                // 3a. Set end date on previous "Current" assignments for this coach
                queryUpdateEquipe.prepare("UPDATE HISTORIQUE_COACHS SET date_fin = :hier WHERE id_coach = :id_c AND date_fin IS NULL AND id_historique != :id_h");
                queryUpdateEquipe.bindValue(":hier", dateDebut.addDays(-1));
                queryUpdateEquipe.bindValue(":id_c", m_currentCoachId);
                queryUpdateEquipe.bindValue(":id_h", newHistId);
                if(!queryUpdateEquipe.exec()) throw std::runtime_error("Erreur clôture anciens historiques: " + queryUpdateEquipe.lastError().text().toStdString());
                queryUpdateEquipe.finish();

                // 3b. Set this coach as the current coach for the new team
                queryUpdateEquipe.prepare("UPDATE equipes SET id_entraineur_actuel = :id_c WHERE id_equipe = :id_e");
                queryUpdateEquipe.bindValue(":id_c", m_currentCoachId);
                queryUpdateEquipe.bindValue(":id_e", equipeId);
                if(!queryUpdateEquipe.exec()) throw std::runtime_error("Erreur MAJ équipe actuelle: " + queryUpdateEquipe.lastError().text().toStdString());
                queryUpdateEquipe.finish();

                // 3c. Remove this coach as current coach from any OTHER teams
                queryUpdateEquipe.prepare("UPDATE equipes SET id_entraineur_actuel = NULL WHERE id_equipe != :id_e AND id_entraineur_actuel = :id_c");
                queryUpdateEquipe.bindValue(":id_e", equipeId);
                queryUpdateEquipe.bindValue(":id_c", m_currentCoachId);
                if(!queryUpdateEquipe.exec()) throw std::runtime_error("Erreur MAJ anciennes équipes du coach: " + queryUpdateEquipe.lastError().text().toStdString());
                queryUpdateEquipe.finish();
            }

            // 4. Commit transaction
            if (!db.commit()) throw std::runtime_error("Erreur commit: " + db.lastError().text().toStdString());
            success = true;

        } catch(const std::runtime_error &e) {
            qWarning() << "Erreur ajout historique:" << e.what();
            db.rollback(); // Rollback on error
            // *** Display detailed error from the exception ***
            QMessageBox::critical(this, "Erreur Ajout", QString("Impossible d'ajouter l'entrée d'historique:\n%1").arg(e.what()));
        } catch (const QSqlError &e) { // Catch specific QSqlError too
            qWarning() << "Erreur SQL ajout historique:" << e.text();
            db.rollback(); // Rollback on error
            // *** Display detailed QSqlError information ***
            QMessageBox::critical(this, "Erreur SQL Ajout",
                                  QString("Impossible d'ajouter l'entrée d'historique (SQL Error):\n"
                                          "Driver: %1\nDatabase: %2\nNative Code: %3")
                                      .arg(e.driverText()).arg(e.databaseText()).arg(e.nativeErrorCode()));
        }

        QApplication::restoreOverrideCursor();

        // Refresh UI if successful
        if (success) {
            loadCoachHistoryTable(m_currentCoachId); // Refresh history table
            loadTeamsCache(); // Refresh teams cache as current coach might have changed
        }
    }
}

// Slot to edit an existing history entry
void CoachManagementWidget::onEditHistoryClicked() {
    // Check selection
    if (!historyTableWidget || historyTableWidget->selectedItems().isEmpty()) return;
    int currentRow = historyTableWidget->currentRow();
    bool ok;
    // Get history ID from hidden column 0
    int historyId = historyTableWidget->item(currentRow, 0)->data(Qt::DisplayRole).toInt(&ok);
    if (!ok || historyId < 0) {
        qWarning() << "ID historique invalide ou non trouvé dans la table."; return;
    }

    // Get current data for this history entry from DB to pre-fill dialog
    if (!m_connection || !m_connection->database().isOpen()) { QMessageBox::critical(this, "Erreur DB", "Connexion perdue."); return; }
    QSqlDatabase db = m_connection->database();
    QSqlQuery query(db);
    query.prepare("SELECT id_equipe, date_debut, date_fin FROM HISTORIQUE_COACHS WHERE id_historique = :id_h");
    query.bindValue(":id_h", historyId);

    if (!query.exec() || !query.next()) {
        QMessageBox::critical(this, "Erreur Modification", "Impossible de récupérer les données de l'historique à modifier."); return;
    }
    int currentEquipeId = query.value(0).toInt();
    QDate currentDebut = query.value(1).toDate();
    QDate currentFin = query.value(2).toDate(); // Will be invalid if NULL in DB
    bool isCurrentlyActive = !currentFin.isValid();
    query.finish(); // Finish select query

    // Open the dialog, pre-filled with current data
    CoachHistoryDialog dialog(m_teamsMap, this);
    dialog.setHistoryData(currentEquipeId, currentDebut, currentFin, isCurrentlyActive);

    // If user clicks OK
    if (dialog.exec() == QDialog::Accepted) {
        // Get the new values from the dialog
        int newEquipeId = dialog.getSelectedEquipeId();
        QDate newDebut = dialog.getDateDebut();
        QDate newFin = dialog.getDateFin(); // Invalid if "Current" checked

        // Validate dialog data
        if (newEquipeId < 0 || !newDebut.isValid()) {
            QMessageBox::warning(&dialog, "Données Invalides", "L'équipe et la date de début sont obligatoires."); return;
        }
        // Add more validation?

        // Update DB within a transaction
        if (!db.transaction()) { QMessageBox::critical(this, "Erreur DB", "Impossible de démarrer la transaction."); return; }
        bool success = false;
        QApplication::setOverrideCursor(Qt::WaitCursor);
        try {
            QSqlQuery updateQuery(db); // Can reuse this one for multiple updates
            // 1. Update the history record itself
            updateQuery.prepare("UPDATE HISTORIQUE_COACHS SET id_equipe = :id_e, date_debut = :debut, date_fin = :fin "
                                "WHERE id_historique = :id_h");
            updateQuery.bindValue(":id_e", newEquipeId);
            updateQuery.bindValue(":debut", newDebut);
            // *** Reverted NULL Binding ***
            updateQuery.bindValue(":fin", newFin.isValid() ? QVariant(newFin) : QVariant());
            updateQuery.bindValue(":id_h", historyId);

            if (!updateQuery.exec()) throw std::runtime_error("Erreur MAJ historique: " + updateQuery.lastError().text().toStdString());
            updateQuery.finish();

            // 2. Handle changes related to the "Current" status
            // Case 1: The edited record is NOW the current one
            if (!newFin.isValid()) {
                // End other current assignments for this coach
                updateQuery.prepare("UPDATE HISTORIQUE_COACHS SET date_fin = :hier WHERE id_coach = :id_c AND date_fin IS NULL AND id_historique != :id_h");
                updateQuery.bindValue(":hier", newDebut.addDays(-1));
                updateQuery.bindValue(":id_c", m_currentCoachId);
                updateQuery.bindValue(":id_h", historyId);
                if(!updateQuery.exec()) throw std::runtime_error("Erreur clôture anciens historiques (edit): " + updateQuery.lastError().text().toStdString());
                updateQuery.finish();

                // Set this coach as current for the (potentially new) team
                updateQuery.prepare("UPDATE equipes SET id_entraineur_actuel = :id_c WHERE id_equipe = :id_e");
                updateQuery.bindValue(":id_c", m_currentCoachId);
                updateQuery.bindValue(":id_e", newEquipeId);
                if(!updateQuery.exec()) throw std::runtime_error("Erreur MAJ équipe actuelle (edit): " + updateQuery.lastError().text().toStdString());
                updateQuery.finish();

                // Remove this coach as current from any OTHER teams
                updateQuery.prepare("UPDATE equipes SET id_entraineur_actuel = NULL WHERE id_equipe != :id_e AND id_entraineur_actuel = :id_c");
                updateQuery.bindValue(":id_e", newEquipeId);
                updateQuery.bindValue(":id_c", m_currentCoachId);
                if(!updateQuery.exec()) throw std::runtime_error("Erreur MAJ anciennes équipes du coach (edit): " + updateQuery.lastError().text().toStdString());
                updateQuery.finish();

            }
            // Case 2: The edited record WAS current, but ISN'T anymore
            else if (isCurrentlyActive && newFin.isValid()) {
                // Check if any *other* current assignment exists for this coach
                updateQuery.prepare("SELECT COUNT(*) FROM HISTORIQUE_COACHS WHERE id_coach = :id_c AND date_fin IS NULL");
                updateQuery.bindValue(":id_c", m_currentCoachId);
                if (!updateQuery.exec() || !updateQuery.next()) {
                    updateQuery.finish(); // Finish even on error before throwing
                    throw std::runtime_error("Erreur vérification autres affectations (edit): " + updateQuery.lastError().text().toStdString());
                }
                bool otherCurrentExists = (updateQuery.value(0).toInt() > 0);
                updateQuery.finish();

                if (!otherCurrentExists) {
                    // If NO other current assignment exists, remove coach as current from the team he *was* coaching (currentEquipeId)
                    updateQuery.prepare("UPDATE equipes SET id_entraineur_actuel = NULL WHERE id_equipe = :id_e AND id_entraineur_actuel = :id_c");
                    updateQuery.bindValue(":id_e", currentEquipeId); // Team ID before edit
                    updateQuery.bindValue(":id_c", m_currentCoachId);
                    if(!updateQuery.exec()) throw std::runtime_error("Erreur MAJ équipe quittée (edit): " + updateQuery.lastError().text().toStdString());
                    updateQuery.finish();
                }
                // If another current assignment *does* exist, we don't need to change the EQUIPES table here.
            }

            // 3. Commit transaction
            if (!db.commit()) throw std::runtime_error("Erreur commit MAJ historique: " + db.lastError().text().toStdString());
            success = true;

        } catch(const std::runtime_error &e) {
            qWarning() << "Erreur modif historique:" << e.what();
            db.rollback(); // Rollback on error
            QMessageBox::critical(this, "Erreur Modification", QString("Impossible de modifier l'entrée d'historique:\n%1").arg(e.what()));
        } catch (const QSqlError &e) { // Catch specific QSqlError
            qWarning() << "Erreur SQL modif historique:" << e.text();
            db.rollback(); // Rollback on error
            QMessageBox::critical(this, "Erreur SQL Modification",
                                  QString("Impossible de modifier l'entrée d'historique (SQL Error):\n"
                                          "Driver: %1\nDatabase: %2\nNative Code: %3")
                                      .arg(e.driverText()).arg(e.databaseText()).arg(e.nativeErrorCode()));
        }
        QApplication::restoreOverrideCursor();

        // Refresh UI if successful
        if (success) {
            loadCoachHistoryTable(m_currentCoachId);
            loadTeamsCache(); // Refresh teams cache
        }
    }
}

// Slot to delete an existing history entry
void CoachManagementWidget::onDeleteHistoryClicked() {
    // Check selection
    if (!historyTableWidget || historyTableWidget->selectedItems().isEmpty()) return;
    int currentRow = historyTableWidget->currentRow();
    bool ok;
    // Get history ID from hidden column 0
    int historyId = historyTableWidget->item(currentRow, 0)->data(Qt::DisplayRole).toInt(&ok);
    if (!ok || historyId < 0) { qWarning() << "ID historique invalide."; return; }

    // Get info about the entry *before* deleting it (team ID and if it was current)
    if (!m_connection || !m_connection->database().isOpen()) { QMessageBox::critical(this, "Erreur DB", "Connexion perdue."); return; }
    QSqlDatabase db = m_connection->database();
    QSqlQuery queryCheck(db);
    queryCheck.prepare("SELECT id_equipe, date_fin FROM HISTORIQUE_COACHS WHERE id_historique = :id_h");
    queryCheck.bindValue(":id_h", historyId);
    int equipeIdToDelete = -1;
    bool wasCurrent = false;
    if(queryCheck.exec() && queryCheck.next()) {
        equipeIdToDelete = queryCheck.value(0).toInt();
        wasCurrent = queryCheck.value(1).isNull(); // Was current if date_fin is NULL
    } else {
        queryCheck.finish(); // Finish query
        QMessageBox::critical(this, "Erreur", "Impossible de vérifier l'état de l'historique avant suppression.");
        return;
    }
    queryCheck.finish(); // Finish query

    // Confirm deletion with user
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Confirmation Suppression",
                                  "Êtes-vous sûr de vouloir supprimer cette entrée de l'historique ?",
                                  QMessageBox::Yes | QMessageBox::No, QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        // Delete within a transaction
        if (!db.transaction()) { QMessageBox::critical(this, "Erreur DB", "Impossible de démarrer la transaction."); return; }
        bool success = false;
        QApplication::setOverrideCursor(Qt::WaitCursor);
        try {
            QSqlQuery queryDelete(db);
            QSqlQuery queryCheckAgain(db); // Use a new query object inside loop if needed
            QSqlQuery queryUpdateEquipe(db);

            // 1. Delete the history record
            queryDelete.prepare("DELETE FROM HISTORIQUE_COACHS WHERE id_historique = :id_h");
            queryDelete.bindValue(":id_h", historyId);
            if (!queryDelete.exec()) throw std::runtime_error("Erreur suppression historique: " + queryDelete.lastError().text().toStdString());
            queryDelete.finish();

            // 2. If the deleted record WAS the current one, update the corresponding team
            if(wasCurrent && equipeIdToDelete >= 0) {
                // Check if any *other* current assignment still exists for this coach
                queryCheckAgain.prepare("SELECT COUNT(*) FROM HISTORIQUE_COACHS WHERE id_coach = :id_c AND date_fin IS NULL");
                queryCheckAgain.bindValue(":id_c", m_currentCoachId);
                if (!queryCheckAgain.exec() || !queryCheckAgain.next()) {
                    queryCheckAgain.finish();
                    throw std::runtime_error("Erreur vérification autres affectations (delete): " + queryCheckAgain.lastError().text().toStdString());
                }
                bool otherCurrentExists = (queryCheckAgain.value(0).toInt() > 0);
                queryCheckAgain.finish();

                if (!otherCurrentExists) {
                    // If NO other current assignment exists, remove coach as current from the team he was coaching
                    queryUpdateEquipe.prepare("UPDATE equipes SET id_entraineur_actuel = NULL WHERE id_equipe = :id_e AND id_entraineur_actuel = :id_c");
                    queryUpdateEquipe.bindValue(":id_e", equipeIdToDelete);
                    queryUpdateEquipe.bindValue(":id_c", m_currentCoachId);
                    if(!queryUpdateEquipe.exec()) throw std::runtime_error("Erreur MAJ équipe après suppression historique: " + queryUpdateEquipe.lastError().text().toStdString());
                    queryUpdateEquipe.finish();
                }
                // If another current assignment *does* exist, we don't need to change the EQUIPES table here.
            }

            // 3. Commit transaction
            if (!db.commit()) throw std::runtime_error("Erreur commit suppression historique: " + db.lastError().text().toStdString());
            success = true;
        } catch(const std::runtime_error &e) {
            qWarning() << "Erreur suppression historique:" << e.what();
            db.rollback(); // Rollback on error
            QMessageBox::critical(this, "Erreur Suppression", QString("Impossible de supprimer l'entrée d'historique:\n%1").arg(e.what()));
        } catch (const QSqlError &e) { // Catch specific QSqlError
            qWarning() << "Erreur SQL suppression historique:" << e.text();
            db.rollback(); // Rollback on error
            QMessageBox::critical(this, "Erreur SQL Suppression",
                                  QString("Impossible de supprimer l'entrée d'historique (SQL Error):\n"
                                          "Driver: %1\nDatabase: %2\nNative Code: %3")
                                      .arg(e.driverText()).arg(e.databaseText()).arg(e.nativeErrorCode()));
        }
        QApplication::restoreOverrideCursor();

        // Refresh UI if successful
        if (success) {
            loadCoachHistoryTable(m_currentCoachId);
            loadTeamsCache(); // Refresh teams cache
        }
    }
}


// --- Méthodes privées ---

// Loads details for a specific coach into the form
void CoachManagementWidget::populateCoachDetails(int coachId) {
    if (!m_connection || !m_connection->database().isOpen()) {
        qWarning() << "populateCoachDetails: Connexion DB non disponible.";
        clearForm(); return;
    }
    QApplication::setOverrideCursor(Qt::WaitCursor);
    QSqlDatabase db = m_connection->database(); QSqlQuery query(db);
    query.prepare("SELECT nom, prenom, date_naissance, licence FROM coachs WHERE id_coach = :id");
    query.bindValue(":id", coachId);

    bool detailsLoaded = false;
    if (query.exec() && query.next()) {
        m_currentCoachId = coachId; // Store the ID of the currently viewed coach
        // Populate form fields
        if(idLabelValue) idLabelValue->setText(QString::number(coachId));
        if(nameLineEdit) nameLineEdit->setText(query.value(0).toString());
        if(firstNameLineEdit) firstNameLineEdit->setText(query.value(1).toString());
        if (birthDateEdit) {
            QVariant dateVal = query.value(2);
            // Handle NULL or invalid dates from DB
            if (dateVal.isNull() || !dateVal.isValid() || !dateVal.toDate().isValid()) {
                birthDateEdit->setDate(birthDateEdit->minimumDate());
                birthDateEdit->setSpecialValueText(" "); // Show blank
            } else {
                birthDateEdit->setDate(dateVal.toDate());
                birthDateEdit->setSpecialValueText(""); // Clear special text
            }
        }
        if(licenceLineEdit) licenceLineEdit->setText(query.value(3).toString());
        // Enable/disable buttons
        if(deleteButton) deleteButton->setEnabled(true);
        if(saveButton) saveButton->setText("Enregistrer Modifications");
        detailsLoaded = true;
    } else {
        // Handle case where coach is not found or query fails
        qWarning() << "Erreur chargement détails coach ID" << coachId << ":" << query.lastError().text();
        QMessageBox::warning(this, "Non trouvé", QString("Le coach ID %1 n'a pas pu être chargé ou n'existe pas.").arg(coachId));
        clearForm();
    }
    query.finish(); // Finish query

    // Load and show the history section if details were loaded successfully
    if(detailsLoaded) {
        loadCoachHistoryTable(coachId); // Load the history table for this coach
        if(historyGroupBox) historyGroupBox->setVisible(true); // Make history section visible
        onHistoryTableSelectionChanged(); // Update history button states
    }

    QApplication::restoreOverrideCursor();
}

// Clears the form and resets state for creating a new coach
void CoachManagementWidget::clearForm() {
    m_currentCoachId = -1; // Reset current ID
    // Clear form fields
    if(idLabelValue) idLabelValue->setText("Nouveau");
    if(nameLineEdit) nameLineEdit->clear();
    if(firstNameLineEdit) firstNameLineEdit->clear();
    if(birthDateEdit) {
        // Set a reasonable default date, clear special text
        birthDateEdit->setDate(QDate::currentDate().addYears(-30));
        birthDateEdit->setSpecialValueText("");
    }
    if(licenceLineEdit) licenceLineEdit->clear();
    // Reset UI states
    if(coachTableWidget) coachTableWidget->clearSelection();
    if(deleteButton) deleteButton->setEnabled(false);
    if(saveButton) saveButton->setText("Créer Coach");
    if(nameLineEdit) nameLineEdit->setFocus(); // Set focus to the first input field

    // Hide and clear the history section
    if(historyTableWidget) historyTableWidget->setRowCount(0);
    if(historyGroupBox) historyGroupBox->setVisible(false);
    if(editHistoryButton) editHistoryButton->setEnabled(false);
    if(deleteHistoryButton) deleteHistoryButton->setEnabled(false);
}

// Loads the list of teams into the cache (m_teamsMap) for the history dialog
void CoachManagementWidget::loadTeamsCache() {
    if (!m_connection || !m_connection->database().isOpen()) {
        qWarning() << "loadTeamsCache (Coach): Connexion DB non disponible.";
        m_teamsMap.clear(); return;
    }
    m_teamsMap.clear(); // Clear existing cache
    QSqlDatabase db = m_connection->database();
    QSqlQuery query(db);
    // Select team ID and name
    if(query.exec("SELECT id_equipe, nom FROM equipes ORDER BY nom")) {
        while(query.next()) {
            // Store ID -> Name mapping
            m_teamsMap.insert(query.value(0).toInt(), query.value(1).toString());
        }
    } else {
        qWarning() << "Erreur rechargement cache équipes (Coach):" << query.lastError().text();
    }
    query.finish(); // Finish query
    qInfo() << "Cache équipes (Coach) rechargé:" << m_teamsMap.count() << "équipes.";

}

// Loads the list of coaches from the DB into the main table widget
void CoachManagementWidget::loadCoachesList() {
    // Check if the table widget and connection are valid
    if (!coachTableWidget || !m_connection || !m_connection->database().isOpen()) {
        qWarning() << "loadCoachesList: Table widget or DB connection not available.";
        if(coachTableWidget) coachTableWidget->setRowCount(0); // Clear table if it exists
        return;
    }

    // Clear the table before populating and disable sorting
    coachTableWidget->setRowCount(0);
    coachTableWidget->setSortingEnabled(false);
    QApplication::setOverrideCursor(Qt::WaitCursor); // Show wait cursor

    QSqlDatabase db = m_connection->database();
    QSqlQuery query(db);
    // Prepare the SQL query to select coach details
    QString sql = "SELECT id_coach, nom, prenom, licence FROM coachs ORDER BY nom, prenom";

    // Execute the query
    if (query.exec(sql)) {
        int row = 0;
        // Iterate through the results
        while (query.next()) {
            coachTableWidget->insertRow(row);

            // Create non-editable items for each cell
            QTableWidgetItem *idItem = new QTableWidgetItem(query.value(0).toString());
            idItem->setFlags(idItem->flags() & ~Qt::ItemIsEditable);

            QTableWidgetItem *nomItem = new QTableWidgetItem(query.value(1).toString());
            nomItem->setFlags(nomItem->flags() & ~Qt::ItemIsEditable);

            QTableWidgetItem *prenomItem = new QTableWidgetItem(query.value(2).toString());
            prenomItem->setFlags(prenomItem->flags() & ~Qt::ItemIsEditable);

            QTableWidgetItem *licenceItem = new QTableWidgetItem(query.value(3).toString());
            licenceItem->setFlags(licenceItem->flags() & ~Qt::ItemIsEditable);

            // Add items to the current row
            coachTableWidget->setItem(row, 0, idItem);
            coachTableWidget->setItem(row, 1, nomItem);
            coachTableWidget->setItem(row, 2, prenomItem);
            coachTableWidget->setItem(row, 3, licenceItem);

            row++; // Move to the next row
        }
    } else {
        // Handle query execution error
        qWarning() << "Erreur chargement liste coachs:" << query.lastError().text();
        QMessageBox::critical(this, "Erreur Chargement",
                              "Impossible de charger la liste des coachs.\n" + query.lastError().text());
    }
    query.finish(); // Finish query

    // Restore cursor and re-enable sorting
    QApplication::restoreOverrideCursor();
    coachTableWidget->setSortingEnabled(true);
}


// Loads the assignment history for a specific coach into the history table widget
void CoachManagementWidget::loadCoachHistoryTable(int coachId) {
    // Check prerequisites
    if (!historyTableWidget || !m_connection || !m_connection->database().isOpen() || coachId < 0) {
        if(historyTableWidget) historyTableWidget->setRowCount(0); // Clear table if possible
        return;
    }

    // Clear table and disable sorting during population
    historyTableWidget->setRowCount(0);
    historyTableWidget->setSortingEnabled(false);
    QApplication::setOverrideCursor(Qt::WaitCursor);

    QSqlDatabase db = m_connection->database();
    QSqlQuery query(db);
    // Prepare query with JOIN to get team name
    query.prepare("SELECT h.id_historique, e.nom AS nom_equipe, h.date_debut, h.date_fin "
                  "FROM HISTORIQUE_COACHS h "
                  "LEFT JOIN EQUIPES e ON h.id_equipe = e.id_equipe "
                  "WHERE h.id_coach = :id_c "
                  "ORDER BY h.date_debut DESC"); // Order by most recent first
    query.bindValue(":id_c", coachId);

    if (query.exec()) {
        int row = 0;
        while (query.next()) {
            historyTableWidget->insertRow(row);

            // Column 0: History ID (Hidden) - Store as data
            QTableWidgetItem *histIdItem = new QTableWidgetItem();
            histIdItem->setData(Qt::DisplayRole, query.value(0).toInt());
            historyTableWidget->setItem(row, 0, histIdItem);

            // Column 1: Team Name
            QTableWidgetItem *teamItem = new QTableWidgetItem(query.value(1).toString());
            teamItem->setFlags(teamItem->flags() & ~Qt::ItemIsEditable);
            historyTableWidget->setItem(row, 1, teamItem);

            // Column 2: Start Date
            QTableWidgetItem *debutItem = new QTableWidgetItem(query.value(2).toDate().toString("dd/MM/yyyy"));
            debutItem->setTextAlignment(Qt::AlignCenter);
            debutItem->setFlags(debutItem->flags() & ~Qt::ItemIsEditable);
            historyTableWidget->setItem(row, 2, debutItem);

            // Column 3: End Date (or "Actuel" if NULL)
            QVariant finVal = query.value(3);
            QString finText = finVal.isNull() ? "Actuel" : finVal.toDate().toString("dd/MM/yyyy");
            QTableWidgetItem *finItem = new QTableWidgetItem(finText);
            finItem->setTextAlignment(Qt::AlignCenter);
            if (finVal.isNull()) { // Optionally make "Actuel" bold
                QFont font = finItem->font(); font.setBold(true); finItem->setFont(font);
            }
            finItem->setFlags(finItem->flags() & ~Qt::ItemIsEditable);
            historyTableWidget->setItem(row, 3, finItem);

            row++;
        }
        // Optional: Handle case where no history exists
        // if (row == 0) { ... }
    } else {
        // Handle query error
        qWarning() << "Erreur chargement historique coach ID" << coachId << ":" << query.lastError().text();
        QMessageBox::warning(this, "Erreur Historique", "Impossible de charger l'historique des affectations.\n" + query.lastError().text());
    }
    query.finish(); // Finish query

    // Final UI adjustments
    historyTableWidget->resizeRowsToContents(); // Adjust row heights
    historyTableWidget->setSortingEnabled(true); // Re-enable sorting
    onHistoryTableSelectionChanged(); // Update button states based on selection (or lack thereof)
    QApplication::restoreOverrideCursor();
}
