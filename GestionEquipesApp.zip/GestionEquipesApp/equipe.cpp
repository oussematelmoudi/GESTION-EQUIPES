// equipe.cpp
#include "equipe.h" // Include direct

Equipe::Equipe() :
    m_id(-1), // -1 indique un objet non initialisé depuis la DB ou nouveau
    m_classement(0),
    m_idEntraineurActuel(-1) // -1 indique pas d'entraîneur
{}

Equipe::Equipe(int id, const QString &nom, int classement, int idCoach) :
    m_id(id),
    m_nom(nom),
    m_classement(classement),
    m_idEntraineurActuel(idCoach)
{}

// --- Getters ---
int Equipe::getId() const { return m_id; }
QString Equipe::getNom() const { return m_nom; }
int Equipe::getClassement() const { return m_classement; }
int Equipe::getIdEntraineurActuel() const { return m_idEntraineurActuel; }
QList<int> Equipe::getEffectifIds() const { return m_effectifIds; }
QList<int> Equipe::getHistoriqueEntraineursIds() const { return m_historiqueEntraineursIds; }
QList<int> Equipe::getHistoriqueMatchsIds() const { return m_historiqueMatchsIds; }
int Equipe::getNombreJoueurs() const { return m_effectifIds.count(); }

// --- Setters ---
void Equipe::setId(int id) { m_id = id; }
void Equipe::setNom(const QString &nom) { m_nom = nom; }
void Equipe::setClassement(int classement) { m_classement = classement; }
void Equipe::setIdEntraineurActuel(int idCoach) { m_idEntraineurActuel = idCoach; }
void Equipe::setEffectifIds(const QList<int> &ids) { m_effectifIds = ids; }
void Equipe::setHistoriqueEntraineursIds(const QList<int> &ids) { m_historiqueEntraineursIds = ids; }
void Equipe::setHistoriqueMatchsIds(const QList<int> &ids) { m_historiqueMatchsIds = ids; }

// --- Méthodes Utilitaires ---
void Equipe::ajouterJoueurId(int joueurId) {
    if (!m_effectifIds.contains(joueurId)) {
        m_effectifIds.append(joueurId);
    }
}

void Equipe::retirerJoueurId(int joueurId) {
    m_effectifIds.removeAll(joueurId);
}

void Equipe::ajouterEntraineurHistoriqueId(int coachId) {
    if (!m_historiqueEntraineursIds.contains(coachId)) {
        m_historiqueEntraineursIds.append(coachId);
    }
}
void Equipe::ajouterMatchHistoriqueId(int matchId) {
    if (!m_historiqueMatchsIds.contains(matchId)) {
        m_historiqueMatchsIds.append(matchId);
    }
}
