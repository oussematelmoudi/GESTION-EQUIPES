// coachhistorydialog.cpp
#include "coachhistorydialog.h" // Include the header file

// Necessary Qt includes for this file's implementation
#include <QLabel>
#include <QComboBox>
#include <QDateEdit>
#include <QCheckBox>
#include <QPushButton>
#include <QFormLayout>
#include <QDialogButtonBox>
#include <QVBoxLayout>
#include <QDate>
#include <QDebug> // Include QDebug for qMax, or include <QtGlobal>

// --- DO NOT INCLUDE .CPP FILES HERE ---
// #include "coachmanagementwidget.cpp" // <<< REMOVE THIS LINE IF IT EXISTS

CoachHistoryDialog::CoachHistoryDialog(const QMap<int, QString> &availableTeams, QWidget *parent)
    : QDialog(parent), teamsMap(availableTeams)
{
    setupUi();
    setWindowTitle("Ajouter/Modifier Affectation Coach");
    setMinimumWidth(350);

    // Remplir le ComboBox des équipes
    equipeComboBox->addItem("Sélectionner une équipe...", -1); // Invite
    for(auto it = teamsMap.constBegin(); it != teamsMap.constEnd(); ++it) {
        equipeComboBox->addItem(it.value(), it.key()); // Texte = Nom, Data = ID
    }

    // Connect the modern signal checkStateChanged instead of the deprecated stateChanged
    connect(currentCheckBox, &QCheckBox::checkStateChanged, this, &CoachHistoryDialog::onCurrentCheckboxChanged);

    connect(buttonBox, &QDialogButtonBox::accepted, this, &QDialog::accept);
    connect(buttonBox, &QDialogButtonBox::rejected, this, &QDialog::reject);

    // Call the slot to set the initial state of the date edit
    onCurrentCheckboxChanged(currentCheckBox->checkState());
}

void CoachHistoryDialog::setupUi() {
    // Ensure all member widget pointers are initialized before use
    // (They should be declared in the header)
    mainLayout = new QVBoxLayout(this); // Assuming mainLayout is a member
    formLayout = new QFormLayout();

    equipeLabel = new QLabel("Équipe:", this);
    equipeComboBox = new QComboBox(this);

    debutLabel = new QLabel("Date de Début:", this);
    debutDateEdit = new QDateEdit(QDate::currentDate(), this);
    debutDateEdit->setCalendarPopup(true);
    debutDateEdit->setDisplayFormat("dd/MM/yyyy");

    finLabel = new QLabel("Date de Fin:", this);
    finDateEdit = new QDateEdit(QDate::currentDate(), this);
    finDateEdit->setCalendarPopup(true);
    finDateEdit->setDisplayFormat("dd/MM/yyyy");

    currentCheckBox = new QCheckBox("Affectation Actuelle", this);

    formLayout->addRow(equipeLabel, equipeComboBox);
    formLayout->addRow(debutLabel, debutDateEdit);
    formLayout->addRow(finLabel, finDateEdit);
    formLayout->addRow("", currentCheckBox); // Checkbox sans label de formulaire

    buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);

    mainLayout->addLayout(formLayout);
    mainLayout->addWidget(buttonBox);
    // setLayout(mainLayout); // Not strictly necessary if 'this' is passed to QVBoxLayout constructor
}

// Pré-remplit les champs pour la modification
void CoachHistoryDialog::setHistoryData(int equipeId, const QDate& dateDebut, const QDate& dateFin, bool isCurrent) {
    // Find the item in the combo box by its data (ID)
    int index = equipeComboBox->findData(equipeId);
    // Set the current index, ensuring it's valid (>= 0)
    equipeComboBox->setCurrentIndex(qMax(0, index));

    // Set the start date, defaulting to today if the provided date is invalid
    debutDateEdit->setDate(dateDebut.isValid() ? dateDebut : QDate::currentDate());

    // Handle the end date based on whether it's the current assignment
    if (isCurrent || !dateFin.isValid()) {
        currentCheckBox->setChecked(true);
        // Set a default date for the QDateEdit, but disable it
        finDateEdit->setDate(QDate::currentDate());
        finDateEdit->setEnabled(false);
    } else {
        currentCheckBox->setChecked(false);
        finDateEdit->setDate(dateFin);
        finDateEdit->setEnabled(true);
    }
}

// Getters pour récupérer les valeurs après acceptation
int CoachHistoryDialog::getSelectedEquipeId() const {
    // Return the data (ID) associated with the currently selected item
    return equipeComboBox->currentData().toInt();
}

QDate CoachHistoryDialog::getDateDebut() const {
    return debutDateEdit->date();
}

QDate CoachHistoryDialog::getDateFin() const {
    // Return an invalid QDate if "Current" is checked, otherwise return the selected date
    return currentCheckBox->isChecked() ? QDate() : finDateEdit->date();
}

bool CoachHistoryDialog::isCurrentAssignment() const {
    return currentCheckBox->isChecked();
}

// Slot pour activer/désactiver la date de fin
// The 'state' parameter corresponds to the Qt::CheckState enum (Unchecked, Checked)
void CoachHistoryDialog::onCurrentCheckboxChanged(int state) {
    // Enable the end date edit only if the checkbox is unchecked
    finDateEdit->setEnabled(state == Qt::Unchecked);
    // Optional: Clear the end date if "Current" is checked
    // if (state == Qt::Checked) {
    //     finDateEdit->clear(); // Or set to a default invalid date
    // }
}

