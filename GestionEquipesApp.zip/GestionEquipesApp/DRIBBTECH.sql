-- =============================================================================
-- Sequences for Primary Keys
-- =============================================================================
CREATE SEQUENCE coach_seq START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE equipe_seq START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE joueur_seq START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE historique_coachs_seq START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE match_seq START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE transfert_seq START WITH 1 INCREMENT BY 1 NOCACHE;

-- =============================================================================
-- COACHS Table
-- =============================================================================
CREATE TABLE COACHS (
    id_coach NUMBER PRIMARY KEY,
    nom VARCHAR2(100) NOT NULL,
    prenom VARCHAR2(100) NOT NULL,
    date_naissance DATE NULL,
    licence VARCHAR2(50) NULL
);

COMMENT ON TABLE COACHS IS 'Table storing coach information';
COMMENT ON COLUMN COACHS.id_coach IS 'Unique identifier for the coach (PK)';
COMMENT ON COLUMN COACHS.nom IS 'Last name of the coach';
COMMENT ON COLUMN COACHS.prenom IS 'First name of the coach';
COMMENT ON COLUMN COACHS.date_naissance IS 'Date of birth of the coach';
COMMENT ON COLUMN COACHS.licence IS 'License number of the coach';

-- =============================================================================
-- EQUIPES Table (Teams)
-- =============================================================================
CREATE TABLE EQUIPES (
    id_equipe NUMBER PRIMARY KEY,
    nom VARCHAR2(100) NOT NULL UNIQUE, -- Assuming team names should be unique
    classement NUMBER DEFAULT 0,
    id_entraineur_actuel NUMBER NULL,  -- Foreign key to COACHS, nullable
    -- Foreign Key Constraint (can be added later with ALTER TABLE if preferred)
    CONSTRAINT fk_equipe_coach FOREIGN KEY (id_entraineur_actuel)
        REFERENCES COACHS(id_coach) ON DELETE SET NULL -- If coach is deleted, set team's coach to NULL
);

COMMENT ON TABLE EQUIPES IS 'Table storing team information';
COMMENT ON COLUMN EQUIPES.id_equipe IS 'Unique identifier for the team (PK)';
COMMENT ON COLUMN EQUIPES.nom IS 'Name of the team (should be unique)';
COMMENT ON COLUMN EQUIPES.classement IS 'Current ranking or points of the team';
COMMENT ON COLUMN EQUIPES.id_entraineur_actuel IS 'ID of the current coach for this team (FK to COACHS)';


-- =============================================================================
-- JOUEURS Table (Players)
-- =============================================================================
CREATE TABLE JOUEURS (
    id_joueur NUMBER PRIMARY KEY,
    nom VARCHAR2(100) NOT NULL,
    prenom VARCHAR2(100) NOT NULL,
    date_naissance DATE NULL,
    position VARCHAR2(50) NULL,
    numero_maillot NUMBER NULL,
    id_equipe_actuelle NUMBER NULL, -- Foreign key to EQUIPES, nullable
    -- Foreign Key Constraint
    CONSTRAINT fk_joueur_equipe FOREIGN KEY (id_equipe_actuelle)
        REFERENCES EQUIPES(id_equipe) ON DELETE SET NULL -- If team is deleted, player becomes free agent (NULL team)
);

COMMENT ON TABLE JOUEURS IS 'Table storing player information';
COMMENT ON COLUMN JOUEURS.id_joueur IS 'Unique identifier for the player (PK)';
COMMENT ON COLUMN JOUEURS.nom IS 'Last name of the player';
COMMENT ON COLUMN JOUEURS.prenom IS 'First name of the player';
COMMENT ON COLUMN JOUEURS.date_naissance IS 'Date of birth of the player';
COMMENT ON COLUMN JOUEURS.position IS 'Playing position (e.g., Attaquant, Gardien)';
COMMENT ON COLUMN JOUEURS.numero_maillot IS 'Jersey number';
COMMENT ON COLUMN JOUEURS.id_equipe_actuelle IS 'ID of the current team for this player (FK to EQUIPES)';

-- =============================================================================
-- HISTORIQUE_COACHS Table (Coach Assignment History)
-- =============================================================================
CREATE TABLE HISTORIQUE_COACHS (
    id_historique NUMBER PRIMARY KEY,   -- Unique primary key for each history entry
    id_coach NUMBER NOT NULL,           -- Foreign key to the COACHS table
    id_equipe NUMBER NOT NULL,          -- Foreign key to the EQUIPES table
    date_debut DATE NOT NULL,           -- Assignment start date
    date_fin DATE NULL,                 -- Assignment end date (NULL if current assignment)
    -- Foreign key constraints
    CONSTRAINT fk_hist_coach FOREIGN KEY (id_coach)
        REFERENCES COACHS(id_coach) ON DELETE CASCADE, -- Deletes history if the coach is deleted
    CONSTRAINT fk_hist_equipe FOREIGN KEY (id_equipe)
        REFERENCES EQUIPES(id_equipe) ON DELETE CASCADE -- Deletes history if the team is deleted
);

COMMENT ON TABLE HISTORIQUE_COACHS IS 'History of coach assignments to teams';
COMMENT ON COLUMN HISTORIQUE_COACHS.id_historique IS 'Unique identifier for the history record (PK)';
COMMENT ON COLUMN HISTORIQUE_COACHS.id_coach IS 'ID of the coach (FK to COACHS)';
COMMENT ON COLUMN HISTORIQUE_COACHS.id_equipe IS 'ID of the team (FK to EQUIPES)';
COMMENT ON COLUMN HISTORIQUE_COACHS.date_debut IS 'Start date of the assignment';
COMMENT ON COLUMN HISTORIQUE_COACHS.date_fin IS 'End date of the assignment (NULL if current)';

-- =============================================================================
-- EQUIPE_JOUEURS Table (Team Roster Link Table)
-- =============================================================================
CREATE TABLE EQUIPE_JOUEURS (
    id_equipe NUMBER NOT NULL,          -- Foreign key to EQUIPES
    id_joueur NUMBER NOT NULL,          -- Foreign key to JOUEURS
    -- Composite Primary Key
    CONSTRAINT pk_equipe_joueurs PRIMARY KEY (id_equipe, id_joueur),
    -- Foreign Key Constraints
    CONSTRAINT fk_eqj_equipe FOREIGN KEY (id_equipe)
        REFERENCES EQUIPES(id_equipe) ON DELETE CASCADE, -- If team is deleted, remove roster link
    CONSTRAINT fk_eqj_joueur FOREIGN KEY (id_joueur)
        REFERENCES JOUEURS(id_joueur) ON DELETE CASCADE  -- If player is deleted, remove roster link
);

COMMENT ON TABLE EQUIPE_JOUEURS IS 'Link table connecting players to teams (roster)';
COMMENT ON COLUMN EQUIPE_JOUEURS.id_equipe IS 'ID of the team (FK/PK part)';
COMMENT ON COLUMN EQUIPE_JOUEURS.id_joueur IS 'ID of the player (FK/PK part)';

-- =============================================================================
-- MATCHS Table
-- =============================================================================
CREATE TABLE MATCHS (
    id_match NUMBER PRIMARY KEY,
    date_match DATE NOT NULL,
    id_equipe_domicile NUMBER NOT NULL, -- Foreign key to EQUIPES
    id_equipe_exterieur NUMBER NOT NULL, -- Foreign key to EQUIPES
    score_domicile NUMBER NULL,         -- Nullable if match not played/result unknown
    score_exterieur NUMBER NULL,        -- Nullable if match not played/result unknown
    lieu VARCHAR2(200) NULL,            -- Location of the match
    -- Foreign Key Constraints
    CONSTRAINT fk_match_eqdom FOREIGN KEY (id_equipe_domicile)
        REFERENCES EQUIPES(id_equipe) ON DELETE CASCADE, -- If home team deleted, delete match
    CONSTRAINT fk_match_eqext FOREIGN KEY (id_equipe_exterieur)
        REFERENCES EQUIPES(id_equipe) ON DELETE CASCADE  -- If away team deleted, delete match
);

COMMENT ON TABLE MATCHS IS 'Table storing match results';
COMMENT ON COLUMN MATCHS.id_match IS 'Unique identifier for the match (PK)';
COMMENT ON COLUMN MATCHS.date_match IS 'Date the match was played';
COMMENT ON COLUMN MATCHS.id_equipe_domicile IS 'ID of the home team (FK to EQUIPES)';
COMMENT ON COLUMN MATCHS.id_equipe_exterieur IS 'ID of the away team (FK to EQUIPES)';
COMMENT ON COLUMN MATCHS.score_domicile IS 'Score of the home team';
COMMENT ON COLUMN MATCHS.score_exterieur IS 'Score of the away team';
COMMENT ON COLUMN MATCHS.lieu IS 'Location where the match was played';

-- =============================================================================
-- TRANSFERTS Table
-- =============================================================================
CREATE TABLE TRANSFERTS (
    id_transfert NUMBER PRIMARY KEY,
    id_joueur NUMBER NOT NULL,              -- Foreign key to JOUEURS
    id_equipe_origine NUMBER NULL,          -- Foreign key to EQUIPES (NULL if from 'Free Agent')
    id_equipe_destination NUMBER NULL,      -- Foreign key to EQUIPES (NULL if to 'Free Agent')
    date_transfert DATE NOT NULL,
    montant NUMBER(12, 2) DEFAULT 0.00,     -- Transfer amount (e.g., up to 9,999,999,999.99)
    -- Foreign Key Constraints
    CONSTRAINT fk_trans_joueur FOREIGN KEY (id_joueur)
        REFERENCES JOUEURS(id_joueur) ON DELETE CASCADE, -- If player deleted, delete transfer history
    CONSTRAINT fk_trans_eqori FOREIGN KEY (id_equipe_origine)
        REFERENCES EQUIPES(id_equipe) ON DELETE SET NULL, -- If origin team deleted, set origin to NULL
    CONSTRAINT fk_trans_eqdest FOREIGN KEY (id_equipe_destination)
        REFERENCES EQUIPES(id_equipe) ON DELETE SET NULL  -- If destination team deleted, set destination to NULL
);

COMMENT ON TABLE TRANSFERTS IS 'Table storing player transfer history';
COMMENT ON COLUMN TRANSFERTS.id_transfert IS 'Unique identifier for the transfer (PK)';
COMMENT ON COLUMN TRANSFERTS.id_joueur IS 'ID of the player transferred (FK to JOUEURS)';
COMMENT ON COLUMN TRANSFERTS.id_equipe_origine IS 'ID of the originating team (FK to EQUIPES, NULL if free)';
COMMENT ON COLUMN TRANSFERTS.id_equipe_destination IS 'ID of the destination team (FK to EQUIPES, NULL if free)';
COMMENT ON COLUMN TRANSFERTS.date_transfert IS 'Date of the transfer';
COMMENT ON COLUMN TRANSFERTS.montant IS 'Transfer fee/amount';

-- =============================================================================
-- Optional: Add Indexes for Foreign Keys for better performance
-- =============================================================================
CREATE INDEX idx_equipes_coach ON EQUIPES(id_entraineur_actuel);
CREATE INDEX idx_joueurs_equipe ON JOUEURS(id_equipe_actuelle);
CREATE INDEX idx_histcoach_coach ON HISTORIQUE_COACHS(id_coach);
CREATE INDEX idx_histcoach_equipe ON HISTORIQUE_COACHS(id_equipe);
CREATE INDEX idx_eqjoueurs_equipe ON EQUIPE_JOUEURS(id_equipe);
CREATE INDEX idx_eqjoueurs_joueur ON EQUIPE_JOUEURS(id_joueur);
CREATE INDEX idx_matchs_dom ON MATCHS(id_equipe_domicile);
CREATE INDEX idx_matchs_ext ON MATCHS(id_equipe_exterieur);
CREATE INDEX idx_transferts_joueur ON TRANSFERTS(id_joueur);
CREATE INDEX idx_transferts_eqori ON TRANSFERTS(id_equipe_origine);
CREATE INDEX idx_transferts_eqdest ON TRANSFERTS(id_equipe_destination);

