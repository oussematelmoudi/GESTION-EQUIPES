// connection.h (Corrigé)
#ifndef CONNECTION_H
#define CONNECTION_H

#include <QSqlDatabase>
#include <QSqlError> // Inclure pour les erreurs
#include <QSqlQuery> // Inclure car souvent utilisé avec la connexion
#include <QString>   // Pour le nom de connexion
#include <QDebug>    // Pour qInfo/qWarning

class Connection
{
private:
    QSqlDatabase db; // Stocke l'objet de base de données comme membre
    QString connectionName; // Nom unique pour cette connexion

public:
    Connection();  // Constructeur pour initialiser la connexion
    ~Connection(); // Destructeur pour nettoyer

    // Tente d'ouvrir la connexion et retourne true si succès, false sinon
    // Affiche l'erreur détaillée en cas d'échec.
    bool createconnect();

    // Ferme la connexion
    void closeconnect();

    // Retourne une référence à l'objet QSqlDatabase pour créer des requêtes
    // Attention: vérifier si la connexion est ouverte avant utilisation.
    QSqlDatabase& database(); // Retourne une référence modifiable

    // Optionnel: Retourne une référence constante si seul l'accès en lecture est requis
    // const QSqlDatabase& database() const;
};

#endif // CONNECTION_H
